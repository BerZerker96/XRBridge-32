// Test client acting as a 32-bit SteamVR game: it loads Valve's own openvr_api.dll,
// which reads openvrpaths.vrpath and loads whichever runtime is registered first.
#include <windows.h>
#include <cstdint>
#include <cstdio>
typedef intptr_t(__cdecl* InitFn)(int*, int);
typedef intptr_t(__cdecl* GetFn)(const char*, int*);
typedef void(__cdecl* ShutFn)();
typedef bool(__cdecl* InstalledFn)();
struct SysTable { void(__stdcall* GetRecommendedRenderTargetSize)(uint32_t*, uint32_t*); };
struct TrackedDevicePose { float m[3][4]; float v[3]; float a[3]; int result; bool valid; bool connected; };
struct CompTable {
    void(__stdcall* SetTrackingSpace)(int);
    int(__stdcall* GetTrackingSpace)();
    int(__stdcall* WaitGetPoses)(TrackedDevicePose*, uint32_t, TrackedDevicePose*, uint32_t);
};
int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    HMODULE h = LoadLibraryA(argc > 1 ? argv[1] : "openvr_api.dll");
    if (!h) { printf("FAIL load openvr_api %lu\n", GetLastError()); return 1; }
    auto init = (InitFn)GetProcAddress(h, "VR_InitInternal");
    auto get = (GetFn)GetProcAddress(h, "VR_GetGenericInterface");
    auto shut = (ShutFn)GetProcAddress(h, "VR_ShutdownInternal");
    auto inst = (InstalledFn)GetProcAddress(h, "VR_IsRuntimeInstalled");
    printf("VR_IsRuntimeInstalled=%d\n", inst());
    int err = 0;
    init(&err, 1 /*Scene*/);
    printf("VR_InitInternal err=%d\n", err);
    if (err) return 2;
    char rp[MAX_PATH] = "?";
    if (HMODULE m = GetModuleHandleA("vrclient.dll")) GetModuleFileNameA(m, rp, MAX_PATH);
    printf("runtime module: %s\n", rp);
    auto* sys = (SysTable*)get("FnTable:IVRSystem_019", &err);
    printf("IVRSystem err=%d table=%p\n", err, (void*)sys);
    if (!sys) return 3;
    uint32_t w = 0, ht = 0;
    sys->GetRecommendedRenderTargetSize(&w, &ht);
    printf("render target %ux%u\n", w, ht);
    auto* comp = (CompTable*)get("FnTable:IVRCompositor_022", &err);
    printf("IVRCompositor err=%d table=%p\n", err, (void*)comp);
    if (!comp) return 4;
    TrackedDevicePose poses[64] = {};
    for (int i = 0; i < 5; ++i) printf("WaitGetPoses -> %d\n", comp->WaitGetPoses(poses, 64, nullptr, 0));
    printf("hmd pose valid=%d x=%.3f\n", poses[0].valid, poses[0].m[0][3]);
    shut();
    printf("OPENVR-OK %ux%u\n", w, ht);
    return 0;
}
