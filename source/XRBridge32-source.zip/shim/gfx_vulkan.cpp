// Vulkan game side: imports the host's D3D11 textures and fence.
#include "gfx.h"
#include "../common/formats.h"
#include <cstring>
#include <mutex>

const char* const kVkInstanceExtensions =
    "VK_KHR_external_memory_capabilities VK_KHR_external_semaphore_capabilities "
    "VK_KHR_external_fence_capabilities VK_KHR_get_physical_device_properties2";
const char* const kVkDeviceExtensions =
    "VK_KHR_dedicated_allocation VK_KHR_get_memory_requirements2 VK_KHR_external_memory "
    "VK_KHR_external_memory_win32 VK_KHR_timeline_semaphore VK_KHR_external_semaphore VK_KHR_external_semaphore_win32";

static PFN_vkGetInstanceProcAddr g_gipa;

// Loaded on demand: a game that never touches Vulkan must not need vulkan-1.dll.
PFN_vkGetInstanceProcAddr vkLoaderProc() {
    if (!g_gipa) {
        HMODULE m = LoadLibraryA("vulkan-1.dll");
        if (m) g_gipa = (PFN_vkGetInstanceProcAddr)GetProcAddress(m, "vkGetInstanceProcAddr");
    }
    return g_gipa;
}
void vkSetLoaderProc(PFN_vkGetInstanceProcAddr fn) { if (fn) g_gipa = fn; }

XrResult vkPickPhysicalDevice(VkInstance instance, const LUID& luid, VkPhysicalDevice* out) {
    PFN_vkGetInstanceProcAddr gipa = vkLoaderProc();
    if (!gipa) return XR_ERROR_RUNTIME_FAILURE;
    auto enumerate = (PFN_vkEnumeratePhysicalDevices)gipa(instance, "vkEnumeratePhysicalDevices");
    auto props2 = (PFN_vkGetPhysicalDeviceProperties2)gipa(instance, "vkGetPhysicalDeviceProperties2");
    if (!props2) props2 = (PFN_vkGetPhysicalDeviceProperties2)gipa(instance, "vkGetPhysicalDeviceProperties2KHR");
    if (!enumerate) return XR_ERROR_RUNTIME_FAILURE;
    uint32_t n = 0;
    if (enumerate(instance, &n, nullptr) != VK_SUCCESS || n == 0) return XR_ERROR_RUNTIME_FAILURE;
    std::vector<VkPhysicalDevice> devs(n);
    if (enumerate(instance, &n, devs.data()) != VK_SUCCESS) return XR_ERROR_RUNTIME_FAILURE;
    if (props2) {
        for (auto d : devs) {
            VkPhysicalDeviceIDProperties id{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES};
            VkPhysicalDeviceProperties2 p{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2, &id};
            props2(d, &p);
            if (id.deviceLUIDValid && !memcmp(id.deviceLUID, &luid, sizeof(LUID))) { *out = d; return XR_SUCCESS; }
        }
    }
    logf("Vulkan: no device matches the headset's GPU");
    return XR_ERROR_RUNTIME_FAILURE;
}

namespace {
#define VK_FNS(X) \
    X(vkGetPhysicalDeviceMemoryProperties) X(vkGetPhysicalDeviceProperties2) X(vkGetDeviceQueue) X(vkCreateImage) X(vkDestroyImage) \
    X(vkGetImageMemoryRequirements) X(vkAllocateMemory) X(vkFreeMemory) X(vkBindImageMemory) X(vkCreateCommandPool) X(vkDestroyCommandPool) \
    X(vkAllocateCommandBuffers) X(vkFreeCommandBuffers) X(vkBeginCommandBuffer) X(vkEndCommandBuffer) X(vkCmdPipelineBarrier) X(vkQueueSubmit) \
    X(vkCreateFence) X(vkDestroyFence) X(vkResetFences) X(vkWaitForFences) X(vkCreateSemaphore) X(vkDestroySemaphore) \
    X(vkImportSemaphoreWin32HandleKHR) X(vkGetMemoryWin32HandlePropertiesKHR) X(vkWaitSemaphores) X(vkGetPhysicalDeviceImageFormatProperties2)

struct VkDispatch {
#define X(f) PFN_##f f = nullptr;
    VK_FNS(X)
#undef X
};

class VkSession;

class VkImages : public GfxImages {
public:
    VkSession* s;
    VkDispatch* vk;
    VkDevice dev;
    bool depth = false, stencil = false, transitioned = false;
    std::vector<VkImage> images;
    std::vector<VkDeviceMemory> memory;
    VkImages(VkSession* session, VkDispatch* d, VkDevice device) : s(session), vk(d), dev(device) {}
    ~VkImages() override {
        // No vkDeviceWaitIdle: it needs every queue externally synchronized, and DXVK submits
        // from its own thread. OpenXR requires the app to have finished with these images.
        for (auto i : images) vk->vkDestroyImage(dev, i, nullptr);
        for (auto m : memory) vk->vkFreeMemory(dev, m, nullptr);
    }
    void fill(XrSwapchainImageBaseHeader* out, uint32_t count) override {
        auto* d = (XrSwapchainImageVulkanKHR*)out;
        for (uint32_t i = 0; i < count && i < images.size(); ++i) d[i].image = images[i];
    }
    void onAcquire() override;
};

class VkSession : public GfxSession {
    XrGraphicsBindingVulkanKHR b;
    VkDispatch vk;
    VkQueue queue = VK_NULL_HANDLE;
    VkPhysicalDeviceMemoryProperties memProps{};
    VkSemaphore timeline = VK_NULL_HANDLE;
    VkFence cpuFence = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE;
    uint64_t value = 0;
    bool ntImport = false;
    std::mutex queueMutex; // apps may call xrReleaseSwapchainImage from several threads
public:
    explicit VkSession(const XrGraphicsBindingVulkanKHR& binding) : b(binding) {}
    ~VkSession() override {
        if (!vk.vkCreateCommandPool) return;
        // Only our own signals are waited for: the queue itself may not be touched here.
        if (timeline && value && vk.vkWaitSemaphores) {
            VkSemaphoreWaitInfo wi{VK_STRUCTURE_TYPE_SEMAPHORE_WAIT_INFO};
            wi.semaphoreCount = 1; wi.pSemaphores = &timeline; wi.pValues = &value;
            vk.vkWaitSemaphores(b.device, &wi, 2000000000ull);
        }
        if (pool) vk.vkDestroyCommandPool(b.device, pool, nullptr);
        if (cpuFence) vk.vkDestroyFence(b.device, cpuFence, nullptr);
        if (timeline) vk.vkDestroySemaphore(b.device, timeline, nullptr);
    }
    const char* name() const override { return "Vulkan"; }
    bool prefersNtHandles() const override { return ntImport; }
    XrStructureType imageType() const override { return XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR; }
    int64_t appFormat(int dxgi) const override { const XrbFormat* f = xrbFindDxgi(dxgi); return f && f->vk ? f->vk : -1; }
    int dxgiFormat(int64_t app) const override { const XrbFormat* f = xrbFindVk((int)app); return f ? f->dxgi : -1; }

    XrResult init(HANDLE fenceHandle, const LUID& luid) override {
        struct CloseOnExit { HANDLE h; ~CloseOnExit() { if (h) CloseHandle(h); } } guard{fenceHandle};
        if (!b.instance || !b.physicalDevice || !b.device) return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        PFN_vkGetInstanceProcAddr gipa = vkLoaderProc();
        if (!gipa) { logf("Vulkan: vulkan-1.dll not found"); return XR_ERROR_RUNTIME_FAILURE; }
        // Device functions come from the game's device: the instance query may return nothing for
        // an extension function, and it adds a dispatch step on every call when it does not.
        auto gdpa = (PFN_vkGetDeviceProcAddr)gipa(b.instance, "vkGetDeviceProcAddr");
        auto load = [&](const char* n) -> PFN_vkVoidFunction {
            PFN_vkVoidFunction f = gdpa ? gdpa(b.device, n) : nullptr;
            return f ? f : gipa(b.instance, n);
        };
#define X(f) vk.f = (PFN_##f)load(#f);
        VK_FNS(X)
#undef X
        if (!vk.vkGetPhysicalDeviceProperties2) vk.vkGetPhysicalDeviceProperties2 = (PFN_vkGetPhysicalDeviceProperties2)gipa(b.instance, "vkGetPhysicalDeviceProperties2KHR");
        if (!vk.vkWaitSemaphores) vk.vkWaitSemaphores = (PFN_vkWaitSemaphores)load("vkWaitSemaphoresKHR");
        if (!vk.vkGetMemoryWin32HandlePropertiesKHR) {
            logf("Vulkan: the game did not enable VK_KHR_external_memory_win32");
            return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        }
        if (vk.vkGetPhysicalDeviceProperties2) {
            VkPhysicalDeviceIDProperties id{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES};
            VkPhysicalDeviceProperties2 p{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2, &id};
            vk.vkGetPhysicalDeviceProperties2(b.physicalDevice, &p);
            if (id.deviceLUIDValid && memcmp(id.deviceLUID, &luid, sizeof(LUID))) {
                logf("Vulkan: the game's GPU is not the headset's GPU");
                return XR_ERROR_GRAPHICS_DEVICE_INVALID;
            }
        }
        vk.vkGetPhysicalDeviceMemoryProperties(b.physicalDevice, &memProps);
        // NT handles are what Vulkan drivers import from D3D11 most widely; the older KMT
        // handles are used only where the driver says it cannot import NT ones.
        if (!vk.vkGetPhysicalDeviceImageFormatProperties2) vk.vkGetPhysicalDeviceImageFormatProperties2 = (PFN_vkGetPhysicalDeviceImageFormatProperties2)gipa(b.instance, "vkGetPhysicalDeviceImageFormatProperties2KHR");
        if (vk.vkGetPhysicalDeviceImageFormatProperties2) {
            VkPhysicalDeviceExternalImageFormatInfo ext{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_IMAGE_FORMAT_INFO};
            ext.handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_D3D11_TEXTURE_BIT;
            VkPhysicalDeviceImageFormatInfo2 fi{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_IMAGE_FORMAT_INFO_2, &ext};
            fi.format = VK_FORMAT_R8G8B8A8_SRGB; fi.type = VK_IMAGE_TYPE_2D; fi.tiling = VK_IMAGE_TILING_OPTIMAL;
            fi.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
            VkExternalImageFormatProperties ep{VK_STRUCTURE_TYPE_EXTERNAL_IMAGE_FORMAT_PROPERTIES};
            VkImageFormatProperties2 p{VK_STRUCTURE_TYPE_IMAGE_FORMAT_PROPERTIES_2, &ep};
            ntImport = vk.vkGetPhysicalDeviceImageFormatProperties2(b.physicalDevice, &fi, &p) == VK_SUCCESS &&
                       (ep.externalMemoryProperties.externalMemoryFeatures & VK_EXTERNAL_MEMORY_FEATURE_IMPORTABLE_BIT);
        }
        logf("Vulkan: importing textures with %s handles", ntImport ? "NT" : "KMT");
        vk.vkGetDeviceQueue(b.device, b.queueFamilyIndex, b.queueIndex, &queue);
        VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        pci.queueFamilyIndex = b.queueFamilyIndex;
        VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        if (vk.vkCreateCommandPool(b.device, &pci, nullptr, &pool) != VK_SUCCESS ||
            vk.vkCreateFence(b.device, &fci, nullptr, &cpuFence) != VK_SUCCESS)
            return XR_ERROR_RUNTIME_FAILURE;

        // A D3D fence is a timeline semaphore here. XR_KHR_vulkan_enable cannot force the
        // timeline feature on, so a game that skipped it falls back to CPU sync.
        if (fenceHandle && vk.vkImportSemaphoreWin32HandleKHR) {
            VkSemaphoreTypeCreateInfo tci{VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO};
            tci.semaphoreType = VK_SEMAPHORE_TYPE_TIMELINE;
            VkSemaphoreCreateInfo sci{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO, &tci};
            if (vk.vkCreateSemaphore(b.device, &sci, nullptr, &timeline) == VK_SUCCESS) {
                VkImportSemaphoreWin32HandleInfoKHR imp{VK_STRUCTURE_TYPE_IMPORT_SEMAPHORE_WIN32_HANDLE_INFO_KHR};
                imp.semaphore = timeline;
                imp.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_D3D11_FENCE_BIT;
                imp.handle = fenceHandle;
                if (vk.vkImportSemaphoreWin32HandleKHR(b.device, &imp) != VK_SUCCESS) {
                    vk.vkDestroySemaphore(b.device, timeline, nullptr);
                    timeline = VK_NULL_HANDLE;
                }
            } else {
                timeline = VK_NULL_HANDLE;
            }
        }
        if (!timeline) logf("Vulkan: no shared fence, using CPU sync");
        return XR_SUCCESS;
    }

    XrResult open(const SwapchainInfo& info, const std::vector<uint64_t>& handles, GfxImages** out) override {
        auto* im = new VkImages(this, &vk, b.device);
        const auto ht = info.ntHandles ? VK_EXTERNAL_MEMORY_HANDLE_TYPE_D3D11_TEXTURE_BIT : VK_EXTERNAL_MEMORY_HANDLE_TYPE_D3D11_TEXTURE_KMT_BIT;
        const XrbFormat* fm = xrbFindVk((int)info.appFormat);
        const bool depth = fm && fm->depth;
        im->depth = depth;
        im->stencil = fm && fm->stencil;
        VkImageUsageFlags usage = (depth ? VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT : VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT) | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        if (info.usage & XR_SWAPCHAIN_USAGE_SAMPLED_BIT) usage |= VK_IMAGE_USAGE_SAMPLED_BIT;
        if ((info.usage & XR_SWAPCHAIN_USAGE_UNORDERED_ACCESS_BIT) && !depth) usage |= VK_IMAGE_USAGE_STORAGE_BIT;
        for (uint64_t h : handles) {
            VkExternalMemoryImageCreateInfo ext{VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO};
            ext.handleTypes = ht;
            VkImageCreateInfo ci{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO, &ext};
            if (info.usage & XR_SWAPCHAIN_USAGE_MUTABLE_FORMAT_BIT) ci.flags |= VK_IMAGE_CREATE_MUTABLE_FORMAT_BIT;
            if (info.faceCount == 6) ci.flags |= VK_IMAGE_CREATE_CUBE_COMPATIBLE_BIT;
            ci.imageType = VK_IMAGE_TYPE_2D;
            ci.format = (VkFormat)info.appFormat;
            ci.extent = {info.width, info.height, 1};
            ci.mipLevels = info.mipCount;
            ci.arrayLayers = info.arraySize * info.faceCount;
            ci.samples = (VkSampleCountFlagBits)info.sampleCount;
            ci.tiling = VK_IMAGE_TILING_OPTIMAL;
            ci.usage = usage;
            ci.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
            ci.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            VkImage image = VK_NULL_HANDLE;
            VkResult r = vk.vkCreateImage(b.device, &ci, nullptr, &image);
            if (r != VK_SUCCESS) { logf("Vulkan: vkCreateImage failed %d", r); delete im; return XR_ERROR_SWAPCHAIN_FORMAT_UNSUPPORTED; }
            im->images.push_back(image);

            VkMemoryRequirements req{};
            vk.vkGetImageMemoryRequirements(b.device, image, &req);
            VkMemoryWin32HandlePropertiesKHR hp{VK_STRUCTURE_TYPE_MEMORY_WIN32_HANDLE_PROPERTIES_KHR};
            r = vk.vkGetMemoryWin32HandlePropertiesKHR(b.device, ht, (HANDLE)(uintptr_t)h, &hp);
            if (r != VK_SUCCESS) { logf("Vulkan: handle properties failed %d", r); delete im; return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
            uint32_t type = UINT32_MAX;
            const uint32_t usable = hp.memoryTypeBits & req.memoryTypeBits;
            for (uint32_t i = 0; i < memProps.memoryTypeCount && type == UINT32_MAX; ++i)
                if ((usable & (1u << i)) && (memProps.memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)) type = i;
            if (type == UINT32_MAX) {
                // Some drivers report no bits for a D3D11 handle. The image's own requirements
                // are then the only guide, and the import below still validates the choice.
                logf("Vulkan: handle reports memory types 0x%x, image allows 0x%x", hp.memoryTypeBits, req.memoryTypeBits);
                for (uint32_t i = 0; i < memProps.memoryTypeCount && type == UINT32_MAX; ++i)
                    if ((req.memoryTypeBits & (1u << i)) && (memProps.memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)) type = i;
            }
            if (type == UINT32_MAX) { logf("Vulkan: no memory type for the shared texture"); delete im; return XR_ERROR_GRAPHICS_DEVICE_INVALID; }

            VkImportMemoryWin32HandleInfoKHR imp{VK_STRUCTURE_TYPE_IMPORT_MEMORY_WIN32_HANDLE_INFO_KHR};
            imp.handleType = ht;
            imp.handle = (HANDLE)(uintptr_t)h;
            VkMemoryDedicatedAllocateInfo ded{VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO, &imp};
            ded.image = image;
            VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO, &ded};
            mai.allocationSize = req.size;
            mai.memoryTypeIndex = type;
            VkDeviceMemory mem = VK_NULL_HANDLE;
            r = vk.vkAllocateMemory(b.device, &mai, nullptr, &mem);
            if (r != VK_SUCCESS) { logf("Vulkan: importing texture memory failed %d", r); delete im; return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
            im->memory.push_back(mem);
            r = vk.vkBindImageMemory(b.device, image, mem, 0);
            if (r != VK_SUCCESS) { logf("Vulkan: bind failed %d", r); delete im; return XR_ERROR_RUNTIME_FAILURE; }
        }

        // The layout change has to wait for the first xrAcquireSwapchainImage: xrCreateSwapchain
        // may not touch the app's queue, and DXVK could be submitting on it at this moment.
        *out = im;
        return XR_SUCCESS;
    }

    // Hands images over in the layout OpenXR promises the app. The layout never changes after
    // this, because the host only copies from the memory.
    void transition(VkImages& im) {
        std::lock_guard<std::mutex> l(queueMutex);
        VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cai.commandPool = pool;
        cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        cai.commandBufferCount = 1;
        VkCommandBuffer cmd = VK_NULL_HANDLE;
        if (vk.vkAllocateCommandBuffers(b.device, &cai, &cmd) != VK_SUCCESS) { logf("Vulkan: could not allocate a command buffer"); return; }
        VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        vk.vkBeginCommandBuffer(cmd, &begin);
        for (auto image : im.images) {
            VkImageMemoryBarrier bar{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
            bar.dstAccessMask = im.depth ? VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT : VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
            bar.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            bar.newLayout = im.depth ? VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL : VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            bar.srcQueueFamilyIndex = bar.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            bar.image = image;
            VkImageAspectFlags aspect = im.depth ? (VkImageAspectFlags)(VK_IMAGE_ASPECT_DEPTH_BIT | (im.stencil ? VK_IMAGE_ASPECT_STENCIL_BIT : 0)) : (VkImageAspectFlags)VK_IMAGE_ASPECT_COLOR_BIT;
            bar.subresourceRange = {aspect, 0, VK_REMAINING_MIP_LEVELS, 0, VK_REMAINING_ARRAY_LAYERS};
            vk.vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_ALL_GRAPHICS_BIT, 0, 0, nullptr, 0, nullptr, 1, &bar);
        }
        vk.vkEndCommandBuffer(cmd);
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1;
        si.pCommandBuffers = &cmd;
        vk.vkResetFences(b.device, 1, &cpuFence);
        VkResult r = vk.vkQueueSubmit(queue, 1, &si, cpuFence);
        if (r == VK_SUCCESS) vk.vkWaitForFences(b.device, 1, &cpuFence, VK_TRUE, 5000000000ull);
        else logf("Vulkan: layout transition failed %d", r);
        vk.vkFreeCommandBuffers(b.device, pool, 1, &cmd);
    }

    uint64_t sync() override {
        std::lock_guard<std::mutex> l(queueMutex);
        if (timeline) {
            uint64_t v = value + 1;
            VkTimelineSemaphoreSubmitInfo ti{VK_STRUCTURE_TYPE_TIMELINE_SEMAPHORE_SUBMIT_INFO};
            ti.signalSemaphoreValueCount = 1;
            ti.pSignalSemaphoreValues = &v;
            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO, &ti};
            si.signalSemaphoreCount = 1;
            si.pSignalSemaphores = &timeline;
            if (vk.vkQueueSubmit(queue, 1, &si, VK_NULL_HANDLE) == VK_SUCCESS) { value = v; return v; }
        }
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        vk.vkResetFences(b.device, 1, &cpuFence);
        if (vk.vkQueueSubmit(queue, 1, &si, cpuFence) == VK_SUCCESS)
            vk.vkWaitForFences(b.device, 1, &cpuFence, VK_TRUE, 5000000000ull);
        return 0;
    }
};

void VkImages::onAcquire() {
    if (transitioned) return;
    transitioned = true;
    s->transition(*this);
}
} // namespace

GfxSession* makeVulkanSession(const XrGraphicsBindingVulkanKHR& b) { return new VkSession(b); }
