// XRBridge32 wire protocol, shared by the 32-bit shim and the 64-bit host.
//
// Why this is hand-marshalled: XR handles, atoms and pointer-free structs have
// the same layout in both architectures, but every struct with a `next` pointer
// has different offsets. Those are written field by field. Pointer-free structs
// are copied whole, guarded by the static_asserts below.
#pragma once
#include <windows.h>
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <type_traits>
#include <vector>

enum Op : uint32_t {
    OP_HELLO = 1,
    OP_ENUM_EXTENSIONS, OP_CREATE_INSTANCE, OP_DESTROY_INSTANCE, OP_GET_INSTANCE_PROPERTIES,
    OP_POLL_EVENT, OP_RESULT_TO_STRING, OP_STRUCT_TO_STRING,
    OP_GET_SYSTEM, OP_GET_SYSTEM_PROPERTIES, OP_ENUM_BLEND_MODES,
    OP_CREATE_SESSION, OP_DESTROY_SESSION,
    OP_ENUM_REF_SPACES, OP_CREATE_REF_SPACE, OP_GET_BOUNDS, OP_CREATE_ACTION_SPACE, OP_LOCATE_SPACE, OP_DESTROY_SPACE,
    OP_ENUM_VIEW_CONFIGS, OP_GET_VIEW_CONFIG_PROPS, OP_ENUM_VIEW_CONFIG_VIEWS,
    OP_ENUM_SWAPCHAIN_FORMATS, OP_CREATE_SWAPCHAIN, OP_DESTROY_SWAPCHAIN,
    OP_ACQUIRE_IMAGE, OP_WAIT_IMAGE, OP_RELEASE_IMAGE,
    OP_BEGIN_SESSION, OP_END_SESSION, OP_REQUEST_EXIT,
    OP_WAIT_FRAME, OP_BEGIN_FRAME, OP_END_FRAME, OP_LOCATE_VIEWS,
    OP_STRING_TO_PATH, OP_PATH_TO_STRING,
    OP_CREATE_ACTION_SET, OP_DESTROY_ACTION_SET, OP_CREATE_ACTION, OP_DESTROY_ACTION,
    OP_SUGGEST_BINDINGS, OP_ATTACH_ACTION_SETS, OP_GET_INTERACTION_PROFILE,
    OP_GET_STATE_BOOL, OP_GET_STATE_FLOAT, OP_GET_STATE_VEC2, OP_GET_STATE_POSE,
    OP_SYNC_ACTIONS, OP_ENUM_BOUND_SOURCES, OP_GET_SOURCE_NAME,
    OP_APPLY_HAPTIC, OP_STOP_HAPTIC,
    OP_GET_D3D11_REQUIREMENTS, OP_GET_VISIBILITY_MASK, OP_PERF_TO_TIME, OP_TIME_TO_PERF,
    OP_LOCATE_SPACES, OP_GENERIC, OP_HAS_FUNCTION,
};

constexpr uint32_t XRB_PROTOCOL = 4;
constexpr uint32_t XRB_MAX_ARRAY = 1u << 20; // upper bound on any two-call capacity
constexpr uint32_t XRB_MAX_MESSAGE = 16 * 1024 * 1024;

class Writer {
public:
    std::vector<uint8_t> buf;
    template <class T> void put(const T& v) {
        static_assert(std::is_trivially_copyable<T>::value, "POD only");
        raw(&v, sizeof(T));
    }
    void raw(const void* p, size_t n) {
        const uint8_t* b = static_cast<const uint8_t*>(p);
        if (n) buf.insert(buf.end(), b, b + n);
    }
    void str(const char* s) {
        uint32_t n = s ? (uint32_t)strlen(s) : 0;
        put(n);
        raw(s, n);
    }
};

class Reader {
public:
    Reader() = default;
    Reader(const uint8_t* b, size_t n) : p(b), e(b + n) {}
    bool bad = false;
    template <class T> T get() {
        T v{};
        raw(&v, sizeof(T));
        return v;
    }
    void raw(void* out, size_t n) {
        if (n == 0) return;
        if (bad || (size_t)(e - p) < n) { bad = true; return; }
        memcpy(out, p, n);
        p += n;
    }
    std::string str() {
        uint32_t n = get<uint32_t>();
        if (bad || (size_t)(e - p) < n) { bad = true; return {}; }
        std::string s((const char*)p, n);
        p += n;
        return s;
    }
    // Reads a count then that many elements, bounded by the bytes actually present.
    template <class T> std::vector<T> vec() {
        uint32_t n = get<uint32_t>();
        if (bad || (size_t)(e - p) / sizeof(T) < n) { bad = true; return {}; }
        std::vector<T> v(n);
        raw(v.data(), n * sizeof(T));
        return v;
    }
private:
    const uint8_t* p = nullptr;
    const uint8_t* e = nullptr;
};

// Messages are length-prefixed on a byte-mode pipe.
inline bool pipeWriteAll(HANDLE h, const void* data, size_t n) {
    const uint8_t* p = static_cast<const uint8_t*>(data);
    while (n) {
        DWORD done = 0;
        if (!WriteFile(h, p, (DWORD)n, &done, nullptr)) return false;
        p += done;
        n -= done;
    }
    return true;
}
inline bool pipeReadAll(HANDLE h, void* data, size_t n) {
    uint8_t* p = static_cast<uint8_t*>(data);
    while (n) {
        DWORD done = 0;
        if (!ReadFile(h, p, (DWORD)n, &done, nullptr) || done == 0) return false;
        p += done;
        n -= done;
    }
    return true;
}
inline bool sendMessage(HANDLE h, const std::vector<uint8_t>& m) {
    uint32_t n = (uint32_t)m.size();
    return pipeWriteAll(h, &n, 4) && pipeWriteAll(h, m.data(), n);
}
inline bool recvMessage(HANDLE h, std::vector<uint8_t>& m) {
    uint32_t n = 0;
    if (!pipeReadAll(h, &n, 4) || n > XRB_MAX_MESSAGE) return false;
    m.resize(n);
    return pipeReadAll(h, m.data(), n);
}

// Per-request allocations on the receiving side of generated marshalling.
// A bump allocator whose first chunk is kept between requests, so the hot path does no heap
// allocation. Requests too big for it get chunks of their own, freed on clear().
struct Arena {
    static constexpr size_t kChunk = 64 * 1024;
    std::unique_ptr<char[]> main{new char[kChunk]};
    size_t used = 0;
    std::vector<std::unique_ptr<char[]>> extra;
    template <class T> T* alloc(size_t n) {
        size_t bytes = sizeof(T) * (n ? n : 1);
        size_t start = (used + 15) & ~(size_t)15;
        char* p;
        if (start + bytes <= kChunk) {
            p = main.get() + start;
            used = start + bytes;
        } else {
            extra.emplace_back(new char[bytes]);
            p = extra.back().get();
        }
        memset(p, 0, bytes);
        return reinterpret_cast<T*>(p);
    }
    const char* str(const std::string& s) {
        char* p = alloc<char>(s.size() + 1);
        memcpy(p, s.data(), s.size());
        return p;
    }
    void clear() { used = 0; extra.clear(); }
};

// ---------------------------------------------------------------- fast transport
// Each app thread gets one shared memory block for requests and replies. A pipe round
// trip costs kernel calls and context switches, and OpenComposite makes hundreds of calls
// per frame. Here both sides spin briefly, so a burst of calls runs without entering the
// kernel, then sleep on an event so idle time costs nothing. The pipe stays for connection
// setup and for messages too big for the block.
constexpr uint32_t XRB_SHM_CAPACITY = 256 * 1024;
enum : LONG { SHM_IDLE = 0, SHM_REQUEST, SHM_REPLY, SHM_REQUEST_PIPE, SHM_REPLY_PIPE, SHM_CLOSE };
struct ShmBlock {
    volatile LONG state;
    volatile LONG hostSleeping;
    volatile LONG clientSleeping;
    volatile LONG size;
    uint8_t data[XRB_SHM_CAPACITY];
};
// How long each side keeps polling before sleeping, in pause instructions. On current CPUs
// these are tens of microseconds, far below a frame and comparable to one kernel round trip.
constexpr int XRB_HOST_SPIN = 4000;
constexpr int XRB_CLIENT_SPIN = 6000;

// Layout guards for structs copied whole across the 32/64 boundary.
#ifdef XR_CURRENT_API_VERSION
static_assert(sizeof(XrPosef) == 28 && sizeof(XrFovf) == 16 && sizeof(XrRect2Di) == 16, "layout");
static_assert(sizeof(XrExtent2Df) == 8 && sizeof(XrVector2f) == 8 && sizeof(XrVector3f) == 12, "layout");
static_assert(sizeof(XrSwapchainSubImage) == 32 && offsetof(XrSwapchainSubImage, imageRect) == 8, "layout");
static_assert(sizeof(XrActionSuggestedBinding) == 16 && sizeof(XrActiveActionSet) == 16, "layout");
static_assert(sizeof(XrApplicationInfo) == 272, "layout");
static_assert(sizeof(XrSystemGraphicsProperties) == 12 && sizeof(XrSystemTrackingProperties) == 8, "layout");
#endif

#if defined(XR_CURRENT_API_VERSION) && defined(XR_EXT_hand_tracking)
static_assert(sizeof(XrHandJointLocationEXT) == 40 && sizeof(XrHandJointVelocityEXT) == 32, "layout");
#endif
#ifdef XR_CURRENT_API_VERSION
static_assert(sizeof(XrSpaceLocationData) == 40 && sizeof(XrSpaceVelocityData) == 32, "layout");
#endif

#define XRB_RUNTIME_NAME "XRBridge32 (32-bit to 64-bit OpenXR bridge)"
