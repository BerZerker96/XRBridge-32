// xrbridge_selftest32.exe: a small 32-bit OpenXR app that goes through the real
// Khronos loader and the WOW6432Node registry slot, the same way a 32-bit game
// using OpenComposite does.
//
//   xrbridge_selftest32 --api d3d11|d3d12|vulkan|opengl [--seconds N]
//
//   With a headset: fills each eye with a colour for the chosen API. The D3D11, D3D12
//     and OpenGL tests also draw the top half white, so an upside-down image is obvious.
//   With XRB_MOCK=1: runs against tests/mock_runtime and checks every marshalled value.
//   With XRB_NULL_GFX=1: no GPU work, for testing the bridge's call paths.
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#define XR_USE_GRAPHICS_API_D3D12
#define XR_USE_GRAPHICS_API_VULKAN
#define XR_USE_GRAPHICS_API_OPENGL
#define VK_USE_PLATFORM_WIN32_KHR
#define VK_NO_PROTOTYPES
#include <windows.h>
#include <unknwn.h>
#include <d3d11_1.h>
#include <d3d12.h>
#include <dxgi.h>
#include <GL/gl.h>
#include <vulkan/vulkan.h>
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

static int g_fail, g_pass;
static bool g_mock, g_null;
#define OK(expr) do { XrResult r_ = (expr); if (XR_FAILED(r_)) { printf("FAIL %s -> %d\n", #expr, (int)r_); ++g_fail; return 1; } ++g_pass; } while (0)
#define EXPECT(c) do { if (g_mock) { if (c) ++g_pass; else { printf("FAIL line %d: %s\n", __LINE__, #c); ++g_fail; } } } while (0)
#define LOAD(fnptr, name) OK(xrGetInstanceProcAddr(inst, name, (PFN_xrVoidFunction*)&fnptr))

static XrInstance inst;
static XrSession sess;
static XrSessionState state = XR_SESSION_STATE_UNKNOWN;
static bool running = false;

static XrPosef pose() {
    XrPosef p;
    p.orientation = {0.5f, 0.25f, 0.125f, 0.0625f};
    p.position = {1.5f, 2.5f, 3.5f};
    return p;
}
static bool same(const XrPosef& a, const XrPosef& b) { return !memcmp(&a, &b, sizeof(a)); }

// ---------------------------------------------------------------- renderers
struct Renderer {
    virtual ~Renderer() {}
    virtual const char* extension() = 0;
    virtual XrStructureType bindingType() = 0;
    virtual XrStructureType imageType() = 0;
    virtual size_t imageSize() = 0;
    virtual int setup(XrSystemId sys) = 0;
    virtual const void* binding() = 0;
    virtual int addSwapchain(int eye, const void* images, uint32_t n, int64_t format) = 0;
    virtual void draw(int eye, uint32_t idx, int w, int h, float pulse) = 0;
};

static IDXGIAdapter1* adapterFor(const LUID& luid) {
    IDXGIFactory1* f = nullptr; IDXGIAdapter1* a = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&f))) return nullptr;
    for (UINT i = 0; f->EnumAdapters1(i, &a) == S_OK; ++i) {
        DXGI_ADAPTER_DESC1 d; a->GetDesc1(&d);
        if (!memcmp(&d.AdapterLuid, &luid, sizeof(LUID))) break;
        a->Release(); a = nullptr;
    }
    f->Release();
    return a;
}

struct D3D11R : Renderer {
    ID3D11Device* dev = nullptr; ID3D11DeviceContext* ctx = nullptr; ID3D11DeviceContext1* ctx1 = nullptr;
    XrGraphicsBindingD3D11KHR gb{XR_TYPE_GRAPHICS_BINDING_D3D11_KHR};
    std::vector<ID3D11RenderTargetView*> rtv[2];
    const char* extension() override { return "XR_KHR_D3D11_enable"; }
    XrStructureType bindingType() override { return gb.type; }
    XrStructureType imageType() override { return XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR; }
    size_t imageSize() override { return sizeof(XrSwapchainImageD3D11KHR); }
    const void* binding() override { return &gb; }
    int setup(XrSystemId sys) override {
        PFN_xrGetD3D11GraphicsRequirementsKHR fn = nullptr;
        LOAD(fn, "xrGetD3D11GraphicsRequirementsKHR");
        XrGraphicsRequirementsD3D11KHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
        OK(fn(inst, sys, &rq));
        if (g_null) return 0;
        IDXGIAdapter1* a = adapterFor(rq.adapterLuid);
        if (!a) { printf("FAIL no adapter matches the runtime's LUID\n"); return 1; }
        D3D_FEATURE_LEVEL fl = D3D_FEATURE_LEVEL_11_0;
        HRESULT hr = D3D11CreateDevice(a, D3D_DRIVER_TYPE_UNKNOWN, nullptr, 0, &fl, 1, D3D11_SDK_VERSION, &dev, nullptr, &ctx);
        a->Release();
        if (FAILED(hr)) { printf("FAIL D3D11CreateDevice 0x%08lx\n", hr); return 1; }
        ctx->QueryInterface(__uuidof(ID3D11DeviceContext1), (void**)&ctx1);
        gb.device = dev;
        return 0;
    }
    int addSwapchain(int eye, const void* images, uint32_t n, int64_t format) override {
        if (g_null) return 0;
        auto* im = (const XrSwapchainImageD3D11KHR*)images;
        for (uint32_t i = 0; i < n; ++i) {
            D3D11_RENDER_TARGET_VIEW_DESC rv{};
            rv.Format = (DXGI_FORMAT)format;
            rv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
            ID3D11RenderTargetView* v = nullptr;
            HRESULT hr = dev->CreateRenderTargetView(im[i].texture, &rv, &v);
            if (FAILED(hr)) { printf("FAIL CreateRenderTargetView 0x%08lx\n", hr); return 1; }
            rtv[eye].push_back(v);
        }
        return 0;
    }
    void draw(int eye, uint32_t idx, int w, int h, float p) override {
        if (g_null) return;
        float col[4] = {0.0f, 0.3f + 0.3f * p, 0.0f, 1.0f}, top[4] = {0.9f, 0.9f, 0.9f, 1.0f};
        ctx->ClearRenderTargetView(rtv[eye][idx], col);
        if (ctx1) { D3D11_RECT r = {0, 0, w, h / 2}; ctx1->ClearView(rtv[eye][idx], top, &r, 1); }
    }
};

struct D3D12R : Renderer {
    ID3D12Device* dev = nullptr; ID3D12CommandQueue* queue = nullptr; ID3D12CommandAllocator* alloc = nullptr;
    ID3D12GraphicsCommandList* list = nullptr; ID3D12Fence* fence = nullptr; ID3D12DescriptorHeap* heap = nullptr;
    HANDLE event = nullptr; uint64_t value = 0; UINT rtvSize = 0, used = 0;
    std::vector<D3D12_CPU_DESCRIPTOR_HANDLE> rtv[2];
    XrGraphicsBindingD3D12KHR gb{XR_TYPE_GRAPHICS_BINDING_D3D12_KHR};
    const char* extension() override { return "XR_KHR_D3D12_enable"; }
    XrStructureType bindingType() override { return gb.type; }
    XrStructureType imageType() override { return XR_TYPE_SWAPCHAIN_IMAGE_D3D12_KHR; }
    size_t imageSize() override { return sizeof(XrSwapchainImageD3D12KHR); }
    const void* binding() override { return &gb; }
    int setup(XrSystemId sys) override {
        PFN_xrGetD3D12GraphicsRequirementsKHR fn = nullptr;
        LOAD(fn, "xrGetD3D12GraphicsRequirementsKHR");
        XrGraphicsRequirementsD3D12KHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D12_KHR};
        OK(fn(inst, sys, &rq));
        if (g_null) return 0;
        HMODULE m = LoadLibraryA("d3d12.dll");
        if (!m) { printf("FAIL d3d12.dll not available\n"); return 1; }
        auto create = (PFN_D3D12_CREATE_DEVICE)GetProcAddress(m, "D3D12CreateDevice");
        IDXGIAdapter1* a = adapterFor(rq.adapterLuid);
        if (!a) { printf("FAIL no adapter matches the runtime's LUID\n"); return 1; }
        HRESULT hr = create(a, D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), (void**)&dev);
        a->Release();
        if (FAILED(hr)) { printf("FAIL D3D12CreateDevice 0x%08lx\n", hr); return 1; }
        D3D12_COMMAND_QUEUE_DESC qd{};
        qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        D3D12_DESCRIPTOR_HEAP_DESC hd{};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV; hd.NumDescriptors = 64;
        if (FAILED(dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void**)&queue)) ||
            FAILED(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&alloc)) ||
            FAILED(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&list)) ||
            FAILED(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence), (void**)&fence)) ||
            FAILED(dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap), (void**)&heap))) {
            printf("FAIL creating D3D12 objects\n");
            return 1;
        }
        list->Close();
        event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        rtvSize = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
        gb.device = dev; gb.queue = queue;
        return 0;
    }
    int addSwapchain(int eye, const void* images, uint32_t n, int64_t format) override {
        if (g_null) return 0;
        auto* im = (const XrSwapchainImageD3D12KHR*)images;
        for (uint32_t i = 0; i < n; ++i) {
            D3D12_RENDER_TARGET_VIEW_DESC rv{};
            rv.Format = (DXGI_FORMAT)format;
            rv.ViewDimension = D3D12_RTV_DIMENSION_TEXTURE2D;
            D3D12_CPU_DESCRIPTOR_HANDLE h = heap->GetCPUDescriptorHandleForHeapStart();
            h.ptr += rtvSize * used++;
            dev->CreateRenderTargetView(im[i].texture, &rv, h);
            rtv[eye].push_back(h);
        }
        return 0;
    }
    void draw(int eye, uint32_t idx, int w, int h, float p) override {
        if (g_null) return;
        alloc->Reset();
        list->Reset(alloc, nullptr);
        float col[4] = {0.0f, 0.0f, 0.3f + 0.3f * p, 1.0f}, top[4] = {0.9f, 0.9f, 0.9f, 1.0f};
        D3D12_RECT r = {0, 0, w, h / 2};
        list->ClearRenderTargetView(rtv[eye][idx], col, 0, nullptr);
        list->ClearRenderTargetView(rtv[eye][idx], top, 1, &r);
        list->Close();
        ID3D12CommandList* lists[] = {list};
        queue->ExecuteCommandLists(1, lists);
        ++value;
        queue->Signal(fence, value);
        fence->SetEventOnCompletion(value, event);
        WaitForSingleObject(event, 5000);
    }
};

struct VulkanR : Renderer {
    XrGraphicsBindingVulkanKHR gb{XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR};
    PFN_vkGetInstanceProcAddr gipa = nullptr;
    VkQueue queue = VK_NULL_HANDLE; VkCommandPool pool = VK_NULL_HANDLE; VkCommandBuffer cmd = VK_NULL_HANDLE; VkFence fence = VK_NULL_HANDLE;
    std::vector<VkImage> images[2];
#define VKF(X) X(vkBeginCommandBuffer) X(vkEndCommandBuffer) X(vkCmdPipelineBarrier) X(vkCmdClearColorImage) X(vkQueueSubmit) X(vkWaitForFences) X(vkResetFences) X(vkResetCommandBuffer)
#define X(f) PFN_##f f = nullptr;
    VKF(X)
#undef X
    const char* extension() override { return "XR_KHR_vulkan_enable"; }
    XrStructureType bindingType() override { return gb.type; }
    XrStructureType imageType() override { return XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR; }
    size_t imageSize() override { return sizeof(XrSwapchainImageVulkanKHR); }
    const void* binding() override { return &gb; }
    static std::vector<std::string> words(const std::string& s) {
        std::vector<std::string> out; std::string cur;
        for (char c : s) { if (c == ' ' || !c) { if (!cur.empty()) out.push_back(cur); cur.clear(); } else cur += c; }
        if (!cur.empty()) out.push_back(cur);
        return out;
    }
    int setup(XrSystemId sys) override {
        PFN_xrGetVulkanGraphicsRequirementsKHR req = nullptr;
        PFN_xrGetVulkanInstanceExtensionsKHR ie = nullptr;
        PFN_xrGetVulkanDeviceExtensionsKHR de = nullptr;
        PFN_xrGetVulkanGraphicsDeviceKHR gd = nullptr;
        LOAD(req, "xrGetVulkanGraphicsRequirementsKHR"); LOAD(ie, "xrGetVulkanInstanceExtensionsKHR");
        LOAD(de, "xrGetVulkanDeviceExtensionsKHR"); LOAD(gd, "xrGetVulkanGraphicsDeviceKHR");
        XrGraphicsRequirementsVulkanKHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_VULKAN_KHR};
        OK(req(inst, sys, &rq));
        uint32_t n = 0;
        OK(ie(inst, sys, 0, &n, nullptr));
        std::string ies(n, 0);
        OK(ie(inst, sys, n, &n, &ies[0]));
        OK(de(inst, sys, 0, &n, nullptr));
        std::string des(n, 0);
        OK(de(inst, sys, n, &n, &des[0]));
        EXPECT(ies.find("VK_KHR_external_memory_capabilities") != std::string::npos);
        EXPECT(des.find("VK_KHR_external_memory_win32") != std::string::npos);
        if (g_null) return 0;

        HMODULE m = LoadLibraryA("vulkan-1.dll");
        if (!m) { printf("FAIL vulkan-1.dll not available\n"); return 1; }
        gipa = (PFN_vkGetInstanceProcAddr)GetProcAddress(m, "vkGetInstanceProcAddr");
        auto createInstance = (PFN_vkCreateInstance)gipa(VK_NULL_HANDLE, "vkCreateInstance");
        auto ieWords = words(ies), deWords = words(des);
        std::vector<const char*> iNames, dNames;
        for (auto& w : ieWords) iNames.push_back(w.c_str());
        for (auto& w : deWords) dNames.push_back(w.c_str());
        VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        ai.apiVersion = VK_MAKE_VERSION(1, 1, 0);
        VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        ici.pApplicationInfo = &ai;
        ici.enabledExtensionCount = (uint32_t)iNames.size(); ici.ppEnabledExtensionNames = iNames.data();
        VkResult r = createInstance(&ici, nullptr, &gb.instance);
        if (r != VK_SUCCESS) { printf("FAIL vkCreateInstance %d\n", r); return 1; }
        OK(gd(inst, sys, gb.instance, &gb.physicalDevice));
        auto families = (PFN_vkGetPhysicalDeviceQueueFamilyProperties)gipa(gb.instance, "vkGetPhysicalDeviceQueueFamilyProperties");
        uint32_t fc = 0;
        families(gb.physicalDevice, &fc, nullptr);
        std::vector<VkQueueFamilyProperties> fp(fc);
        families(gb.physicalDevice, &fc, fp.data());
        for (uint32_t i = 0; i < fc; ++i) if (fp[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) { gb.queueFamilyIndex = i; break; }
        float prio = 1.0f;
        VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        qci.queueFamilyIndex = gb.queueFamilyIndex; qci.queueCount = 1; qci.pQueuePriorities = &prio;
        VkPhysicalDeviceTimelineSemaphoreFeatures tl{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES};
        tl.timelineSemaphore = VK_TRUE;
        VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO, &tl};
        dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qci;
        dci.enabledExtensionCount = (uint32_t)dNames.size(); dci.ppEnabledExtensionNames = dNames.data();
        // The semaphore extensions are optional for this test: without them the bridge uses
        // its CPU sync. Memory import is what actually has to work.
        {
            auto enumExt = (PFN_vkEnumerateDeviceExtensionProperties)gipa(gb.instance, "vkEnumerateDeviceExtensionProperties");
            uint32_t ec = 0;
            enumExt(gb.physicalDevice, nullptr, &ec, nullptr);
            std::vector<VkExtensionProperties> have(ec);
            enumExt(gb.physicalDevice, nullptr, &ec, have.data());
            std::vector<const char*> kept;
            for (auto* name : dNames) {
                bool found = false;
                for (auto& h : have) if (!strcmp(h.extensionName, name)) found = true;
                if (found) kept.push_back(name);
                else printf("device lacks %s\n", name);
            }
            dNames = kept;
            dci.enabledExtensionCount = (uint32_t)dNames.size(); dci.ppEnabledExtensionNames = dNames.data();
        }
        auto createDevice = (PFN_vkCreateDevice)gipa(gb.instance, "vkCreateDevice");
        r = createDevice(gb.physicalDevice, &dci, nullptr, &gb.device);
        if (r != VK_SUCCESS) { printf("FAIL vkCreateDevice %d\n", r); return 1; }
#define X(f) f = (PFN_##f)gipa(gb.instance, #f);
        VKF(X)
#undef X
        ((PFN_vkGetDeviceQueue)gipa(gb.instance, "vkGetDeviceQueue"))(gb.device, gb.queueFamilyIndex, 0, &queue);
        VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT; pci.queueFamilyIndex = gb.queueFamilyIndex;
        ((PFN_vkCreateCommandPool)gipa(gb.instance, "vkCreateCommandPool"))(gb.device, &pci, nullptr, &pool);
        VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cai.commandPool = pool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = 1;
        ((PFN_vkAllocateCommandBuffers)gipa(gb.instance, "vkAllocateCommandBuffers"))(gb.device, &cai, &cmd);
        VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        ((PFN_vkCreateFence)gipa(gb.instance, "vkCreateFence"))(gb.device, &fci, nullptr, &fence);
        return 0;
    }
    int addSwapchain(int eye, const void* imgs, uint32_t n, int64_t) override {
        if (g_null) return 0;
        auto* im = (const XrSwapchainImageVulkanKHR*)imgs;
        for (uint32_t i = 0; i < n; ++i) images[eye].push_back(im[i].image);
        return 0;
    }
    void draw(int eye, uint32_t idx, int, int, float p) override {
        if (g_null) return;
        VkImage image = images[eye][idx];
        vkResetCommandBuffer(cmd, 0);
        VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        vkBeginCommandBuffer(cmd, &bi);
        VkImageSubresourceRange range{VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        b.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT; b.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        b.oldLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL; b.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        b.image = image; b.subresourceRange = range;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
        VkClearColorValue col{};
        col.float32[0] = 0.4f + 0.4f * p; col.float32[1] = 0.2f; col.float32[3] = 1.0f;
        vkCmdClearColorImage(cmd, image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, &col, 1, &range);
        b.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT; b.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        b.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL; b.newLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
        vkEndCommandBuffer(cmd);
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
        vkResetFences(gb.device, 1, &fence);
        vkQueueSubmit(queue, 1, &si, fence);
        vkWaitForFences(gb.device, 1, &fence, VK_TRUE, 5000000000ull);
    }
};

struct OpenGLR : Renderer {
    XrGraphicsBindingOpenGLWin32KHR gb{XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR};
    std::vector<GLuint> images[2];
    GLuint fbo = 0;
    void (APIENTRY* genFb)(GLsizei, GLuint*) = nullptr;
    void (APIENTRY* bindFb)(GLenum, GLuint) = nullptr;
    void (APIENTRY* fbTex)(GLenum, GLenum, GLenum, GLuint, GLint) = nullptr;
    const char* extension() override { return "XR_KHR_opengl_enable"; }
    XrStructureType bindingType() override { return gb.type; }
    XrStructureType imageType() override { return XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_KHR; }
    size_t imageSize() override { return sizeof(XrSwapchainImageOpenGLKHR); }
    const void* binding() override { return &gb; }
    int setup(XrSystemId sys) override {
        PFN_xrGetOpenGLGraphicsRequirementsKHR fn = nullptr;
        LOAD(fn, "xrGetOpenGLGraphicsRequirementsKHR");
        XrGraphicsRequirementsOpenGLKHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_OPENGL_KHR};
        OK(fn(inst, sys, &rq));
        if (g_null) return 0;
        HWND w = CreateWindowExA(0, "STATIC", "xrb", WS_POPUP, 0, 0, 16, 16, nullptr, nullptr, nullptr, nullptr);
        gb.hDC = GetDC(w);
        PIXELFORMATDESCRIPTOR pfd{};
        pfd.nSize = sizeof(pfd); pfd.nVersion = 1; pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
        pfd.iPixelType = PFD_TYPE_RGBA; pfd.cColorBits = 32;
        SetPixelFormat(gb.hDC, ChoosePixelFormat(gb.hDC, &pfd), &pfd);
        gb.hGLRC = wglCreateContext(gb.hDC);
        if (!gb.hGLRC || !wglMakeCurrent(gb.hDC, gb.hGLRC)) { printf("FAIL could not create an OpenGL context\n"); return 1; }
        genFb = (decltype(genFb))wglGetProcAddress("glGenFramebuffers");
        bindFb = (decltype(bindFb))wglGetProcAddress("glBindFramebuffer");
        fbTex = (decltype(fbTex))wglGetProcAddress("glFramebufferTexture2D");
        if (!genFb || !bindFb || !fbTex) { printf("FAIL this OpenGL driver has no framebuffer objects\n"); return 1; }
        genFb(1, &fbo);
        return 0;
    }
    int addSwapchain(int eye, const void* imgs, uint32_t n, int64_t) override {
        if (g_null) return 0;
        auto* im = (const XrSwapchainImageOpenGLKHR*)imgs;
        for (uint32_t i = 0; i < n; ++i) images[eye].push_back(im[i].image);
        return 0;
    }
    void draw(int eye, uint32_t idx, int w, int h, float p) override {
        if (g_null) return;
        const GLenum FB = 0x8D40, COLOR0 = 0x8CE0;
        bindFb(FB, fbo);
        fbTex(FB, COLOR0, GL_TEXTURE_2D, images[eye][idx], 0);
        glDisable(GL_SCISSOR_TEST);
        glClearColor(0.3f + 0.3f * p, 0.0f, 0.5f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        // In GL the top of the image is at high y. The bridge must keep it on top.
        glEnable(GL_SCISSOR_TEST);
        glScissor(0, h / 2, w, h - h / 2);
        glClearColor(0.9f, 0.9f, 0.9f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glDisable(GL_SCISSOR_TEST);
        bindFb(FB, 0);
    }
};

// ---------------------------------------------------------------- event pump
static int pump() {
    for (;;) {
        XrEventDataBuffer ev{XR_TYPE_EVENT_DATA_BUFFER};
        XrResult r = xrPollEvent(inst, &ev);
        if (r == XR_EVENT_UNAVAILABLE) return 0;
        if (XR_FAILED(r)) { printf("FAIL xrPollEvent %d\n", (int)r); ++g_fail; return 1; }
        if (ev.type == XR_TYPE_EVENT_DATA_DISPLAY_REFRESH_RATE_CHANGED_FB) {
            auto* e = (XrEventDataDisplayRefreshRateChangedFB*)&ev;
            EXPECT(e->fromDisplayRefreshRate == 72.0f && e->toDisplayRefreshRate == 90.0f);
        } else if (ev.type == XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) {
            auto* e = (XrEventDataSessionStateChanged*)&ev;
            state = e->state;
            printf("session state -> %d\n", (int)state);
            if (g_mock) {
                EXPECT((uint64_t)e->session == 0xAB00000000000002ull);
                EXPECT(e->time == 0x0012345678900007ll);
            }
            if (state == XR_SESSION_STATE_READY) {
                XrSessionBeginInfo bi{XR_TYPE_SESSION_BEGIN_INFO};
                bi.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
                OK(xrBeginSession(sess, &bi));
                running = true;
            } else if (state == XR_SESSION_STATE_STOPPING) {
                OK(xrEndSession(sess));
                running = false;
            }
        }
    }
}

static DWORD WINAPI otherThread(LPVOID p) {
    XrInstanceProperties tp{XR_TYPE_INSTANCE_PROPERTIES};
    *(XrResult*)p = xrGetInstanceProperties(inst, &tp);
    return 0;
}

// Calls only needed once, checked against the mock's known values.
static int mockChecks(XrSpace view, XrSpace local, XrTime t, XrAction act, XrPath left, XrSystemId sys) {
    XrSpaceVelocity vel{XR_TYPE_SPACE_VELOCITY};
    XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION, &vel};
    OK(xrLocateSpace(view, local, t, &loc));
    EXPECT(same(loc.pose, pose()) && vel.linearVelocity.y == 5.f && vel.angularVelocity.z == 9.f);

    XrSpace spaces[2] = {view, local};
    XrSpacesLocateInfo sli{XR_TYPE_SPACES_LOCATE_INFO};
    sli.baseSpace = local; sli.time = t; sli.spaceCount = 2; sli.spaces = spaces;
    XrSpaceLocationData ld[2]; XrSpaceVelocityData vd[2];
    XrSpaceVelocities vs{XR_TYPE_SPACE_VELOCITIES}; vs.velocityCount = 2; vs.velocities = vd;
    XrSpaceLocations ls{XR_TYPE_SPACE_LOCATIONS, &vs}; ls.locationCount = 2; ls.locations = ld;
    OK(xrLocateSpaces(sess, &sli, &ls));
    EXPECT(same(ld[1].pose, pose()) && vd[1].linearVelocity.z == 6.f);

    XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO}; gi.action = act; gi.subactionPath = left;
    XrActionStateBoolean bs{XR_TYPE_ACTION_STATE_BOOLEAN};
    OK(xrGetActionStateBoolean(sess, &gi, &bs));
    EXPECT(bs.currentState == XR_TRUE && bs.lastChangeTime == 0x0012345678900009ll && bs.isActive == XR_TRUE);
    XrActionStateFloat fl{XR_TYPE_ACTION_STATE_FLOAT};
    OK(xrGetActionStateFloat(sess, &gi, &fl));
    EXPECT(fl.currentState == 0.625f && fl.lastChangeTime == 0x001234567890000All);
    XrActionStateVector2f v2{XR_TYPE_ACTION_STATE_VECTOR2F};
    OK(xrGetActionStateVector2f(sess, &gi, &v2));
    EXPECT(v2.currentState.y == -0.5f && v2.lastChangeTime == 0x001234567890000Bll);
    XrActionStatePose ps{XR_TYPE_ACTION_STATE_POSE};
    OK(xrGetActionStatePose(sess, &gi, &ps));
    EXPECT(ps.isActive == XR_TRUE);

    XrActionSpaceCreateInfo asi{XR_TYPE_ACTION_SPACE_CREATE_INFO};
    asi.action = act; asi.subactionPath = left; asi.poseInActionSpace = pose();
    XrSpace aspace = XR_NULL_HANDLE;
    OK(xrCreateActionSpace(sess, &asi, &aspace));
    OK(xrDestroySpace(aspace));

    XrHapticVibration hv{XR_TYPE_HAPTIC_VIBRATION};
    hv.duration = 5000000; hv.frequency = 160.f; hv.amplitude = 0.5f;
    XrHapticActionInfo hi{XR_TYPE_HAPTIC_ACTION_INFO}; hi.action = act; hi.subactionPath = left;
    OK(xrApplyHapticFeedback(sess, &hi, (const XrHapticBaseHeader*)&hv));
    OK(xrStopHapticFeedback(sess, &hi));

    XrInteractionProfileState ips{XR_TYPE_INTERACTION_PROFILE_STATE};
    OK(xrGetCurrentInteractionProfile(sess, left, &ips));
    EXPECT(ips.interactionProfile == left);

    XrBoundSourcesForActionEnumerateInfo bi{XR_TYPE_BOUND_SOURCES_FOR_ACTION_ENUMERATE_INFO}; bi.action = act;
    uint32_t bn = 0; XrPath src[2];
    OK(xrEnumerateBoundSourcesForAction(sess, &bi, 2, &bn, src));
    EXPECT(bn == 1);
    XrInputSourceLocalizedNameGetInfo ln{XR_TYPE_INPUT_SOURCE_LOCALIZED_NAME_GET_INFO};
    ln.sourcePath = src[0]; ln.whichComponents = XR_INPUT_SOURCE_LOCALIZED_NAME_USER_PATH_BIT;
    char nm[32]; uint32_t nl = 0;
    OK(xrGetInputSourceLocalizedName(sess, &ln, sizeof(nm), &nl, nm));
    EXPECT(!strcmp(nm, "Trigger"));

    XrExtent2Df bounds{};
    OK(xrGetReferenceSpaceBoundsRect(sess, XR_REFERENCE_SPACE_TYPE_STAGE, &bounds));
    EXPECT(bounds.width == 2.5f && bounds.height == 3.5f);

    PFN_xrGetVisibilityMaskKHR vm = nullptr;
    LOAD(vm, "xrGetVisibilityMaskKHR");
    XrVector2f verts[3]; uint32_t idxs[3];
    XrVisibilityMaskKHR mask{XR_TYPE_VISIBILITY_MASK_KHR};
    mask.vertexCapacityInput = 3; mask.vertices = verts; mask.indexCapacityInput = 3; mask.indices = idxs;
    OK(vm(sess, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 0, XR_VISIBILITY_MASK_TYPE_HIDDEN_TRIANGLE_MESH_KHR, &mask));
    EXPECT(mask.vertexCountOutput == 3 && verts[1].x == 1.f && idxs[2] == 2);

    PFN_xrConvertTimeToWin32PerformanceCounterKHR t2p = nullptr;
    LOAD(t2p, "xrConvertTimeToWin32PerformanceCounterKHR");
    LARGE_INTEGER pc{};
    OK(t2p(inst, 0x0012345678900000ll, &pc));
    EXPECT(pc.QuadPart == 0x0012345678900000ll - 1);

    // Hand tracking
    XrSystemHandTrackingPropertiesEXT hp{XR_TYPE_SYSTEM_HAND_TRACKING_PROPERTIES_EXT};
    XrSystemProperties sp{XR_TYPE_SYSTEM_PROPERTIES, &hp};
    OK(xrGetSystemProperties(inst, sys, &sp));
    EXPECT(hp.supportsHandTracking == XR_TRUE);
    PFN_xrCreateHandTrackerEXT cht = nullptr; PFN_xrDestroyHandTrackerEXT dht = nullptr; PFN_xrLocateHandJointsEXT lhj = nullptr;
    LOAD(cht, "xrCreateHandTrackerEXT"); LOAD(dht, "xrDestroyHandTrackerEXT"); LOAD(lhj, "xrLocateHandJointsEXT");
    XrHandTrackerCreateInfoEXT hci{XR_TYPE_HAND_TRACKER_CREATE_INFO_EXT};
    hci.hand = XR_HAND_RIGHT_EXT; hci.handJointSet = XR_HAND_JOINT_SET_DEFAULT_EXT;
    XrHandTrackerEXT tracker = XR_NULL_HANDLE;
    OK(cht(sess, &hci, &tracker));
    XrHandJointLocationEXT jl[26]; XrHandJointVelocityEXT jv[26];
    XrHandJointVelocitiesEXT jvs{XR_TYPE_HAND_JOINT_VELOCITIES_EXT}; jvs.jointCount = 26; jvs.jointVelocities = jv;
    XrHandJointLocationsEXT jls{XR_TYPE_HAND_JOINT_LOCATIONS_EXT, &jvs}; jls.jointCount = 26; jls.jointLocations = jl;
    XrHandJointsLocateInfoEXT hli{XR_TYPE_HAND_JOINTS_LOCATE_INFO_EXT}; hli.baseSpace = local; hli.time = t;
    OK(lhj(tracker, &hli, &jls));
    EXPECT(jls.isActive == XR_TRUE && same(jl[25].pose, pose()) && jl[25].radius == 0.125f && jv[25].angularVelocity.y == 8.f);
    OK(dht(tracker));

    // Refresh rate
    PFN_xrEnumerateDisplayRefreshRatesFB err = nullptr; PFN_xrGetDisplayRefreshRateFB grr = nullptr; PFN_xrRequestDisplayRefreshRateFB qrr = nullptr;
    LOAD(err, "xrEnumerateDisplayRefreshRatesFB"); LOAD(grr, "xrGetDisplayRefreshRateFB"); LOAD(qrr, "xrRequestDisplayRefreshRateFB");
    uint32_t rc = 0; float rates[2];
    OK(err(sess, 2, &rc, rates));
    EXPECT(rc == 2 && rates[1] == 90.0f);
    float cur = 0;
    OK(grr(sess, &cur));
    EXPECT(cur == 90.0f);
    OK(qrr(sess, 90.0f));

    char rs[XR_MAX_RESULT_STRING_SIZE];
    OK(xrResultToString(inst, XR_SUCCESS, rs));

    // Functions only the generated marshalling knows about.
    PFN_xrPerfSettingsSetPerformanceLevelEXT psl = nullptr;
    LOAD(psl, "xrPerfSettingsSetPerformanceLevelEXT");
    OK(psl(sess, XR_PERF_SETTINGS_DOMAIN_GPU_EXT, XR_PERF_SETTINGS_LEVEL_BOOST_EXT));
    PFN_xrCreateEyeTrackerFB cet = nullptr; PFN_xrDestroyEyeTrackerFB det = nullptr; PFN_xrGetEyeGazesFB geg = nullptr;
    LOAD(cet, "xrCreateEyeTrackerFB"); LOAD(det, "xrDestroyEyeTrackerFB"); LOAD(geg, "xrGetEyeGazesFB");
    XrEyeTrackerCreateInfoFB eci{XR_TYPE_EYE_TRACKER_CREATE_INFO_FB};
    XrEyeTrackerFB et = XR_NULL_HANDLE;
    OK(cet(sess, &eci, &et));
    XrEyeGazesInfoFB egi{XR_TYPE_EYE_GAZES_INFO_FB}; egi.baseSpace = local; egi.time = t;
    XrEyeGazesFB gz{XR_TYPE_EYE_GAZES_FB};
    OK(geg(et, &egi, &gz));
    EXPECT(gz.gaze[1].isValid == XR_TRUE && same(gz.gaze[1].gazePose, pose()) && gz.gaze[1].gazeConfidence == 0.875f && gz.time == 0x0012345678900000ll + 21);
    OK(det(et));

    // Foveated rendering structs on view configuration calls.
    XrFoveatedViewConfigurationViewVARJO fv[2] = {{XR_TYPE_FOVEATED_VIEW_CONFIGURATION_VIEW_VARJO}, {XR_TYPE_FOVEATED_VIEW_CONFIGURATION_VIEW_VARJO}};
    fv[0].foveatedRenderingActive = XR_TRUE;
    XrViewConfigurationView fvv[2] = {{XR_TYPE_VIEW_CONFIGURATION_VIEW, &fv[0]}, {XR_TYPE_VIEW_CONFIGURATION_VIEW, &fv[1]}};
    uint32_t fvn = 0;
    OK(xrEnumerateViewConfigurationViews(inst, sys, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 2, &fvn, fvv));
    EXPECT(fv[0].foveatedRenderingActive == XR_TRUE);
    XrViewLocateFoveatedRenderingVARJO flv{XR_TYPE_VIEW_LOCATE_FOVEATED_RENDERING_VARJO};
    flv.foveatedRenderingActive = XR_TRUE;
    XrViewLocateInfo fli{XR_TYPE_VIEW_LOCATE_INFO, &flv};
    fli.viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO; fli.displayTime = t; fli.space = local;
    XrViewState fvs{XR_TYPE_VIEW_STATE};
    XrView fviews[2] = {{XR_TYPE_VIEW}, {XR_TYPE_VIEW}};
    uint32_t fnv = 0;
    OK(xrLocateViews(sess, &fli, &fvs, 2, &fnv, fviews));

    // Quad views: four views, the inner two narrower, through both view calls.
    {
        XrViewConfigurationView qv[4];
        for (auto& v : qv) v = {XR_TYPE_VIEW_CONFIGURATION_VIEW};
        uint32_t qn = 0;
        OK(xrEnumerateViewConfigurationViews(inst, sys, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_QUAD_VARJO, 4, &qn, qv));
        EXPECT(qn == 4 && qv[3].recommendedImageRectWidth == 64);
        XrViewLocateInfo qli{XR_TYPE_VIEW_LOCATE_INFO, &flv};
        qli.viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_QUAD_VARJO; qli.displayTime = t; qli.space = local;
        XrView qviews[4];
        for (auto& v : qviews) v = {XR_TYPE_VIEW};
        OK(xrLocateViews(sess, &qli, &fvs, 4, &qn, qviews));
        EXPECT(qn == 4 && qviews[2].fov.angleLeft == qviews[0].fov.angleLeft * 0.5f);
    }

    // Several threads must get independent host connections.
    XrResult tr = XR_ERROR_RUNTIME_FAILURE;
    HANDLE th = CreateThread(nullptr, 0, otherThread, &tr, 0, nullptr);
    WaitForSingleObject(th, 5000);
    CloseHandle(th);
    EXPECT(tr == XR_SUCCESS);
    return 0;
}

static std::string nextArg(int& i, int argc, char** argv) { return i + 1 < argc ? argv[++i] : ""; }

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    char e[8];
    g_mock = GetEnvironmentVariableA("XRB_MOCK", e, sizeof(e)) > 0;
    g_null = GetEnvironmentVariableA("XRB_NULL_GFX", e, sizeof(e)) > 0;
    double seconds = g_mock ? 0.5 : 4.0;
    std::string api = "d3d11";
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--api") api = nextArg(i, argc, argv);
        else if (a == "--seconds") seconds = atof(nextArg(i, argc, argv).c_str());
    }
    for (int i = 1; i < argc; ++i) if (!strcmp(argv[i], "--check")) {
        // What a game sees from whichever 32-bit runtime is active. No session, no headset needed.
        uint32_t cnt = 0;
        XrResult r = xrEnumerateInstanceExtensionProperties(nullptr, 0, &cnt, nullptr);
        printf("result %d\n", (int)r);
        std::vector<XrExtensionProperties> list(cnt, {XR_TYPE_EXTENSION_PROPERTIES});
        if (XR_SUCCEEDED(r)) xrEnumerateInstanceExtensionProperties(nullptr, cnt, &cnt, list.data());
        for (auto& x : list) printf("ext %s\n", x.extensionName);
        return 0;
    }
    Renderer* rd = api == "d3d12" ? (Renderer*)new D3D12R : api == "vulkan" ? (Renderer*)new VulkanR : api == "opengl" ? (Renderer*)new OpenGLR : (Renderer*)new D3D11R;
    printf("testing %s\n", rd->extension());

    uint32_t n = 0;
    OK(xrEnumerateInstanceExtensionProperties(nullptr, 0, &n, nullptr));
    std::vector<XrExtensionProperties> exts(n, {XR_TYPE_EXTENSION_PROPERTIES});
    OK(xrEnumerateInstanceExtensionProperties(nullptr, n, &n, exts.data()));
    auto has = [&](const char* name) { for (auto& x : exts) if (!strcmp(x.extensionName, name)) return true; return false; };
    if (!has(rd->extension())) { printf("FAIL %s is not offered (does the 64-bit runtime have XR_KHR_D3D11_enable?)\n", rd->extension()); return 1; }
    EXPECT(has("XR_KHR_D3D11_enable") && has("XR_KHR_D3D12_enable") && has("XR_KHR_opengl_enable") && has("XR_KHR_vulkan_enable") && has("XR_KHR_vulkan_enable2"));
    EXPECT(has("XR_EXT_hand_tracking") && has("XR_FB_display_refresh_rate") && has("XR_KHR_composition_layer_cylinder") && has("XR_KHR_composition_layer_cube"));
    EXPECT(has("XR_KHR_composition_layer_depth") && has("XR_EXT_dpad_binding") && has("XR_VARJO_quad_views") && has("XR_VARJO_foveated_rendering"));
    EXPECT(!has("XR_MNDX_xdev_space") || true);

    std::vector<const char*> en = {rd->extension()};
    if (has("XR_KHR_visibility_mask")) en.push_back("XR_KHR_visibility_mask");
    if (has("XR_KHR_win32_convert_performance_counter")) en.push_back("XR_KHR_win32_convert_performance_counter");
    if (g_mock) for (auto* x : {"XR_EXT_hand_tracking", "XR_FB_display_refresh_rate", "XR_KHR_composition_layer_cylinder", "XR_KHR_composition_layer_equirect2", "XR_KHR_composition_layer_cube", "XR_EXT_debug_utils",
        "XR_KHR_composition_layer_depth", "XR_VARJO_foveated_rendering", "XR_VARJO_quad_views", "XR_EXT_performance_settings", "XR_FB_eye_tracking_social", "XR_KHR_binding_modification", "XR_VALVE_analog_threshold",
        "XR_FB_swapchain_update_state", "XR_FB_foveation", "XR_FB_foveation_configuration"}) en.push_back(x);
    XrInstanceCreateInfo ici{XR_TYPE_INSTANCE_CREATE_INFO};
    strcpy(ici.applicationInfo.applicationName, "XRBridge32 selftest");
    ici.applicationInfo.applicationVersion = 1;
    ici.applicationInfo.apiVersion = g_mock ? XR_MAKE_VERSION(1, 1, 0) : XR_MAKE_VERSION(1, 0, 0);
    ici.enabledExtensionCount = (uint32_t)en.size();
    ici.enabledExtensionNames = en.data();
    OK(xrCreateInstance(&ici, &inst));

    XrInstanceProperties ip{XR_TYPE_INSTANCE_PROPERTIES};
    OK(xrGetInstanceProperties(inst, &ip));
    printf("runtime: %s\n", ip.runtimeName);
    EXPECT(strstr(ip.runtimeName, "XRBridge32") && strstr(ip.runtimeName, "MockRuntime"));
    EXPECT(ip.runtimeVersion == XR_MAKE_VERSION(9, 8, 7));

    XrSystemGetInfo sgi{XR_TYPE_SYSTEM_GET_INFO};
    sgi.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    XrSystemId sys = 0;
    OK(xrGetSystem(inst, &sgi, &sys));
    EXPECT(sys == 0xCD00000000000042ull);
    XrSystemProperties sp{XR_TYPE_SYSTEM_PROPERTIES};
    OK(xrGetSystemProperties(inst, sys, &sp));
    printf("system: %s\n", sp.systemName);
    EXPECT(!strcmp(sp.systemName, "MockHMD") && sp.vendorId == 0x1234 && sp.graphicsProperties.maxLayerCount == 16 && sp.trackingProperties.orientationTracking == XR_TRUE);

    uint32_t vcount = 0;
    OK(xrEnumerateViewConfigurationViews(inst, sys, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 0, &vcount, nullptr));
    std::vector<XrViewConfigurationView> vcv(vcount, {XR_TYPE_VIEW_CONFIGURATION_VIEW});
    OK(xrEnumerateViewConfigurationViews(inst, sys, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, vcount, &vcount, vcv.data()));
    EXPECT(vcount == 2 && vcv[1].recommendedImageRectWidth == 64 && vcv[1].maxImageRectHeight == 144 && vcv[1].maxSwapchainSampleCount == 4);
    printf("eye size %ux%u\n", vcv[0].recommendedImageRectWidth, vcv[0].recommendedImageRectHeight);

    if (rd->setup(sys)) return 1;
    // In null mode the renderer holds a zeroed binding: only its type matters here.
    XrSessionCreateInfo sci{XR_TYPE_SESSION_CREATE_INFO, rd->binding(), 0, sys};
    OK(xrCreateSession(inst, &sci, &sess));

    uint32_t fc = 0;
    OK(xrEnumerateSwapchainFormats(sess, 0, &fc, nullptr));
    std::vector<int64_t> fmts(fc);
    OK(xrEnumerateSwapchainFormats(sess, fc, &fc, fmts.data()));
    if (fc == 0) { printf("FAIL no usable colour formats\n"); return 1; }
    // Each API must see its own names for the same formats, in the runtime's order.
    if (api == "vulkan") EXPECT(fc == 4 && fmts[0] == 43 && fmts[1] == 126 && fmts[2] == 37 && fmts[3] == 129);
    else if (api == "opengl") EXPECT(fc == 4 && fmts[0] == 0x8C43 && fmts[1] == 0x8CAC && fmts[2] == 0x8058 && fmts[3] == 0x88F0);
    else EXPECT(fc == 4 && fmts[0] == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB && fmts[1] == DXGI_FORMAT_D32_FLOAT && fmts[2] == DXGI_FORMAT_R8G8B8A8_UNORM);

    XrReferenceSpaceCreateInfo rsi{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
    rsi.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_LOCAL;
    rsi.poseInReferenceSpace = {{0, 0, 0, 1}, {0, 0, 0}};
    XrSpace local = XR_NULL_HANDLE, view = XR_NULL_HANDLE;
    OK(xrCreateReferenceSpace(sess, &rsi, &local));
    rsi.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_VIEW;
    OK(xrCreateReferenceSpace(sess, &rsi, &view));
    EXPECT(((uint64_t)local >> 56) == 0xAB);

    XrPath left = 0, right = 0, profile = 0, b1 = 0, b2 = 0;
    OK(xrStringToPath(inst, "/user/hand/left", &left));
    OK(xrStringToPath(inst, "/user/hand/right", &right));
    OK(xrStringToPath(inst, "/interaction_profiles/khr/simple_controller", &profile));
    OK(xrStringToPath(inst, "/user/hand/left/input/select/click", &b1));
    OK(xrStringToPath(inst, "/user/hand/right/input/select/click", &b2));
    char pbuf[64]; uint32_t plen = 0;
    OK(xrPathToString(inst, right, sizeof(pbuf), &plen, pbuf));
    EXPECT(!strcmp(pbuf, "/user/hand/right"));

    XrActionSetCreateInfo asci{XR_TYPE_ACTION_SET_CREATE_INFO};
    strcpy(asci.actionSetName, "bridge_test"); strcpy(asci.localizedActionSetName, "Bridge test");
    asci.priority = 3;
    XrActionSet aset = XR_NULL_HANDLE;
    OK(xrCreateActionSet(inst, &asci, &aset));
    XrPath subs[2] = {left, right};
    XrActionCreateInfo aci{XR_TYPE_ACTION_CREATE_INFO};
    strcpy(aci.actionName, "select"); strcpy(aci.localizedActionName, "Select");
    aci.actionType = XR_ACTION_TYPE_BOOLEAN_INPUT;
    aci.countSubactionPaths = 2; aci.subactionPaths = subs;
    XrAction act = XR_NULL_HANDLE;
    OK(xrCreateAction(aset, &aci, &act));
    XrActionSuggestedBinding bind[2] = {{act, b1}, {act, b2}};
    XrInteractionProfileSuggestedBinding sb{XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING};
    sb.interactionProfile = profile; sb.countSuggestedBindings = 2; sb.suggestedBindings = bind;
    // Pointers to pointers inside a chain: the hardest shape the marshalling has to carry.
    XrInteractionProfileAnalogThresholdVALVE analog{XR_TYPE_INTERACTION_PROFILE_ANALOG_THRESHOLD_VALVE};
    analog.action = act; analog.binding = b1; analog.onThreshold = 0.75f; analog.offThreshold = 0.5f;
    const XrBindingModificationBaseHeaderKHR* mods[1] = {(const XrBindingModificationBaseHeaderKHR*)&analog};
    XrBindingModificationsKHR bm{XR_TYPE_BINDING_MODIFICATIONS_KHR};
    bm.bindingModificationCount = 1; bm.bindingModifications = mods;
    if (g_mock) sb.next = &bm;
    OK(xrSuggestInteractionProfileBindings(inst, &sb));
    XrSessionActionSetsAttachInfo att{XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO};
    att.countActionSets = 1; att.actionSets = &aset;
    OK(xrAttachSessionActionSets(sess, &att));

    int64_t fmt = fmts[0];
    XrSwapchain chains[2] = {};
    for (int eye = 0; eye < 2; ++eye) {
        XrSwapchainCreateInfo sc{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        sc.usageFlags = XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
        sc.format = fmt; sc.sampleCount = 1;
        sc.width = vcv[eye].recommendedImageRectWidth; sc.height = vcv[eye].recommendedImageRectHeight;
        sc.faceCount = 1; sc.arraySize = 1; sc.mipCount = 1;
        OK(xrCreateSwapchain(sess, &sc, &chains[eye]));
        uint32_t ic = 0;
        OK(xrEnumerateSwapchainImages(chains[eye], 0, &ic, nullptr));
        std::vector<uint8_t> buf(ic * rd->imageSize());
        for (uint32_t i = 0; i < ic; ++i) ((XrSwapchainImageBaseHeader*)(buf.data() + i * rd->imageSize()))->type = rd->imageType();
        OK(xrEnumerateSwapchainImages(chains[eye], ic, &ic, (XrSwapchainImageBaseHeader*)buf.data()));
        EXPECT(ic == 3);
        if (g_null) {
            // The stride of each API's image struct: the third image must hold fake id 3.
            uint64_t third = 0;
            if (api == "vulkan") third = (uint64_t)((XrSwapchainImageVulkanKHR*)buf.data())[2].image;
            else if (api == "opengl") third = ((XrSwapchainImageOpenGLKHR*)buf.data())[2].image;
            else if (api == "d3d12") third = (uint64_t)(uintptr_t)((XrSwapchainImageD3D12KHR*)buf.data())[2].texture;
            else third = (uint64_t)(uintptr_t)((XrSwapchainImageD3D11KHR*)buf.data())[2].texture;
            EXPECT(third == 3);
        }
        if (rd->addSwapchain(eye, buf.data(), ic, fmt)) return 1;
    }

    XrSwapchain depthChain = XR_NULL_HANDLE;
    if (g_mock && g_null) {
        XrSwapchainCreateInfo dc{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        dc.usageFlags = XR_SWAPCHAIN_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
        dc.format = fmts[1]; dc.sampleCount = 1; dc.width = 64; dc.height = 72; dc.faceCount = 1; dc.arraySize = 1; dc.mipCount = 1;
        OK(xrCreateSwapchain(sess, &dc, &depthChain));
        if (g_mock) {
            // FB foveation: create a profile, apply it to an eye swapchain, read it back,
            // and a state type that cannot cross is refused before it leaves the game.
            PFN_xrCreateFoveationProfileFB cfp = nullptr; PFN_xrDestroyFoveationProfileFB dfp = nullptr;
            PFN_xrUpdateSwapchainFB usc = nullptr; PFN_xrGetSwapchainStateFB gss = nullptr;
            LOAD(cfp, "xrCreateFoveationProfileFB"); LOAD(dfp, "xrDestroyFoveationProfileFB");
            LOAD(usc, "xrUpdateSwapchainFB"); LOAD(gss, "xrGetSwapchainStateFB");
            XrFoveationLevelProfileCreateInfoFB lv{XR_TYPE_FOVEATION_LEVEL_PROFILE_CREATE_INFO_FB};
            lv.level = XR_FOVEATION_LEVEL_HIGH_FB; lv.verticalOffset = 0.25f; lv.dynamic = XR_FOVEATION_DYNAMIC_LEVEL_ENABLED_FB;
            XrFoveationProfileCreateInfoFB pci{XR_TYPE_FOVEATION_PROFILE_CREATE_INFO_FB, &lv};
            XrFoveationProfileFB prof = XR_NULL_HANDLE;
            OK(cfp(sess, &pci, &prof));
            XrSwapchainStateFoveationFB fst{XR_TYPE_SWAPCHAIN_STATE_FOVEATION_FB};
            fst.profile = prof;
            OK(usc(chains[0], (XrSwapchainStateBaseHeaderFB*)&fst));
            XrSwapchainStateFoveationFB back{XR_TYPE_SWAPCHAIN_STATE_FOVEATION_FB};
            OK(gss(chains[0], (XrSwapchainStateBaseHeaderFB*)&back));
            EXPECT(back.profile == prof);
            XrSwapchainStateBaseHeaderFB android{(XrStructureType)1000071000}; // XR_TYPE_SWAPCHAIN_STATE_ANDROID_SURFACE_DIMENSIONS_FB
            EXPECT(usc(chains[0], &android) == XR_ERROR_VALIDATION_FAILURE);
            OK(dfp(prof));
        }
    }
    XrCompositionLayerDepthInfoKHR depthInfo[2] = {{XR_TYPE_COMPOSITION_LAYER_DEPTH_INFO_KHR}, {XR_TYPE_COMPOSITION_LAYER_DEPTH_INFO_KHR}};

    ULONGLONG start = GetTickCount64();
    int frames = 0;
    bool asked = false, checksDone = false;
    while (state != XR_SESSION_STATE_EXITING && GetTickCount64() - start < (ULONGLONG)(seconds * 1000) + 15000) {
        if (pump()) return 1;
        if (!asked && GetTickCount64() - start > seconds * 1000 && running) {
            OK(xrRequestExitSession(sess));
            asked = true;
        }
        if (!running) { Sleep(10); continue; }

        XrFrameState fs{XR_TYPE_FRAME_STATE};
        OK(xrWaitFrame(sess, nullptr, &fs));
        OK(xrBeginFrame(sess, nullptr));
        EXPECT(fs.predictedDisplayPeriod == 11111111 && fs.shouldRender == XR_TRUE);

        XrActiveActionSet active{aset, XR_NULL_PATH};
        XrActionsSyncInfo si{XR_TYPE_ACTIONS_SYNC_INFO};
        si.countActiveActionSets = 1; si.activeActionSets = &active;
        OK(xrSyncActions(sess, &si));

        XrCompositionLayerProjectionView pv[2] = {{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}, {XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}};
        XrCompositionLayerProjection layer{XR_TYPE_COMPOSITION_LAYER_PROJECTION};
        const XrCompositionLayerBaseHeader* layers[5];
        uint32_t layerCount = 0;
        if (fs.shouldRender) {
            XrViewLocateInfo li{XR_TYPE_VIEW_LOCATE_INFO};
            li.viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
            li.displayTime = fs.predictedDisplayTime; li.space = local;
            XrViewState vs{XR_TYPE_VIEW_STATE};
            XrView views[2] = {{XR_TYPE_VIEW}, {XR_TYPE_VIEW}};
            uint32_t nv = 0;
            OK(xrLocateViews(sess, &li, &vs, 2, &nv, views));
            EXPECT(nv == 2 && same(views[1].pose, pose()) && views[1].fov.angleDown == -1.0f && views[0].fov.angleLeft == -0.75f);
            float pulse = 0.5f + 0.5f * sinf((float)((GetTickCount64() - start) / 1000.0) * 3.0f);
            for (int eye = 0; eye < 2; ++eye) {
                uint32_t idx = 0;
                OK(xrAcquireSwapchainImage(chains[eye], nullptr, &idx));
                XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
                wi.timeout = g_mock ? 123456789 : XR_INFINITE_DURATION;
                OK(xrWaitSwapchainImage(chains[eye], &wi));
                rd->draw(eye, idx, (int)vcv[eye].recommendedImageRectWidth, (int)vcv[eye].recommendedImageRectHeight, pulse);
                OK(xrReleaseSwapchainImage(chains[eye], nullptr));
                pv[eye].pose = views[eye].pose;
                pv[eye].fov = views[eye].fov;
                pv[eye].subImage.swapchain = chains[eye];
                pv[eye].subImage.imageRect = {{0, 0}, {(int32_t)vcv[eye].recommendedImageRectWidth, (int32_t)vcv[eye].recommendedImageRectHeight}};
                if (depthChain) {
                    depthInfo[eye].subImage.swapchain = depthChain;
                    depthInfo[eye].subImage.imageRect = pv[eye].subImage.imageRect;
                    depthInfo[eye].minDepth = 0; depthInfo[eye].maxDepth = 1; depthInfo[eye].nearZ = 0.25f; depthInfo[eye].farZ = 500.0f;
                    pv[eye].next = &depthInfo[eye];
                }
            }
            layer.space = local; layer.viewCount = 2; layer.views = pv;
            layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&layer;
        }
        XrFrameEndInfo fe{XR_TYPE_FRAME_END_INFO};
        fe.displayTime = fs.predictedDisplayTime;
        fe.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
        XrCompositionLayerQuad q{XR_TYPE_COMPOSITION_LAYER_QUAD};
        XrCompositionLayerCylinderKHR cy{XR_TYPE_COMPOSITION_LAYER_CYLINDER_KHR};
        XrCompositionLayerEquirect2KHR eq{XR_TYPE_COMPOSITION_LAYER_EQUIRECT2_KHR};
        XrCompositionLayerCubeKHR cu{XR_TYPE_COMPOSITION_LAYER_CUBE_KHR};
        if (g_mock) {
            q.space = local; q.eyeVisibility = XR_EYE_VISIBILITY_BOTH; q.subImage.swapchain = chains[0];
            q.pose = pose(); q.size = {1.25f, 0.75f};
            q.subImage.imageRect = {{0, 10}, {64, 20}}; // on a 72-row image; GL must arrive mirrored as y=42
            layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&q;
            cy.space = local; cy.subImage.swapchain = chains[0]; cy.pose = pose(); cy.radius = 2.5f; cy.centralAngle = 1.5f; cy.aspectRatio = 0.75f;
            layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&cy;
            eq.space = local; eq.subImage.swapchain = chains[0]; eq.pose = pose(); eq.radius = 3.5f; eq.lowerVerticalAngle = -0.5f;
            layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&eq;
            cu.space = local; cu.swapchain = chains[0]; cu.imageArrayIndex = 0; cu.orientation = {0.5f, 0.25f, 0.125f, 0.0625f};
            layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&cu;
        }
        fe.layerCount = layerCount; fe.layers = layers;
        OK(xrEndFrame(sess, &fe));
        ++frames;

        if (g_mock && !checksDone) {
            checksDone = true;
            if (mockChecks(view, local, fs.predictedDisplayTime, act, left, sys)) return 1;
            if (GetEnvironmentVariableA("XRB_BENCH", e, sizeof(e))) {
                // Measures the cost of the bridge itself: one call that does nothing in the mock.
                LARGE_INTEGER f, a, b;
                QueryPerformanceFrequency(&f);
                XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO}; gi.action = act; gi.subactionPath = left;
                XrActionStateBoolean bs{XR_TYPE_ACTION_STATE_BOOLEAN};
                const int count = 200000;
                QueryPerformanceCounter(&a);
                for (int i = 0; i < count; ++i) xrGetActionStateBoolean(sess, &gi, &bs);
                QueryPerformanceCounter(&b);
                printf("BENCH %.2f us per call\n", (double)(b.QuadPart - a.QuadPart) * 1e6 / f.QuadPart / count);
            }
        }
    }
    printf("frames submitted: %d\n", frames);
    if (frames == 0 || state != XR_SESSION_STATE_EXITING) { printf("FAIL session did not run and exit cleanly (state %d)\n", (int)state); ++g_fail; }

    if (depthChain) OK(xrDestroySwapchain(depthChain));
    OK(xrDestroySwapchain(chains[0]));
    OK(xrDestroySwapchain(chains[1]));
    OK(xrDestroySpace(view));
    OK(xrDestroySpace(local));
    OK(xrDestroyAction(act));
    OK(xrDestroyActionSet(aset));
    OK(xrDestroySession(sess));
    OK(xrDestroyInstance(inst));
    printf("%s: %s, %d checks passed, %d failed\n", g_fail ? "FAILED" : "PASSED", api.c_str(), g_pass, g_fail);
    return g_fail ? 1 : 0;
}
