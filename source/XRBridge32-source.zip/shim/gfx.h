// Game-side graphics backends. The host always owns the textures and always talks
// D3D11 to the real runtime; each backend opens those textures with the game's API.
#pragma once
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#define XR_USE_GRAPHICS_API_D3D12
#define XR_USE_GRAPHICS_API_VULKAN
#define XR_USE_GRAPHICS_API_OPENGL
#define VK_USE_PLATFORM_WIN32_KHR
#define VK_NO_PROTOTYPES
#include <windows.h>
#include <unknwn.h>
#include <d3d11_4.h>
#include <d3d12.h>
#include <dxgi1_2.h>
#include <vulkan/vulkan.h>
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <cstdint>
#include <vector>

void logf(const char* fmt, ...);

struct SwapchainInfo {
    uint32_t width, height, arraySize, faceCount, mipCount, sampleCount;
    uint64_t usage;
    int64_t appFormat; // in the game API's own format enum
    int dxgiFormat;
    bool ntHandles; // NT handles (closed by the shim after open) rather than legacy shared handles
};

// One swapchain's images, as the game sees them.
class GfxImages {
public:
    virtual ~GfxImages() {}
    virtual void fill(XrSwapchainImageBaseHeader* out, uint32_t count) = 0;
    // Called in xrAcquireSwapchainImage, one of the few calls where OpenXR lets a runtime use
    // the app's graphics queue.
    virtual void onAcquire() {}
    // Last chance to touch the image on the game's API before the host copies it.
    virtual void onRelease(uint32_t) {}
};

class GfxSession {
public:
    virtual ~GfxSession() {}
    virtual const char* name() const = 0;
    virtual XrStructureType imageType() const = 0;
    // Translate between the API's format enum and DXGI. Negative or zero means no mapping.
    virtual int64_t appFormat(int dxgi) const = 0;
    virtual int dxgiFormat(int64_t app) const = 0;
    // `fence` is an NT handle owned by this process, or null when the host has none.
    virtual XrResult init(HANDLE fence, const LUID& hostAdapter) = 0;
    virtual XrResult open(const SwapchainInfo& info, const std::vector<uint64_t>& handles, GfxImages** out) = 0;
    // Makes all submitted work visible to the host. Returns a fence value for the host
    // to wait on, or 0 after waiting on the CPU because no shared fence is available.
    virtual uint64_t sync() = 0;
    // True when the game's image rows run bottom-up, so sub-image rects need converting.
    virtual bool bottomUp() const { return false; }
    // D3D12 can only open NT handles, and they are the handle type Vulkan drivers support
    // most widely. D3D11 and OpenGL stay on legacy handles, which every driver accepts.
    virtual bool prefersNtHandles() const { return false; }
};

GfxSession* makeD3D11Session(const XrGraphicsBindingD3D11KHR& b);
GfxSession* makeD3D12Session(const XrGraphicsBindingD3D12KHR& b);
GfxSession* makeVulkanSession(const XrGraphicsBindingVulkanKHR& b);
GfxSession* makeOpenGLSession(const XrGraphicsBindingOpenGLWin32KHR& b);
GfxSession* makeNullSession(XrStructureType bindingType); // test mode, no GPU work

// Vulkan helpers behind the XR_KHR_vulkan_enable entry points.
PFN_vkGetInstanceProcAddr vkLoaderProc();
void vkSetLoaderProc(PFN_vkGetInstanceProcAddr fn);
XrResult vkPickPhysicalDevice(VkInstance instance, const LUID& luid, VkPhysicalDevice* out);
extern const char* const kVkInstanceExtensions;
extern const char* const kVkDeviceExtensions;
