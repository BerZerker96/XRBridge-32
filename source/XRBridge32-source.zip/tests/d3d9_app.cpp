// Stands in for a flat D3D9 game: red frames, a device Reset at a new size, then blue frames.
#include <windows.h>
#include <d3d9.h>
#include <cstdio>
int main() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    HMODULE m = LoadLibraryA("d3d9.dll");
    auto create = (IDirect3D9*(WINAPI*)(UINT))GetProcAddress(m, "Direct3DCreate9");
    if (!create) { printf("FAIL no Direct3DCreate9\n"); return 1; }
    char mod[MAX_PATH]; GetModuleFileNameA(m, mod, MAX_PATH); printf("d3d9 module: %s\n", mod);
    printf("proxy marker export: %s\n", GetProcAddress(m, "XRBridgeD3D9Proxy") ? "yes" : "no");
    IDirect3D9* d3d = create(D3D_SDK_VERSION);
    if (!d3d) { printf("FAIL Direct3DCreate9\n"); return 1; }
    HWND w = CreateWindowExA(0, "STATIC", "game", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 1280, 768, nullptr, nullptr, nullptr, nullptr);
    D3DPRESENT_PARAMETERS pp{};
    pp.Windowed = TRUE; pp.SwapEffect = D3DSWAPEFFECT_DISCARD; pp.BackBufferFormat = D3DFMT_X8R8G8B8;
    pp.BackBufferWidth = 1280; pp.BackBufferHeight = 768; pp.hDeviceWindow = w;
    IDirect3DDevice9* dev = nullptr;
    HRESULT hr = d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, w, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &pp, &dev);
    if (FAILED(hr)) { printf("FAIL CreateDevice 0x%08lx\n", hr); return 1; }
    auto run = [&](D3DCOLOR c, int ms) {
        DWORD start = GetTickCount();
        int frames = 0;
        while (GetTickCount() - start < (DWORD)ms) {
            dev->Clear(0, nullptr, D3DCLEAR_TARGET, c, 1.0f, 0);
            HRESULT p = dev->Present(nullptr, nullptr, nullptr, nullptr);
            if (FAILED(p)) { printf("FAIL Present 0x%08lx\n", p); return false; }
            ++frames;
            Sleep(4);
        }
        printf("presented %d frames\n", frames);
        return true;
    };
    if (!run(D3DCOLOR_XRGB(255, 0, 0), 1500)) return 1;
    pp.BackBufferWidth = 1024; pp.BackBufferHeight = 640;
    hr = dev->Reset(&pp);
    if (FAILED(hr)) { printf("FAIL Reset 0x%08lx\n", hr); return 1; }
    printf("reset ok\n");
    if (!run(D3DCOLOR_XRGB(0, 0, 255), 1000)) return 1;
    dev->Release();
    d3d->Release();
    printf("D3D9-OK\n");
    return 0;
}
