// Dark themed, DPI-aware window for XRBridge32-Setup. Included by setup.cpp.
// Everything visible is drawn here rather than by the system theme, because Win32 has
// no dark theme for standard buttons and check boxes.

enum { ID_INSTALL = 1, ID_ENABLE, ID_DISABLE, ID_TEST, ID_UNINSTALL, ID_LOG, ID_FORCE, ID_OPENVR, ID_REFRESH, ID_D3D9, ID_ZEROCOPY };

static const COLORREF C_BG = RGB(17, 19, 26), C_PANEL = RGB(25, 28, 38), C_PANEL2 = RGB(33, 37, 49), C_EDGE = RGB(52, 57, 74);
static const COLORREF C_TEXT = RGB(232, 234, 240), C_DIM = RGB(146, 152, 170), C_ACCENT = RGB(64, 196, 186), C_ACCENT_HOT = RGB(92, 222, 212);
static const COLORREF C_GOOD = RGB(74, 208, 132), C_WARN = RGB(240, 186, 82), C_BAD = RGB(240, 96, 96), C_OFF = RGB(112, 118, 136);

static HWND g_buttons[5], g_refresh, g_d3d9, g_force, g_openvr, g_zerocopy;
static HFONT g_fontBody, g_fontBold, g_fontTitle, g_fontMono;
static HBRUSH g_brushLog;
static HICON g_iconLarge;
static UINT g_dpi = 96;
static bool g_busy, g_forceOn, g_openvrOn = true, g_zeroCopyOn;
static HWND g_hot;
static int g_panelTop, g_panelBottom;

static int S(int v) { return MulDiv(v, (int)g_dpi, 96); }

static UINT dpiOf(HWND h) {
    typedef UINT(WINAPI * Fn)(HWND);
    static Fn fn = (Fn)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");
    if (fn) { UINT d = fn(h); if (d) return d; }
    HDC dc = GetDC(h);
    UINT d = (UINT)GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(h, dc);
    return d ? d : 96;
}

static void makeFonts() {
    for (HFONT f : {g_fontBody, g_fontBold, g_fontTitle, g_fontMono}) if (f) DeleteObject(f);
    auto mk = [](int pt, int weight, const wchar_t* face) {
        return CreateFontW(-MulDiv(pt, (int)g_dpi, 72), 0, 0, 0, weight, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, face);
    };
    g_fontBody = mk(10, FW_NORMAL, L"Segoe UI");
    g_fontBold = mk(10, FW_SEMIBOLD, L"Segoe UI");
    g_fontTitle = mk(17, FW_SEMIBOLD, L"Segoe UI");
    g_fontMono = mk(9, FW_NORMAL, L"Consolas");
}

static void fillRound(HDC dc, const RECT& r, int radius, COLORREF fill, COLORREF edge) {
    HBRUSH b = CreateSolidBrush(fill);
    HPEN p = CreatePen(PS_SOLID, 1, edge);
    HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, p);
    RoundRect(dc, r.left, r.top, r.right, r.bottom, radius, radius);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(b); DeleteObject(p);
}

static void textIn(HDC dc, const wchar_t* t, RECT r, HFONT f, COLORREF c, UINT flags) {
    HGDIOBJ of = SelectObject(dc, f);
    SetTextColor(dc, c);
    SetBkMode(dc, TRANSPARENT);
    DrawTextW(dc, t, -1, &r, flags | DT_NOPREFIX);
    SelectObject(dc, of);
}

static COLORREF levelColor(int level) {
    return level == LVL_GOOD ? C_GOOD : level == LVL_WARN ? C_WARN : level == LVL_BAD ? C_BAD : C_OFF;
}

static void paintMain(HWND h, HDC dc) {
    RECT rc;
    GetClientRect(h, &rc);
    HBRUSH bg = CreateSolidBrush(C_BG);
    FillRect(dc, &rc, bg);
    DeleteObject(bg);

    // Header
    DrawIconEx(dc, S(18), S(16), g_iconLarge, S(44), S(44), 0, nullptr, DI_NORMAL);
    RECT t = {S(74), S(14), rc.right - S(150), S(42)};
    textIn(dc, L"XRBridge32", t, g_fontTitle, C_TEXT, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    t = {S(74), S(41), rc.right - S(18), S(62)};
    textIn(dc, L"32-bit VR games and SteamVR titles on native 64-bit OpenXR", t, g_fontBody, C_DIM, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

    // Status panel
    std::vector<StatusRow> rows;
    {
        std::lock_guard<std::mutex> l(g_stateMutex);
        rows = g_rows;
    }
    RECT panel = {S(18), g_panelTop, rc.right - S(18), g_panelBottom};
    fillRound(dc, panel, S(10), C_PANEL, C_EDGE);
    int y = g_panelTop + S(9);
    const int rowH = S(25);
    for (auto& row : rows) {
        HBRUSH dot = CreateSolidBrush(levelColor(row.level));
        HPEN np = CreatePen(PS_SOLID, 1, levelColor(row.level));
        HGDIOBJ ob = SelectObject(dc, dot), op = SelectObject(dc, np);
        Ellipse(dc, S(32), y + S(8), S(41), y + S(17));
        SelectObject(dc, ob); SelectObject(dc, op);
        DeleteObject(dot); DeleteObject(np);
        RECT lr = {S(50), y, S(218), y + rowH};
        textIn(dc, row.label.c_str(), lr, g_fontBody, C_DIM, DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);
        RECT vr = {S(222), y, panel.right - S(14), y + rowH};
        textIn(dc, row.value.c_str(), vr, g_fontBold, row.level == LVL_BAD || row.level == LVL_WARN ? levelColor(row.level) : C_TEXT,
               DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_PATH_ELLIPSIS);
        y += rowH;
    }
}

static void drawButton(const DRAWITEMSTRUCT* d) {
    HDC dc = d->hDC;
    RECT r = d->rcItem;
    int id = (int)d->CtlID;
    bool hot = g_hot == d->hwndItem && !g_busy;
    bool pressed = d->itemState & ODS_SELECTED;
    bool disabled = d->itemState & ODS_DISABLED;
    bool focus = (d->itemState & ODS_FOCUS) && !(d->itemState & ODS_NOFOCUSRECT);
    wchar_t text[96];
    GetWindowTextW(d->hwndItem, text, 96);

    HBRUSH bg = CreateSolidBrush(C_BG);
    FillRect(dc, &r, bg);
    DeleteObject(bg);

    if (id == ID_FORCE || id == ID_OPENVR || id == ID_ZEROCOPY) {
        bool on = id == ID_FORCE ? g_forceOn : id == ID_ZEROCOPY ? g_zeroCopyOn : g_openvrOn;
        int box = S(16), top = (r.bottom - box) / 2;
        RECT b = {r.left + S(1), top, r.left + S(1) + box, top + box};
        fillRound(dc, b, S(5), on ? (disabled ? C_OFF : C_ACCENT) : C_PANEL2, on ? (disabled ? C_OFF : C_ACCENT) : (hot ? C_ACCENT : C_EDGE));
        if (on) {
            HPEN p = CreatePen(PS_SOLID, S(2), C_BG);
            HGDIOBJ op = SelectObject(dc, p);
            MoveToEx(dc, b.left + S(4), b.top + S(8), nullptr);
            LineTo(dc, b.left + S(7), b.top + S(11));
            LineTo(dc, b.left + S(12), b.top + S(5));
            SelectObject(dc, op);
            DeleteObject(p);
        }
        RECT tr = {b.right + S(8), r.top, r.right, r.bottom};
        textIn(dc, text, tr, g_fontBody, disabled ? C_OFF : C_TEXT, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
    } else {
        bool primary = id == ID_ENABLE, danger = id == ID_UNINSTALL;
        COLORREF fill = primary ? (hot ? C_ACCENT_HOT : C_ACCENT) : (hot ? C_EDGE : C_PANEL2);
        COLORREF edge = primary ? fill : (danger && hot ? C_BAD : C_EDGE);
        COLORREF ink = primary ? RGB(8, 28, 28) : (danger && hot ? C_BAD : C_TEXT);
        if (pressed) { fill = primary ? C_ACCENT : C_PANEL; }
        if (disabled) { fill = C_PANEL; edge = C_PANEL2; ink = C_OFF; }
        RECT b = {r.left, r.top, r.right, r.bottom};
        fillRound(dc, b, S(8), fill, edge);
        textIn(dc, text, r, primary ? g_fontBold : g_fontBody, ink, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
    }
    if (focus) {
        RECT f = r;
        InflateRect(&f, -S(2), -S(2));
        SetTextColor(dc, C_TEXT);
        SetBkColor(dc, C_BG);
        DrawFocusRect(dc, &f);
    }
}

// Tracks hover so owner-drawn controls can light up.
static LRESULT CALLBACK hoverProc(HWND h, UINT m, WPARAM w, LPARAM l, UINT_PTR, DWORD_PTR) {
    if (m == WM_MOUSEMOVE && g_hot != h) {
        HWND old = g_hot;
        g_hot = h;
        if (old) InvalidateRect(old, nullptr, FALSE);
        InvalidateRect(h, nullptr, FALSE);
        TRACKMOUSEEVENT t{sizeof(t), TME_LEAVE, h, 0};
        TrackMouseEvent(&t);
    } else if (m == WM_MOUSELEAVE && g_hot == h) {
        g_hot = nullptr;
        InvalidateRect(h, nullptr, FALSE);
    } else if (m == WM_ERASEBKGND) {
        return 1;
    } else if (m == WM_LBUTTONDBLCLK) {
        m = WM_LBUTTONDOWN; // quick repeat clicks should count, not be swallowed
    }
    return DefSubclassProc(h, m, w, l);
}

static void layout(HWND h) {
    RECT rc;
    GetClientRect(h, &rc);
    int rows;
    {
        std::lock_guard<std::mutex> l(g_stateMutex);
        rows = (int)g_rows.size();
    }
    if (rows < 5) rows = 5;
    g_panelTop = S(74);
    g_panelBottom = g_panelTop + S(18) + rows * S(25);
    int y = g_panelBottom + S(14);
    const int widths[5] = {84, 84, 84, 140, 92};
    int x = S(18);
    for (int i = 0; i < 5; ++i) {
        MoveWindow(g_buttons[i], x, y, S(widths[i]), S(36), TRUE);
        x += S(widths[i]) + S(8);
    }
    MoveWindow(g_refresh, rc.right - S(18) - S(76), y, S(76), S(36), TRUE);
    MoveWindow(g_d3d9, rc.right - S(18) - S(76) - S(8) - S(140), y, S(140), S(36), TRUE);
    y += S(36) + S(10);
    MoveWindow(g_openvr, S(18), y, S(340), S(24), TRUE);
    MoveWindow(g_force, S(366), y, rc.right - S(384), S(24), TRUE);
    y += S(24) + S(4);
    MoveWindow(g_zerocopy, S(18), y, rc.right - S(36), S(24), TRUE);
    y += S(24) + S(10);
    MoveWindow(g_hwndOut, S(18), y, rc.right - S(36), rc.bottom - y - S(18), TRUE);
    InvalidateRect(h, nullptr, FALSE);
}

static void applyFonts() {
    for (HWND b : g_buttons) SendMessageW(b, WM_SETFONT, (WPARAM)g_fontBody, TRUE);
    SendMessageW(g_refresh, WM_SETFONT, (WPARAM)g_fontBody, TRUE);
    SendMessageW(g_d3d9, WM_SETFONT, (WPARAM)g_fontBody, TRUE);
    SendMessageW(g_zerocopy, WM_SETFONT, (WPARAM)g_fontBody, TRUE);
    SendMessageW(g_force, WM_SETFONT, (WPARAM)g_fontBody, TRUE);
    SendMessageW(g_openvr, WM_SETFONT, (WPARAM)g_fontBody, TRUE);
    SendMessageW(g_hwndOut, WM_SETFONT, (WPARAM)g_fontMono, TRUE);
}

static void setBusy(bool busy) {
    g_busy = busy;
    for (HWND b : g_buttons) EnableWindow(b, !busy);
    EnableWindow(g_refresh, !busy);
    EnableWindow(g_d3d9, !busy);
    EnableWindow(g_zerocopy, !busy);
    EnableWindow(g_force, !busy);
    EnableWindow(g_openvr, !busy);
}

static void runAsync(int id) {
    setBusy(true);
    bool force = g_forceOn, vr = g_openvrOn;
    {
        std::lock_guard<std::mutex> l(g_stateMutex);
        g_output.clear();
    }
    std::thread([id, force, vr] {
        CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
        switch (id) {
        case ID_INSTALL: doInstall(L""); break;
        case ID_ENABLE: doEnableBridge(force); if (vr) doEnableOpenVR(); break;
        case ID_DISABLE: doDisable(); break;
        case ID_UNINSTALL: doUninstall(); break;
        case ID_TEST: doSelfTest(""); break;
        default:
            say(fileExists(manifestPath()) ? L"Ready. 'Test with headset' checks each graphics API in turn."
                                           : L"Not installed yet. Click Install, then Enable, then Test with headset.");
            break;
        }
        doStatus();
        PostMessageW(g_hwndMain, WM_APP + 2, 0, 0);
    }).detach();
}

static LRESULT CALLBACK wndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CREATE: {
        g_hwndMain = h;
        g_dpi = dpiOf(h);
        makeFonts();
        // Dark title bar: attribute 20 on Windows 10 2004 and later, 19 on older builds.
        BOOL dark = TRUE;
        if (FAILED(DwmSetWindowAttribute(h, 20, &dark, sizeof(dark)))) DwmSetWindowAttribute(h, 19, &dark, sizeof(dark));

        struct { const wchar_t* t; int id; } bs[] = {{L"Install", ID_INSTALL}, {L"Enable", ID_ENABLE}, {L"Disable", ID_DISABLE},
                                                     {L"Test with headset", ID_TEST}, {L"Uninstall", ID_UNINSTALL}};
        auto mk = [&](const wchar_t* t, int id) {
            HWND b = CreateWindowW(L"BUTTON", t, WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW, 0, 0, 10, 10, h, (HMENU)(INT_PTR)id, nullptr, nullptr);
            SetWindowSubclass(b, hoverProc, 1, 0);
            return b;
        };
        for (int i = 0; i < 5; ++i) g_buttons[i] = mk(bs[i].t, bs[i].id);
        g_refresh = mk(L"Refresh", ID_REFRESH);
        g_d3d9 = mk(L"D3D9 game screen...", ID_D3D9);
        g_zerocopy = mk(L"Zero-copy frames, faster where the runtime allows it (experimental, restart the game)", ID_ZEROCOPY);
        g_zeroCopyOn = zeroCopyOn();
        g_openvr = mk(L"Redirect SteamVR games through OpenComposite", ID_OPENVR);
        g_force = mk(L"Replace an existing native 32-bit runtime", ID_FORCE);

        g_hwndOut = CreateWindowExW(0, L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
                                    0, 0, 10, 10, h, (HMENU)ID_LOG, nullptr, nullptr);
        // Dark scrollbar where the system offers one. Harmless where it does not.
        typedef HRESULT(WINAPI * ThemeFn)(HWND, LPCWSTR, LPCWSTR);
        if (HMODULE ux = LoadLibraryW(L"uxtheme.dll"))
            if (auto fn = (ThemeFn)GetProcAddress(ux, "SetWindowTheme")) fn(g_hwndOut, L"DarkMode_Explorer", nullptr);
        SendMessageW(g_hwndOut, EM_SETMARGINS, EC_LEFTMARGIN | EC_RIGHTMARGIN, MAKELPARAM(S(8), S(8)));
        g_brushLog = CreateSolidBrush(C_PANEL);
        ShowScrollBar(g_hwndOut, SB_VERT, FALSE);
        applyFonts();
        layout(h);
        runAsync(ID_REFRESH);
        return 0;
    }
    case WM_ERASEBKGND:
        return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(h, &ps);
        RECT rc;
        GetClientRect(h, &rc);
        // Double buffered, so resizing and status updates do not flicker.
        HDC mem = CreateCompatibleDC(dc);
        HBITMAP bmp = CreateCompatibleBitmap(dc, rc.right, rc.bottom);
        HGDIOBJ old = SelectObject(mem, bmp);
        paintMain(h, mem);
        BitBlt(dc, 0, 0, rc.right, rc.bottom, mem, 0, 0, SRCCOPY);
        SelectObject(mem, old);
        DeleteObject(bmp);
        DeleteDC(mem);
        EndPaint(h, &ps);
        return 0;
    }
    case WM_SIZE:
        layout(h);
        return 0;
    case WM_GETMINMAXINFO: {
        auto* mmi = (MINMAXINFO*)l;
        mmi->ptMinTrackSize = {S(800), S(600)};
        return 0;
    }
    case WM_DPICHANGED: {
        g_dpi = HIWORD(w);
        makeFonts();
        applyFonts();
        const RECT* r = (const RECT*)l;
        SetWindowPos(h, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top, SWP_NOZORDER | SWP_NOACTIVATE);
        layout(h);
        return 0;
    }
    case WM_DRAWITEM:
        drawButton((const DRAWITEMSTRUCT*)l);
        return TRUE;
    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLOREDIT: {
        HDC dc = (HDC)w;
        SetTextColor(dc, RGB(202, 206, 218));
        SetBkColor(dc, C_PANEL);
        return (LRESULT)g_brushLog;
    }
    case WM_COMMAND: {
        int id = LOWORD(w);
        if (HIWORD(w) != BN_CLICKED) return 0;
        if (id == ID_FORCE) { g_forceOn = !g_forceOn; InvalidateRect(g_force, nullptr, FALSE); return 0; }
        if (id == ID_OPENVR) { g_openvrOn = !g_openvrOn; InvalidateRect(g_openvr, nullptr, FALSE); return 0; }
        if (id == ID_ZEROCOPY) { g_zeroCopyOn = !g_zeroCopyOn; setZeroCopy(g_zeroCopyOn); InvalidateRect(g_zerocopy, nullptr, FALSE); return 0; }
        if (id == ID_D3D9) {
            wchar_t file[MAX_PATH * 2] = {};
            OPENFILENAMEW ofn{};
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = h;
            ofn.lpstrFilter = L"Game executable (*.exe)\0*.exe\0";
            ofn.lpstrFile = file;
            ofn.nMaxFile = MAX_PATH * 2;
            ofn.lpstrTitle = L"Choose the D3D9 game's .exe";
            ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
            if (!GetOpenFileNameW(&ofn)) return 0;
            wstring exe = file;
            wstring dll = exe.substr(0, exe.find_last_of(L'\\')) + L"\\d3d9.dll";
            std::lock_guard<std::mutex> lk(g_stateMutex);
            g_output.clear();
            setBusy(true);
            bool remove = isOurProxy(dll);
            std::thread([exe, remove] {
                if (remove) doD3D9Remove(exe); else doD3D9Add(exe);
                PostMessageW(g_hwndMain, WM_APP + 2, 0, 0);
            }).detach();
            return 0;
        }
        if (id == ID_UNINSTALL && MessageBoxW(h, L"Remove XRBridge32 and restore your previous VR settings?", L"XRBridge32", MB_YESNO | MB_ICONQUESTION) != IDYES)
            return 0;
        if (id >= ID_INSTALL && id <= ID_UNINSTALL) runAsync(id);
        else if (id == ID_REFRESH) runAsync(id);
        return 0;
    }
    case WM_APP + 1:
    case WM_APP + 2: {
        wstring text;
        {
            std::lock_guard<std::mutex> lk(g_stateMutex);
            text = g_output;
        }
        SetWindowTextW(g_hwndOut, text.c_str());
        // The scrollbar cannot be fully themed on every Windows build, so it only
        // appears when the log actually overflows.
        {
            RECT er;
            GetClientRect(g_hwndOut, &er);
            TEXTMETRICW tm{};
            HDC edc = GetDC(g_hwndOut);
            HGDIOBJ of = SelectObject(edc, g_fontMono);
            GetTextMetricsW(edc, &tm);
            SelectObject(edc, of);
            ReleaseDC(g_hwndOut, edc);
            int lines = (int)SendMessageW(g_hwndOut, EM_GETLINECOUNT, 0, 0);
            ShowScrollBar(g_hwndOut, SB_VERT, tm.tmHeight > 0 && lines * tm.tmHeight > er.bottom);
        }
        SendMessageW(g_hwndOut, EM_LINESCROLL, 0, 0xFFFF);
        if (m == WM_APP + 2) { setBusy(false); layout(h); }
        InvalidateRect(h, nullptr, FALSE);
        return 0;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

static int runGui(HINSTANCE inst, int show) {
    // Lets DarkMode_Explorer take effect on the scrollbar on Windows 10 1903 and later.
    // Ordinal 135 is undocumented, so a missing export or odd build simply stays light.
    typedef int(WINAPI * AppModeFn)(int);
    if (HMODULE ux = LoadLibraryW(L"uxtheme.dll"))
        if (auto fn = (AppModeFn)GetProcAddress(ux, MAKEINTRESOURCEA(135))) fn(1);
    typedef BOOL(WINAPI * DpiFn)(void*);
    if (auto fn = (DpiFn)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext"))
        fn((void*)-4); // per-monitor v2
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&icc);
    g_iconLarge = (HICON)LoadImageW(inst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON, 256, 256, LR_DEFAULTCOLOR);
    WNDCLASSEXW wc{sizeof(wc)};
    wc.lpfnWndProc = wndProc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursorW(nullptr, (LPCWSTR)IDC_ARROW);
    wc.hbrBackground = nullptr;
    wc.lpszClassName = L"XRBridge32Setup";
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(IDI_APP));
    wc.hIconSm = (HICON)LoadImageW(inst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
    RegisterClassExW(&wc);
    HDC screen = GetDC(nullptr);
    int sysDpi = GetDeviceCaps(screen, LOGPIXELSX);
    ReleaseDC(nullptr, screen);
    HWND h = CreateWindowW(L"XRBridge32Setup", L"XRBridge32", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                           MulDiv(860, sysDpi, 96), MulDiv(720, sysDpi, 96), nullptr, nullptr, inst, nullptr);
    ShowWindow(h, show);
    MSG m;
    while (GetMessageW(&m, nullptr, 0, 0)) {
        if (!IsDialogMessageW(h, &m)) {
            TranslateMessage(&m);
            DispatchMessageW(&m);
        }
    }
    return 0;
}
