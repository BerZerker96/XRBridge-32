// A fake 64-bit OpenXR runtime for testing the bridge without a headset.
// Handles and values are deliberately large and distinctive, so truncation or a
// wrong struct offset in the 32/64 marshalling shows up as a failed check.
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#include <windows.h>
#include <unknwn.h>
#include <d3d11.h>
#include <dxgi.h>
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <openxr/openxr_loader_negotiation.h>
#include <cstdio>
#include <cstring>
#include <deque>
#include <map>
#include <string>
#include <vector>

#define H_INSTANCE 0xAB00000000000001ull
#define H_SESSION  0xAB00000000000002ull
#define H_SPACE    0xAB00000000000100ull
#define H_SWAP     0xAB00000000000200ull
#define H_ASET     0xAB00000000000300ull
#define H_ACTION   0xAB00000000000400ull
#define SYSTEM_ID  0xCD00000000000042ull
#define TIME_BASE  0x0012345678900000ll

static FILE* lf;
static void mlog(const char* m) {
    if (!lf) {
        char p[MAX_PATH] = "mock.log";
        GetEnvironmentVariableA("XRB_MOCK_LOG", p, MAX_PATH);
        lf = fopen(p, "w");
    }
    if (lf) { fprintf(lf, "%s\n", m); fflush(lf); }
}
#define CHECK(c) do { if (!(c)) { char b[200]; snprintf(b, 200, "FAIL %s:%d %s", __func__, __LINE__, #c); mlog(b); return XR_ERROR_VALIDATION_FAILURE; } } while (0)

static std::deque<XrSessionState> g_events;
static std::map<std::string, XrPath> g_paths;
static std::vector<std::string> g_pathNames;
static uint64_t g_nextSpace = H_SPACE, g_nextSwap = H_SWAP, g_nextSet = H_ASET, g_nextAction = H_ACTION;
static int64_t g_time = TIME_BASE;
static ID3D11Device* g_device;
static std::map<uint64_t, std::vector<ID3D11Texture2D*>> g_images;
static int g_frames;
static bool g_refreshEvent;

template <class T> static XrResult fill(uint32_t cap, uint32_t* n, T* out, const std::vector<T>& v) {
    *n = (uint32_t)v.size();
    if (!cap) return XR_SUCCESS;
    if (cap < v.size()) return XR_ERROR_SIZE_INSUFFICIENT;
    for (size_t i = 0; i < v.size(); ++i) out[i] = v[i];
    return XR_SUCCESS;
}
static const XrPosef kPose = {{0.5f, 0.25f, 0.125f, 0.0625f}, {1.5f, 2.5f, 3.5f}};
static const XrFovf kFov = {-0.75f, 0.8125f, 0.875f, -1.0f};
static bool samePose(const XrPosef& a, const XrPosef& b) { return !memcmp(&a, &b, sizeof(XrPosef)); }

#define F(ret, name, ...) static XrResult XRAPI_CALL m_##name(__VA_ARGS__)

F(, xrEnumerateApiLayerProperties, uint32_t, uint32_t* n, XrApiLayerProperties*) { *n = 0; return XR_SUCCESS; }
F(, xrEnumerateInstanceExtensionProperties, const char*, uint32_t cap, uint32_t* n, XrExtensionProperties* o) {
    { char h[8]; if (GetEnvironmentVariableA("XRB_MOCK_HANG", h, sizeof(h))) Sleep(INFINITE); } // a stuck runtime
    static const char* names[] = {"XR_KHR_D3D11_enable", "XR_KHR_visibility_mask", "XR_KHR_win32_convert_performance_counter",
                                  "XR_EXT_hand_tracking", "XR_FB_display_refresh_rate", "XR_KHR_composition_layer_cylinder",
                                  "XR_KHR_composition_layer_equirect2", "XR_KHR_composition_layer_cube",
                                  "XR_KHR_composition_layer_depth", "XR_EXT_dpad_binding", "XR_MNDX_xdev_space",
                                  "XR_VARJO_quad_views", "XR_VARJO_foveated_rendering", "XR_EXT_performance_settings", "XR_FB_eye_tracking_social",
                                  "XR_KHR_binding_modification", "XR_VALVE_analog_threshold", "XR_KHR_D3D12_enable",
                                  "XR_FB_swapchain_update_state", "XR_FB_foveation", "XR_FB_foveation_configuration"};
    const uint32_t count = sizeof(names) / sizeof(names[0]);
    *n = count;
    if (!cap) return XR_SUCCESS;
    if (cap < count) return XR_ERROR_SIZE_INSUFFICIENT;
    for (uint32_t i = 0; i < count; ++i) { strcpy(o[i].extensionName, names[i]); o[i].extensionVersion = 7 + i; }
    return XR_SUCCESS;
}
F(, xrCreateInstance, const XrInstanceCreateInfo* ci, XrInstance* i) {
    char b[300]; snprintf(b, 300, "createInstance app=%s exts=%u", ci->applicationInfo.applicationName, ci->enabledExtensionCount); mlog(b);
    bool hasD3D11 = false;
    for (uint32_t i = 0; i < ci->enabledExtensionCount; ++i) {
        if (!strcmp(ci->enabledExtensionNames[i], "XR_KHR_D3D11_enable")) hasD3D11 = true;
        // Graphics APIs the game uses must stay on the game's side of the bridge.
        CHECK(strcmp(ci->enabledExtensionNames[i], "XR_KHR_vulkan_enable") && strcmp(ci->enabledExtensionNames[i], "XR_KHR_opengl_enable") && strcmp(ci->enabledExtensionNames[i], "XR_KHR_D3D12_enable"));
    }
    CHECK(hasD3D11);
    *i = (XrInstance)H_INSTANCE; return XR_SUCCESS;
}
F(, xrDestroyInstance, XrInstance i) { CHECK((uint64_t)i == H_INSTANCE); mlog("destroyInstance ok"); return XR_SUCCESS; }
F(, xrGetInstanceProperties, XrInstance i, XrInstanceProperties* p) {
    CHECK((uint64_t)i == H_INSTANCE); p->runtimeVersion = XR_MAKE_VERSION(9, 8, 7); strcpy(p->runtimeName, "MockRuntime"); return XR_SUCCESS;
}
F(, xrPollEvent, XrInstance, XrEventDataBuffer* e) {
    if (g_refreshEvent) {
        g_refreshEvent = false;
        auto* r = (XrEventDataDisplayRefreshRateChangedFB*)e;
        r->type = XR_TYPE_EVENT_DATA_DISPLAY_REFRESH_RATE_CHANGED_FB; r->next = nullptr;
        r->fromDisplayRefreshRate = 72.0f; r->toDisplayRefreshRate = 90.0f;
        return XR_SUCCESS;
    }
    if (g_events.empty()) return XR_EVENT_UNAVAILABLE;
    auto* s = (XrEventDataSessionStateChanged*)e;
    s->type = XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED; s->next = nullptr;
    s->session = (XrSession)H_SESSION; s->state = g_events.front(); s->time = TIME_BASE + 7;
    g_events.pop_front();
    return XR_SUCCESS;
}
F(, xrResultToString, XrInstance, XrResult, char b[XR_MAX_RESULT_STRING_SIZE]) { strcpy(b, "XR_MOCK_RESULT"); return XR_SUCCESS; }
F(, xrStructureTypeToString, XrInstance, XrStructureType, char b[XR_MAX_STRUCTURE_NAME_SIZE]) { strcpy(b, "XR_MOCK_TYPE"); return XR_SUCCESS; }
F(, xrGetSystem, XrInstance, const XrSystemGetInfo* g, XrSystemId* id) { CHECK(g->formFactor == XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY); *id = SYSTEM_ID; return XR_SUCCESS; }
F(, xrGetSystemProperties, XrInstance, XrSystemId id, XrSystemProperties* p) {
    CHECK(id == SYSTEM_ID);
    p->vendorId = 0x1234; strcpy(p->systemName, "MockHMD");
    p->graphicsProperties = {3840, 2160, 16}; p->trackingProperties = {XR_TRUE, XR_FALSE};
    for (auto* b = (XrBaseOutStructure*)p->next; b; b = b->next) {
        if (b->type == XR_TYPE_SYSTEM_HAND_TRACKING_PROPERTIES_EXT) ((XrSystemHandTrackingPropertiesEXT*)b)->supportsHandTracking = XR_TRUE;
    }
    return XR_SUCCESS;
}
F(, xrEnumerateEnvironmentBlendModes, XrInstance, XrSystemId, XrViewConfigurationType, uint32_t c, uint32_t* n, XrEnvironmentBlendMode* o) {
    return fill<XrEnvironmentBlendMode>(c, n, o, {XR_ENVIRONMENT_BLEND_MODE_OPAQUE});
}
F(, xrCreateSession, XrInstance, const XrSessionCreateInfo* ci, XrSession* s) {
    CHECK(ci->systemId == SYSTEM_ID);
    const XrGraphicsBindingD3D11KHR* gb = (const XrGraphicsBindingD3D11KHR*)ci->next;
    CHECK(gb && gb->type == XR_TYPE_GRAPHICS_BINDING_D3D11_KHR);
    g_device = gb->device;
    *s = (XrSession)H_SESSION;
    g_events.push_back(XR_SESSION_STATE_IDLE);
    g_events.push_back(XR_SESSION_STATE_READY);
    mlog(g_device ? "createSession with real D3D11 device" : "createSession null gfx");
    return XR_SUCCESS;
}
F(, xrDestroySession, XrSession s) { CHECK((uint64_t)s == H_SESSION); mlog("destroySession ok"); return XR_SUCCESS; }
F(, xrEnumerateReferenceSpaces, XrSession, uint32_t c, uint32_t* n, XrReferenceSpaceType* o) {
    return fill<XrReferenceSpaceType>(c, n, o, {XR_REFERENCE_SPACE_TYPE_VIEW, XR_REFERENCE_SPACE_TYPE_LOCAL, XR_REFERENCE_SPACE_TYPE_STAGE});
}
F(, xrCreateReferenceSpace, XrSession, const XrReferenceSpaceCreateInfo*, XrSpace* s) { *s = (XrSpace)(g_nextSpace++); return XR_SUCCESS; }
F(, xrGetReferenceSpaceBoundsRect, XrSession, XrReferenceSpaceType, XrExtent2Df* b) { *b = {2.5f, 3.5f}; return XR_SUCCESS; }
F(, xrCreateActionSpace, XrSession, const XrActionSpaceCreateInfo* ci, XrSpace* s) {
    CHECK(((uint64_t)ci->action & 0xFFFFFF0000000000ull) == 0xAB00000000000000ull);
    CHECK(samePose(ci->poseInActionSpace, kPose));
    *s = (XrSpace)(g_nextSpace++); return XR_SUCCESS;
}
F(, xrLocateSpace, XrSpace sp, XrSpace, XrTime t, XrSpaceLocation* l) {
    CHECK(((uint64_t)sp >> 56) == 0xAB); CHECK(t >= TIME_BASE);
    l->locationFlags = XR_SPACE_LOCATION_POSITION_VALID_BIT | XR_SPACE_LOCATION_ORIENTATION_VALID_BIT;
    l->pose = kPose;
    if (l->next) {
        auto* v = (XrSpaceVelocity*)l->next;
        CHECK(v->type == XR_TYPE_SPACE_VELOCITY);
        v->velocityFlags = XR_SPACE_VELOCITY_LINEAR_VALID_BIT; v->linearVelocity = {4.f, 5.f, 6.f}; v->angularVelocity = {7.f, 8.f, 9.f};
    }
    return XR_SUCCESS;
}
F(, xrDestroySpace, XrSpace s) { CHECK(((uint64_t)s >> 56) == 0xAB); return XR_SUCCESS; }
F(, xrEnumerateViewConfigurations, XrInstance, XrSystemId, uint32_t c, uint32_t* n, XrViewConfigurationType* o) {
    return fill<XrViewConfigurationType>(c, n, o, {XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_QUAD_VARJO});
}
F(, xrGetViewConfigurationProperties, XrInstance, XrSystemId, XrViewConfigurationType t, XrViewConfigurationProperties* p) {
    p->viewConfigurationType = t; p->fovMutable = XR_TRUE; return XR_SUCCESS;
}
F(, xrEnumerateViewConfigurationViews, XrInstance, XrSystemId, XrViewConfigurationType vt, uint32_t c, uint32_t* n, XrViewConfigurationView* o) {
    const uint32_t views = vt == XR_VIEW_CONFIGURATION_TYPE_PRIMARY_QUAD_VARJO ? 4 : 2;
    *n = views;
    if (c >= 2 && o[0].next) {
        auto* f = (XrFoveatedViewConfigurationViewVARJO*)o[0].next;
        if (f->type == XR_TYPE_FOVEATED_VIEW_CONFIGURATION_VIEW_VARJO) f->foveatedRenderingActive = XR_TRUE;
    }
    if (!c) return XR_SUCCESS;
    if (c < views) return XR_ERROR_SIZE_INSUFFICIENT;
    for (uint32_t i = 0; i < views; ++i) {
        CHECK(o[i].type == XR_TYPE_VIEW_CONFIGURATION_VIEW);
        o[i].recommendedImageRectWidth = 64; o[i].maxImageRectWidth = 128; o[i].recommendedImageRectHeight = 72;
        o[i].maxImageRectHeight = 144; o[i].recommendedSwapchainSampleCount = 1; o[i].maxSwapchainSampleCount = 4;
    }
    return XR_SUCCESS;
}
F(, xrEnumerateSwapchainFormats, XrSession, uint32_t c, uint32_t* n, int64_t* o) {
    // Includes depth formats, which the bridge must filter out.
    return fill<int64_t>(c, n, o, {DXGI_FORMAT_R8G8B8A8_UNORM_SRGB, DXGI_FORMAT_D32_FLOAT, DXGI_FORMAT_R8G8B8A8_UNORM, DXGI_FORMAT_D24_UNORM_S8_UINT});
}
F(, xrCreateSwapchain, XrSession, const XrSwapchainCreateInfo* ci, XrSwapchain* s) {
    CHECK(ci->usageFlags & XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT);
    // Whatever API the game uses, the runtime must only ever see DXGI formats.
    const bool depth = ci->format == DXGI_FORMAT_D32_FLOAT || ci->format == DXGI_FORMAT_D24_UNORM_S8_UINT;
    CHECK(depth || ci->format == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB || ci->format == DXGI_FORMAT_R8G8B8A8_UNORM);
    CHECK(ci->usageFlags & (depth ? XR_SWAPCHAIN_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT : XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT));
    if (ci->next) {
        auto* e = (const XrBaseInStructure*)ci->next;
        if (e->type == XR_TYPE_SWAPCHAIN_CREATE_INFO_FOVEATION_FB) mlog("swapchain foveation chain received");
    }
    CHECK(ci->width > 0 && ci->height > 0 && ci->arraySize >= 1 && ci->mipCount >= 1 && ci->faceCount >= 1 && ci->sampleCount >= 1);
    uint64_t h = g_nextSwap++;
    std::vector<ID3D11Texture2D*> imgs(3, nullptr);
    if (g_device) {
        D3D11_TEXTURE2D_DESC d{};
        d.Width = ci->width; d.Height = ci->height; d.MipLevels = ci->mipCount; d.ArraySize = ci->arraySize;
        d.Format = (DXGI_FORMAT)ci->format; d.SampleDesc.Count = ci->sampleCount; d.Usage = D3D11_USAGE_DEFAULT;
        d.BindFlags = (depth ? D3D11_BIND_DEPTH_STENCIL : D3D11_BIND_RENDER_TARGET) | D3D11_BIND_SHADER_RESOURCE;
        char shareEnv[8];
        if (GetEnvironmentVariableA("XRB_MOCK_SHARED", shareEnv, sizeof(shareEnv))) d.MiscFlags = D3D11_RESOURCE_MISC_SHARED;
        for (auto*& t : imgs) if (FAILED(g_device->CreateTexture2D(&d, nullptr, &t))) return XR_ERROR_RUNTIME_FAILURE;
    }
    g_images[h] = imgs;
    *s = (XrSwapchain)h;
    return XR_SUCCESS;
}
F(, xrDestroySwapchain, XrSwapchain s) { CHECK(g_images.count((uint64_t)s)); return XR_SUCCESS; }
F(, xrEnumerateSwapchainImages, XrSwapchain s, uint32_t c, uint32_t* n, XrSwapchainImageBaseHeader* o) {
    auto& im = g_images[(uint64_t)s];
    *n = (uint32_t)im.size();
    if (!c) return XR_SUCCESS;
    if (c < im.size()) return XR_ERROR_SIZE_INSUFFICIENT;
    auto* d = (XrSwapchainImageD3D11KHR*)o;
    for (size_t i = 0; i < im.size(); ++i) d[i].texture = im[i];
    return XR_SUCCESS;
}
static std::map<uint64_t, uint32_t> g_nextIdx;
F(, xrAcquireSwapchainImage, XrSwapchain s, const XrSwapchainImageAcquireInfo*, uint32_t* i) { *i = g_nextIdx[(uint64_t)s]++ % 3; return XR_SUCCESS; }
F(, xrWaitSwapchainImage, XrSwapchain, const XrSwapchainImageWaitInfo* w) {
    char loose[8];
    if (!GetEnvironmentVariableA("XRB_MOCK_LOOSE", loose, sizeof(loose))) CHECK(w->timeout == 123456789);
    return XR_SUCCESS;
}
F(, xrReleaseSwapchainImage, XrSwapchain, const XrSwapchainImageReleaseInfo*) { return XR_SUCCESS; }
F(, xrBeginSession, XrSession, const XrSessionBeginInfo* b) {
    CHECK(b->primaryViewConfigurationType == XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO);
    g_events.push_back(XR_SESSION_STATE_SYNCHRONIZED); g_events.push_back(XR_SESSION_STATE_VISIBLE); g_events.push_back(XR_SESSION_STATE_FOCUSED);
    return XR_SUCCESS;
}
F(, xrEndSession, XrSession) { g_events.push_back(XR_SESSION_STATE_EXITING); return XR_SUCCESS; }
F(, xrRequestExitSession, XrSession) { g_events.push_back(XR_SESSION_STATE_STOPPING); return XR_SUCCESS; }
F(, xrWaitFrame, XrSession, const XrFrameWaitInfo*, XrFrameState* f) {
    Sleep(2);
    g_time += 11111111;
    f->predictedDisplayTime = g_time; f->predictedDisplayPeriod = 11111111; f->shouldRender = XR_TRUE;
    return XR_SUCCESS;
}
F(, xrBeginFrame, XrSession, const XrFrameBeginInfo*) { return XR_SUCCESS; }
F(, xrEndFrame, XrSession, const XrFrameEndInfo* e) {
    CHECK(e->displayTime >= TIME_BASE);
    CHECK(e->environmentBlendMode == XR_ENVIRONMENT_BLEND_MODE_OPAQUE);
    for (uint32_t i = 0; i < e->layerCount; ++i) {
        auto* h = e->layers[i];
        if (h->type == XR_TYPE_COMPOSITION_LAYER_PROJECTION) {
            auto* p = (const XrCompositionLayerProjection*)h;
            CHECK(p->viewCount == 2 && ((uint64_t)p->space >> 56) == 0xAB);
            for (int v = 0; v < 2; ++v) {
                CHECK(p->views[v].type == XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW);
                CHECK(g_images.count((uint64_t)p->views[v].subImage.swapchain));
                CHECK(p->views[v].subImage.imageRect.extent.width == 64);
                if (p->views[v].next) {
                    auto* d = (const XrCompositionLayerDepthInfoKHR*)p->views[v].next;
                    CHECK(d->type == XR_TYPE_COMPOSITION_LAYER_DEPTH_INFO_KHR && d->nearZ == 0.25f && d->farZ == 500.0f && g_images.count((uint64_t)d->subImage.swapchain));
                    if (g_frames == 0) mlog("depth layer received");
                }
            }
        } else if (h->type == XR_TYPE_COMPOSITION_LAYER_QUAD) {
            auto* q = (const XrCompositionLayerQuad*)h;
            char loose[8];
            if (!GetEnvironmentVariableA("XRB_MOCK_LOOSE", loose, sizeof(loose))) CHECK(q->size.width == 1.25f && q->size.height == 0.75f);
            if (g_frames == 0) { char b[80]; snprintf(b, 80, "quad rect y=%d h=%d", q->subImage.imageRect.offset.y, q->subImage.imageRect.extent.height); mlog(b); }
            if (!GetEnvironmentVariableA("XRB_MOCK_LOOSE", loose, sizeof(loose))) CHECK(samePose(q->pose, kPose));
        } else if (h->type == XR_TYPE_COMPOSITION_LAYER_CYLINDER_KHR) {
            auto* c = (const XrCompositionLayerCylinderKHR*)h;
            char loose[8];
            if (GetEnvironmentVariableA("XRB_MOCK_LOOSE", loose, sizeof(loose))) {
                static int logged;
                if (logged++ == 0) { char b[120]; snprintf(b, 120, "screen layer: radius %.2f angle %.2f aspect %.3f", c->radius, c->centralAngle, c->aspectRatio); mlog(b); }
            } else
            CHECK(c->radius == 2.5f && c->centralAngle == 1.5f && c->aspectRatio == 0.75f && samePose(c->pose, kPose));
        } else if (h->type == XR_TYPE_COMPOSITION_LAYER_EQUIRECT2_KHR) {
            auto* c = (const XrCompositionLayerEquirect2KHR*)h;
            CHECK(c->radius == 3.5f && c->lowerVerticalAngle == -0.5f && samePose(c->pose, kPose));
        } else if (h->type == XR_TYPE_COMPOSITION_LAYER_CUBE_KHR) {
            auto* c = (const XrCompositionLayerCubeKHR*)h;
            CHECK(c->imageArrayIndex == 0 && c->orientation.w == 0.0625f);
        } else CHECK(false);
    }
    if (g_frames++ == 0) mlog("first xrEndFrame accepted");
    return XR_SUCCESS;
}
F(, xrLocateViews, XrSession, const XrViewLocateInfo* li, XrViewState* s, uint32_t c, uint32_t* n, XrView* v) {
    CHECK(li->displayTime >= TIME_BASE);
    if (li->next) {
        auto* f = (const XrViewLocateFoveatedRenderingVARJO*)li->next;
        CHECK(f->type == XR_TYPE_VIEW_LOCATE_FOVEATED_RENDERING_VARJO && f->foveatedRenderingActive == XR_TRUE);
        static bool once;
        if (!once) { once = true; mlog("foveated locate chain received"); }
    }
    s->viewStateFlags = XR_VIEW_STATE_POSITION_VALID_BIT | XR_VIEW_STATE_ORIENTATION_VALID_BIT;
    const uint32_t views = li->viewConfigurationType == XR_VIEW_CONFIGURATION_TYPE_PRIMARY_QUAD_VARJO ? 4 : 2;
    *n = views;
    if (!c) return XR_SUCCESS;
    if (c < views) return XR_ERROR_SIZE_INSUFFICIENT;
    for (uint32_t i = 0; i < views; ++i) {
        v[i].pose = kPose; v[i].fov = kFov;
        if (i >= 2) { v[i].fov.angleLeft *= 0.5f; v[i].fov.angleRight *= 0.5f; v[i].fov.angleUp *= 0.5f; v[i].fov.angleDown *= 0.5f; } // inner views
    }
    return XR_SUCCESS;
}
F(, xrStringToPath, XrInstance, const char* s, XrPath* p) {
    auto it = g_paths.find(s);
    if (it == g_paths.end()) {
        g_pathNames.push_back(s);
        XrPath v = 0xEE00000000000000ull + g_pathNames.size();
        g_paths[s] = v;
        *p = v;
    } else *p = it->second;
    return XR_SUCCESS;
}
F(, xrPathToString, XrInstance, XrPath p, uint32_t c, uint32_t* n, char* b) {
    size_t i = (size_t)(p - 0xEE00000000000000ull);
    if (i == 0 || i > g_pathNames.size()) return XR_ERROR_PATH_INVALID;
    const std::string& s = g_pathNames[i - 1];
    *n = (uint32_t)s.size() + 1;
    if (!c) return XR_SUCCESS;
    if (c < *n) return XR_ERROR_SIZE_INSUFFICIENT;
    memcpy(b, s.c_str(), *n);
    return XR_SUCCESS;
}
F(, xrCreateActionSet, XrInstance, const XrActionSetCreateInfo* ci, XrActionSet* a) {
    CHECK(!strcmp(ci->actionSetName, "bridge_test") && ci->priority == 3);
    *a = (XrActionSet)(g_nextSet++); return XR_SUCCESS;
}
F(, xrDestroyActionSet, XrActionSet) { return XR_SUCCESS; }
F(, xrCreateAction, XrActionSet, const XrActionCreateInfo* ci, XrAction* a) {
    CHECK(ci->countSubactionPaths == 2 && (ci->subactionPaths[0] >> 56) == 0xEE);
    *a = (XrAction)(g_nextAction++); return XR_SUCCESS;
}
F(, xrDestroyAction, XrAction) { return XR_SUCCESS; }
F(, xrSuggestInteractionProfileBindings, XrInstance, const XrInteractionProfileSuggestedBinding* s) {
    if (s->next) {
        auto* m = (const XrBindingModificationsKHR*)s->next;
        CHECK(m->type == XR_TYPE_BINDING_MODIFICATIONS_KHR && m->bindingModificationCount == 1);
        auto* a = (const XrInteractionProfileAnalogThresholdVALVE*)m->bindingModifications[0];
        CHECK(a->type == XR_TYPE_INTERACTION_PROFILE_ANALOG_THRESHOLD_VALVE && a->onThreshold == 0.75f);
        mlog("binding modification chain received");
    }
    CHECK(s->countSuggestedBindings == 2 && (s->interactionProfile >> 56) == 0xEE && ((uint64_t)s->suggestedBindings[1].action >> 56) == 0xAB);
    return XR_SUCCESS;
}
F(, xrAttachSessionActionSets, XrSession, const XrSessionActionSetsAttachInfo* a) { CHECK(a->countActionSets == 1 && ((uint64_t)a->actionSets[0] >> 56) == 0xAB); return XR_SUCCESS; }
F(, xrGetCurrentInteractionProfile, XrSession, XrPath top, XrInteractionProfileState* s) { CHECK((top >> 56) == 0xEE); s->interactionProfile = top; return XR_SUCCESS; }
F(, xrGetActionStateBoolean, XrSession, const XrActionStateGetInfo*, XrActionStateBoolean* s) { s->currentState = XR_TRUE; s->changedSinceLastSync = XR_TRUE; s->lastChangeTime = TIME_BASE + 9; s->isActive = XR_TRUE; return XR_SUCCESS; }
F(, xrGetActionStateFloat, XrSession, const XrActionStateGetInfo*, XrActionStateFloat* s) { s->currentState = 0.625f; s->changedSinceLastSync = XR_TRUE; s->lastChangeTime = TIME_BASE + 10; s->isActive = XR_TRUE; return XR_SUCCESS; }
F(, xrGetActionStateVector2f, XrSession, const XrActionStateGetInfo*, XrActionStateVector2f* s) { s->currentState = {0.25f, -0.5f}; s->changedSinceLastSync = XR_FALSE; s->lastChangeTime = TIME_BASE + 11; s->isActive = XR_TRUE; return XR_SUCCESS; }
F(, xrGetActionStatePose, XrSession, const XrActionStateGetInfo*, XrActionStatePose* s) { s->isActive = XR_TRUE; return XR_SUCCESS; }
F(, xrSyncActions, XrSession, const XrActionsSyncInfo* s) { CHECK(s->countActiveActionSets == 1 && ((uint64_t)s->activeActionSets[0].actionSet >> 56) == 0xAB); return XR_SUCCESS; }
F(, xrEnumerateBoundSourcesForAction, XrSession, const XrBoundSourcesForActionEnumerateInfo*, uint32_t c, uint32_t* n, XrPath* o) { return fill<XrPath>(c, n, o, {0xEE00000000000001ull}); }
F(, xrGetInputSourceLocalizedName, XrSession, const XrInputSourceLocalizedNameGetInfo*, uint32_t c, uint32_t* n, char* b) {
    *n = 8; if (!c) return XR_SUCCESS; if (c < 8) return XR_ERROR_SIZE_INSUFFICIENT; strcpy(b, "Trigger"); return XR_SUCCESS;
}
F(, xrApplyHapticFeedback, XrSession, const XrHapticActionInfo*, const XrHapticBaseHeader* h) {
    auto* v = (const XrHapticVibration*)h;
    CHECK(v->type == XR_TYPE_HAPTIC_VIBRATION && v->duration == 5000000 && v->amplitude == 0.5f && v->frequency == 160.f);
    return XR_SUCCESS;
}
F(, xrStopHapticFeedback, XrSession, const XrHapticActionInfo*) { return XR_SUCCESS; }
F(, xrGetD3D11GraphicsRequirementsKHR, XrInstance, XrSystemId, XrGraphicsRequirementsD3D11KHR* r) {
    IDXGIFactory1* f = nullptr; IDXGIAdapter1* a = nullptr;
    r->minFeatureLevel = D3D_FEATURE_LEVEL_11_0;
    if (SUCCEEDED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&f)) && f->EnumAdapters1(0, &a) == S_OK) {
        DXGI_ADAPTER_DESC1 d; a->GetDesc1(&d); r->adapterLuid = d.AdapterLuid; a->Release();
    }
    if (f) f->Release();
    return XR_SUCCESS;
}
F(, xrGetVisibilityMaskKHR, XrSession, XrViewConfigurationType, uint32_t, XrVisibilityMaskTypeKHR, XrVisibilityMaskKHR* m) {
    m->vertexCountOutput = 3; m->indexCountOutput = 3;
    if (m->vertexCapacityInput >= 3) { m->vertices[0] = {0, 0}; m->vertices[1] = {1, 0}; m->vertices[2] = {0, 1}; }
    if (m->indexCapacityInput >= 3) { m->indices[0] = 0; m->indices[1] = 1; m->indices[2] = 2; }
    return XR_SUCCESS;
}
F(, xrConvertWin32PerformanceCounterToTimeKHR, XrInstance, const LARGE_INTEGER* p, XrTime* t) { *t = p->QuadPart + 1; return XR_SUCCESS; }
F(, xrConvertTimeToWin32PerformanceCounterKHR, XrInstance, XrTime t, LARGE_INTEGER* p) { p->QuadPart = t - 1; return XR_SUCCESS; }

F(, xrLocateSpaces, XrSession, const XrSpacesLocateInfo* li, XrSpaceLocations* l) {
    CHECK(li->spaceCount == 2 && l->locationCount == 2 && ((uint64_t)li->spaces[1] >> 56) == 0xAB && li->time >= TIME_BASE);
    for (uint32_t i = 0; i < 2; ++i) { l->locations[i].locationFlags = XR_SPACE_LOCATION_POSITION_VALID_BIT; l->locations[i].pose = kPose; }
    if (l->next) {
        auto* v = (XrSpaceVelocities*)l->next;
        CHECK(v->type == XR_TYPE_SPACE_VELOCITIES && v->velocityCount == 2);
        v->velocities[1].linearVelocity = {4.f, 5.f, 6.f};
    }
    return XR_SUCCESS;
}
// Extensions only the generated code knows about.
F(, xrPerfSettingsSetPerformanceLevelEXT, XrSession, XrPerfSettingsDomainEXT d, XrPerfSettingsLevelEXT l) {
    CHECK(d == XR_PERF_SETTINGS_DOMAIN_GPU_EXT && l == XR_PERF_SETTINGS_LEVEL_BOOST_EXT);
    mlog("generated: perf level set");
    return XR_SUCCESS;
}
F(, xrCreateEyeTrackerFB, XrSession, const XrEyeTrackerCreateInfoFB*, XrEyeTrackerFB* t) { *t = (XrEyeTrackerFB)0xAB00000000000600ull; return XR_SUCCESS; }
F(, xrDestroyEyeTrackerFB, XrEyeTrackerFB t) { CHECK((uint64_t)t == 0xAB00000000000600ull); return XR_SUCCESS; }
F(, xrGetEyeGazesFB, XrEyeTrackerFB t, const XrEyeGazesInfoFB* i, XrEyeGazesFB* g) {
    CHECK((uint64_t)t == 0xAB00000000000600ull && i->time >= TIME_BASE);
    g->gaze[1].isValid = XR_TRUE; g->gaze[1].gazePose = kPose; g->gaze[1].gazeConfidence = 0.875f; g->time = TIME_BASE + 21;
    return XR_SUCCESS;
}
F(, xrCreateHandTrackerEXT, XrSession, const XrHandTrackerCreateInfoEXT* ci, XrHandTrackerEXT* t) {
    CHECK(ci->hand == XR_HAND_RIGHT_EXT && ci->handJointSet == XR_HAND_JOINT_SET_DEFAULT_EXT);
    *t = (XrHandTrackerEXT)0xAB00000000000500ull; return XR_SUCCESS;
}
F(, xrDestroyHandTrackerEXT, XrHandTrackerEXT t) { CHECK((uint64_t)t == 0xAB00000000000500ull); return XR_SUCCESS; }
F(, xrLocateHandJointsEXT, XrHandTrackerEXT t, const XrHandJointsLocateInfoEXT* li, XrHandJointLocationsEXT* l) {
    CHECK((uint64_t)t == 0xAB00000000000500ull && li->time >= TIME_BASE && l->jointCount == 26);
    l->isActive = XR_TRUE;
    l->jointLocations[25].pose = kPose; l->jointLocations[25].radius = 0.125f;
    if (l->next) ((XrHandJointVelocitiesEXT*)l->next)->jointVelocities[25].angularVelocity = {7.f, 8.f, 9.f};
    return XR_SUCCESS;
}
F(, xrEnumerateDisplayRefreshRatesFB, XrSession, uint32_t c, uint32_t* n, float* o) { return fill<float>(c, n, o, {72.0f, 90.0f}); }
F(, xrGetDisplayRefreshRateFB, XrSession, float* r) { *r = 90.0f; return XR_SUCCESS; }
F(, xrRequestDisplayRefreshRateFB, XrSession, float r) { CHECK(r == 90.0f); g_refreshEvent = true; return XR_SUCCESS; }

// FB foveation: a profile handle, and the state that applies it to a swapchain
F(, xrCreateFoveationProfileFB, XrSession, const XrFoveationProfileCreateInfoFB* ci, XrFoveationProfileFB* p) {
    CHECK(ci && ci->type == XR_TYPE_FOVEATION_PROFILE_CREATE_INFO_FB && ci->next);
    auto* lv = (const XrFoveationLevelProfileCreateInfoFB*)ci->next;
    CHECK(lv->type == XR_TYPE_FOVEATION_LEVEL_PROFILE_CREATE_INFO_FB && lv->level == XR_FOVEATION_LEVEL_HIGH_FB && lv->verticalOffset == 0.25f);
    *p = (XrFoveationProfileFB)0xF0FE000000000001ull;
    return XR_SUCCESS;
}
F(, xrDestroyFoveationProfileFB, XrFoveationProfileFB p) { CHECK(p == (XrFoveationProfileFB)0xF0FE000000000001ull); return XR_SUCCESS; }
F(, xrUpdateSwapchainFB, XrSwapchain, const XrSwapchainStateBaseHeaderFB* st) {
    CHECK(st && st->type == XR_TYPE_SWAPCHAIN_STATE_FOVEATION_FB);
    auto* f = (const XrSwapchainStateFoveationFB*)st;
    CHECK(f->profile == (XrFoveationProfileFB)0xF0FE000000000001ull);
    mlog("fb foveation applied to a swapchain");
    return XR_SUCCESS;
}
F(, xrGetSwapchainStateFB, XrSwapchain, XrSwapchainStateBaseHeaderFB* st) {
    CHECK(st && st->type == XR_TYPE_SWAPCHAIN_STATE_FOVEATION_FB);
    ((XrSwapchainStateFoveationFB*)st)->profile = (XrFoveationProfileFB)0xF0FE000000000001ull;
    return XR_SUCCESS;
}

static XrResult XRAPI_CALL m_xrGetInstanceProcAddr(XrInstance, const char* n, PFN_xrVoidFunction* f);
struct E { const char* n; PFN_xrVoidFunction f; };
#define X(n) {#n, (PFN_xrVoidFunction)m_##n}
static const E kE[] = {X(xrGetInstanceProcAddr), X(xrEnumerateApiLayerProperties), X(xrEnumerateInstanceExtensionProperties), X(xrCreateInstance), X(xrDestroyInstance),
    X(xrGetInstanceProperties), X(xrPollEvent), X(xrResultToString), X(xrStructureTypeToString), X(xrGetSystem), X(xrGetSystemProperties), X(xrEnumerateEnvironmentBlendModes),
    X(xrCreateSession), X(xrDestroySession), X(xrEnumerateReferenceSpaces), X(xrCreateReferenceSpace), X(xrGetReferenceSpaceBoundsRect), X(xrCreateActionSpace), X(xrLocateSpace), X(xrDestroySpace),
    X(xrEnumerateViewConfigurations), X(xrGetViewConfigurationProperties), X(xrEnumerateViewConfigurationViews), X(xrEnumerateSwapchainFormats), X(xrCreateSwapchain), X(xrDestroySwapchain),
    X(xrEnumerateSwapchainImages), X(xrAcquireSwapchainImage), X(xrWaitSwapchainImage), X(xrReleaseSwapchainImage), X(xrBeginSession), X(xrEndSession), X(xrRequestExitSession),
    X(xrWaitFrame), X(xrBeginFrame), X(xrEndFrame), X(xrLocateViews), X(xrStringToPath), X(xrPathToString), X(xrCreateActionSet), X(xrDestroyActionSet), X(xrCreateAction), X(xrDestroyAction),
    X(xrSuggestInteractionProfileBindings), X(xrAttachSessionActionSets), X(xrGetCurrentInteractionProfile), X(xrGetActionStateBoolean), X(xrGetActionStateFloat), X(xrGetActionStateVector2f), X(xrGetActionStatePose),
    X(xrSyncActions), X(xrEnumerateBoundSourcesForAction), X(xrGetInputSourceLocalizedName), X(xrApplyHapticFeedback), X(xrStopHapticFeedback), X(xrGetD3D11GraphicsRequirementsKHR), X(xrGetVisibilityMaskKHR),
    X(xrConvertWin32PerformanceCounterToTimeKHR), X(xrConvertTimeToWin32PerformanceCounterKHR), X(xrLocateSpaces),
    X(xrPerfSettingsSetPerformanceLevelEXT), X(xrCreateEyeTrackerFB), X(xrDestroyEyeTrackerFB), X(xrGetEyeGazesFB),
    X(xrCreateHandTrackerEXT), X(xrDestroyHandTrackerEXT), X(xrLocateHandJointsEXT), X(xrEnumerateDisplayRefreshRatesFB), X(xrGetDisplayRefreshRateFB), X(xrRequestDisplayRefreshRateFB),
    X(xrCreateFoveationProfileFB), X(xrDestroyFoveationProfileFB), X(xrUpdateSwapchainFB), X(xrGetSwapchainStateFB)};
static XrResult XRAPI_CALL m_xrGetInstanceProcAddr(XrInstance, const char* n, PFN_xrVoidFunction* f) {
    for (auto& e : kE) if (!strcmp(e.n, n)) { *f = e.f; return XR_SUCCESS; }
    *f = nullptr;
    return XR_ERROR_FUNCTION_UNSUPPORTED;
}
extern "C" __declspec(dllexport) XrResult XRAPI_CALL xrNegotiateLoaderRuntimeInterface(const XrNegotiateLoaderInfo*, XrNegotiateRuntimeRequest* r) {
    r->runtimeInterfaceVersion = XR_CURRENT_LOADER_RUNTIME_VERSION;
    r->runtimeApiVersion = XR_MAKE_VERSION(1, 1, 0);
    r->getInstanceProcAddr = m_xrGetInstanceProcAddr;
    return XR_SUCCESS;
}
