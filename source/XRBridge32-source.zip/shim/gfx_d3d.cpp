// D3D11 and D3D12 game sides, plus the GPU-less test backend.
#include "gfx.h"
#include "../common/formats.h"
#include <cstring>

template <class T> static void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

static int64_t dxgiApp(int dxgi) { return xrbFindDxgi(dxgi) ? dxgi : -1; }
static int dxgiDxgi(int64_t app) { return xrbFindDxgi((int)app) ? (int)app : -1; }

// ---------------------------------------------------------------- D3D11
class D3D11Images : public GfxImages {
public:
    std::vector<ID3D11Texture2D*> tex;
    ~D3D11Images() override { for (auto*& t : tex) rel(t); }
    void fill(XrSwapchainImageBaseHeader* out, uint32_t count) override {
        auto* d = (XrSwapchainImageD3D11KHR*)out;
        for (uint32_t i = 0; i < count && i < tex.size(); ++i) d[i].texture = tex[i];
    }
};

class D3D11Session : public GfxSession {
    ID3D11Device* dev;
    ID3D11DeviceContext* ctx = nullptr;
    ID3D11DeviceContext4* ctx4 = nullptr;
    ID3D11Fence* fence = nullptr;
    ID3D11Query* query = nullptr;
    uint64_t value = 0;
public:
    explicit D3D11Session(const XrGraphicsBindingD3D11KHR& b) : dev(b.device) { if (dev) dev->AddRef(); }
    ~D3D11Session() override { rel(query); rel(fence); rel(ctx4); rel(ctx); rel(dev); }
    const char* name() const override { return "D3D11"; }
    XrStructureType imageType() const override { return XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR; }
    int64_t appFormat(int dxgi) const override { return dxgiApp(dxgi); }
    int dxgiFormat(int64_t app) const override { return dxgiDxgi(app); }

    XrResult init(HANDLE fenceHandle, const LUID& luid) override {
        if (!dev) return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        IDXGIDevice* dx = nullptr; IDXGIAdapter* ad = nullptr;
        if (SUCCEEDED(dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dx)) && SUCCEEDED(dx->GetAdapter(&ad))) {
            DXGI_ADAPTER_DESC d;
            bool match = SUCCEEDED(ad->GetDesc(&d)) && !memcmp(&d.AdapterLuid, &luid, sizeof(LUID));
            rel(ad); rel(dx);
            if (!match) { logf("D3D11: the game's GPU is not the headset's GPU"); return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
        }
        rel(dx);
        dev->GetImmediateContext(&ctx);
        ID3D11Device5* d5 = nullptr;
        if (fenceHandle && SUCCEEDED(dev->QueryInterface(__uuidof(ID3D11Device5), (void**)&d5))) {
            if (FAILED(d5->OpenSharedFence(fenceHandle, __uuidof(ID3D11Fence), (void**)&fence)) ||
                FAILED(ctx->QueryInterface(__uuidof(ID3D11DeviceContext4), (void**)&ctx4))) {
                rel(fence); rel(ctx4);
            }
            rel(d5);
        }
        if (fenceHandle) CloseHandle(fenceHandle);
        if (!fence) logf("D3D11: no shared fence, using CPU sync");
        return XR_SUCCESS;
    }
    XrResult open(const SwapchainInfo& info, const std::vector<uint64_t>& handles, GfxImages** out) override {
        auto* im = new D3D11Images();
        ID3D11Device1* d1 = nullptr;
        if (info.ntHandles && FAILED(dev->QueryInterface(__uuidof(ID3D11Device1), (void**)&d1))) { delete im; return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
        struct Rel { ID3D11Device1*& p; ~Rel() { rel(p); } } guard{d1};
        for (uint64_t h : handles) {
            ID3D11Texture2D* t = nullptr;
            HRESULT hr = d1 ? d1->OpenSharedResource1((HANDLE)(uintptr_t)h, __uuidof(ID3D11Texture2D), (void**)&t)
                            : dev->OpenSharedResource((HANDLE)(uintptr_t)h, __uuidof(ID3D11Texture2D), (void**)&t);
            if (FAILED(hr)) { logf("D3D11: OpenSharedResource failed 0x%08lx", hr); delete im; return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
            im->tex.push_back(t);
        }
        *out = im;
        return XR_SUCCESS;
    }
    uint64_t sync() override {
        if (fence && ctx4 && SUCCEEDED(ctx4->Signal(fence, value + 1))) {
            ++value;
            ctx->Flush(); // Signal alone can sit in the command buffer forever.
            return value;
        }
        if (!query) {
            D3D11_QUERY_DESC qd{D3D11_QUERY_EVENT, 0};
            if (FAILED(dev->CreateQuery(&qd, &query))) { ctx->Flush(); return 0; }
        }
        ctx->End(query);
        ctx->Flush();
        BOOL done = FALSE;
        for (int spins = 0; spins < 2000; ++spins) {
            if (ctx->GetData(query, &done, sizeof(done), 0) == S_OK && done) break;
            Sleep(0);
        }
        return 0;
    }
};
GfxSession* makeD3D11Session(const XrGraphicsBindingD3D11KHR& b) { return new D3D11Session(b); }

// ---------------------------------------------------------------- D3D12
class D3D12Images : public GfxImages {
public:
    std::vector<ID3D12Resource*> tex;
    ~D3D12Images() override { for (auto*& t : tex) rel(t); }
    void fill(XrSwapchainImageBaseHeader* out, uint32_t count) override {
        auto* d = (XrSwapchainImageD3D12KHR*)out;
        for (uint32_t i = 0; i < count && i < tex.size(); ++i) d[i].texture = tex[i];
    }
};

class D3D12Session : public GfxSession {
    ID3D12Device* dev;
    ID3D12CommandQueue* queue;
    ID3D12Fence* sharedFence = nullptr; // visible to the host
    ID3D12Fence* localFence = nullptr;  // CPU waits only
    HANDLE event = nullptr;
    uint64_t value = 0, localValue = 0;

    void waitLocal() {
        if (!localFence) return;
        ++localValue;
        if (SUCCEEDED(queue->Signal(localFence, localValue)) && SUCCEEDED(localFence->SetEventOnCompletion(localValue, event)))
            WaitForSingleObject(event, 5000);
    }
public:
    explicit D3D12Session(const XrGraphicsBindingD3D12KHR& b) : dev(b.device), queue(b.queue) {
        if (dev) dev->AddRef();
        if (queue) queue->AddRef();
    }
    ~D3D12Session() override {
        if (queue && localFence) waitLocal();
        if (event) CloseHandle(event);
        rel(localFence); rel(sharedFence); rel(queue); rel(dev);
    }
    const char* name() const override { return "D3D12"; }
    bool prefersNtHandles() const override { return true; }
    XrStructureType imageType() const override { return XR_TYPE_SWAPCHAIN_IMAGE_D3D12_KHR; }
    int64_t appFormat(int dxgi) const override { return dxgiApp(dxgi); }
    int dxgiFormat(int64_t app) const override { return dxgiDxgi(app); }

    XrResult init(HANDLE fenceHandle, const LUID& luid) override {
        if (!dev || !queue) return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        LUID devLuid = dev->GetAdapterLuid();
        if (memcmp(&devLuid, &luid, sizeof(LUID))) { logf("D3D12: the game's GPU is not the headset's GPU"); return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
        if (FAILED(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence), (void**)&localFence))) return XR_ERROR_RUNTIME_FAILURE;
        event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        if (fenceHandle) {
            if (FAILED(dev->OpenSharedHandle(fenceHandle, __uuidof(ID3D12Fence), (void**)&sharedFence))) sharedFence = nullptr;
            CloseHandle(fenceHandle);
        }
        if (!sharedFence) logf("D3D12: no shared fence, using CPU sync");
        return XR_SUCCESS;
    }
    XrResult open(const SwapchainInfo& info, const std::vector<uint64_t>& handles, GfxImages** out) override {
        auto* im = new D3D12Images();
        for (uint64_t h : handles) {
            ID3D12Resource* t = nullptr;
            HRESULT hr = dev->OpenSharedHandle((HANDLE)(uintptr_t)h, __uuidof(ID3D12Resource), (void**)&t);
            if (FAILED(hr)) { logf("D3D12: OpenSharedHandle failed 0x%08lx", hr); delete im; return XR_ERROR_GRAPHICS_DEVICE_INVALID; }
            im->tex.push_back(t);
        }
        // Imported resources start in COMMON. OpenXR says images are handed to the app in
        // RENDER_TARGET (colour) or DEPTH_WRITE (depth), and returned in that state.
        const bool depthImage = (info.usage & XR_SWAPCHAIN_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT) != 0;
        if ((info.usage & XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT) || depthImage) {
            ID3D12CommandAllocator* alloc = nullptr;
            ID3D12GraphicsCommandList* list = nullptr;
            HRESULT hr = dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&alloc);
            if (SUCCEEDED(hr)) hr = dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&list);
            if (FAILED(hr)) { rel(alloc); delete im; return XR_ERROR_RUNTIME_FAILURE; }
            for (auto* t : im->tex) {
                D3D12_RESOURCE_BARRIER b{};
                b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
                b.Transition.pResource = t;
                b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
                b.Transition.StateBefore = D3D12_RESOURCE_STATE_COMMON;
                b.Transition.StateAfter = depthImage ? D3D12_RESOURCE_STATE_DEPTH_WRITE : D3D12_RESOURCE_STATE_RENDER_TARGET;
                list->ResourceBarrier(1, &b);
            }
            list->Close();
            ID3D12CommandList* lists[] = {list};
            queue->ExecuteCommandLists(1, lists);
            waitLocal();
            rel(list); rel(alloc);
        }
        *out = im;
        return XR_SUCCESS;
    }
    uint64_t sync() override {
        if (sharedFence && SUCCEEDED(queue->Signal(sharedFence, value + 1))) return ++value;
        waitLocal();
        return 0;
    }
};
GfxSession* makeD3D12Session(const XrGraphicsBindingD3D12KHR& b) { return new D3D12Session(b); }

// ---------------------------------------------------------------- test backend
class NullImages : public GfxImages {
    XrStructureType type;
public:
    explicit NullImages(XrStructureType t) : type(t) {}
    void fill(XrSwapchainImageBaseHeader* out, uint32_t count) override {
        // Writes 1-based fake ids so tests can tell the array stride was right.
        for (uint32_t i = 0; i < count; ++i) {
            if (type == XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR) ((XrSwapchainImageVulkanKHR*)out)[i].image = (VkImage)(uintptr_t)(i + 1);
            else if (type == XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_KHR) ((XrSwapchainImageOpenGLKHR*)out)[i].image = i + 1;
            else if (type == XR_TYPE_SWAPCHAIN_IMAGE_D3D12_KHR) ((XrSwapchainImageD3D12KHR*)out)[i].texture = (ID3D12Resource*)(uintptr_t)(i + 1);
            else ((XrSwapchainImageD3D11KHR*)out)[i].texture = (ID3D11Texture2D*)(uintptr_t)(i + 1);
        }
    }
};
class NullSession : public GfxSession {
    XrStructureType binding;
public:
    explicit NullSession(XrStructureType b) : binding(b) {}
    const char* name() const override {
        return binding == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR ? "null/Vulkan" : binding == XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR ? "null/OpenGL"
             : binding == XR_TYPE_GRAPHICS_BINDING_D3D12_KHR ? "null/D3D12" : "null/D3D11";
    }
    XrStructureType imageType() const override {
        return binding == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR ? XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR : binding == XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR ? XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_KHR
             : binding == XR_TYPE_GRAPHICS_BINDING_D3D12_KHR ? XR_TYPE_SWAPCHAIN_IMAGE_D3D12_KHR : XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR;
    }
    int64_t appFormat(int dxgi) const override {
        const XrbFormat* f = xrbFindDxgi(dxgi);
        if (!f) return -1;
        if (binding == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR) return f->vk ? f->vk : -1;
        if (binding == XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR) return f->gl ? f->gl : -1;
        return dxgi;
    }
    int dxgiFormat(int64_t app) const override {
        const XrbFormat* f = binding == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR ? xrbFindVk((int)app)
                           : binding == XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR ? xrbFindGl((int)app) : xrbFindDxgi((int)app);
        return f ? f->dxgi : -1;
    }
    XrResult init(HANDLE fence, const LUID&) override { if (fence) CloseHandle(fence); return XR_SUCCESS; }
    XrResult open(const SwapchainInfo&, const std::vector<uint64_t>&, GfxImages** out) override { *out = new NullImages(imageType()); return XR_SUCCESS; }
    uint64_t sync() override { return 0; }
    bool bottomUp() const override { return binding == XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR; }
};
GfxSession* makeNullSession(XrStructureType b) { return new NullSession(b); }
