#!/bin/bash
# Cross-compiles everything from Linux with mingw-w64 (posix threads).
# Expects the Khronos OpenXR-SDK headers and static loaders at the paths below.
set -euo pipefail
cd "$(dirname "$0")"
SDK=${SDK:-/home/claude/src/OpenXR-SDK}
L64=${L64:-/home/claude/build-loader-x86_64/src/loader}
L32=${L32:-/home/claude/build-loader-i686/src/loader}
CFLAGS="-std=c++17 -O2 -Wall -Wno-unused-function -I$SDK/include"
STATIC="-static -static-libgcc -static-libstdc++ -s"
CXX64=x86_64-w64-mingw32-g++-posix
CXX32=i686-w64-mingw32-g++-posix
RC64=x86_64-w64-mingw32-windres
OUT=build/payload
mkdir -p "$OUT"

python3 tools/gen_marshal.py "$SDK/specification/registry/xr.xml" common/gen_marshal.inc > build/gen_marshal.log
python3 setup/make_icon.py setup/app.ico
printf '1 ICON "setup/app.ico"\n' > build/icon.rc
x86_64-w64-mingw32-windres build/icon.rc -O coff -o build/icon64.o
i686-w64-mingw32-windres build/icon.rc -O coff -o build/icon32.o

# 32-bit runtime. The .def keeps the export undecorated, because stdcall would
# otherwise export _xrNegotiateLoaderRuntimeInterface@8 and the loader would not find it.
$CXX32 $CFLAGS -Os -Ithird_party/vulkan-headers shim/shim.cpp shim/gfx_d3d.cpp shim/gfx_vulkan.cpp shim/gfx_opengl.cpp shim/shim.def -shared -o $OUT/xrbridge32.dll $STATIC -lopengl32 -lgdi32

# 64-bit host, statically linked with the Khronos loader so 64-bit API layers apply.
$CXX64 $CFLAGS -Os -mwindows host/host.cpp build/icon64.o -o $OUT/xrbridge_host.exe -L"$L64" -lopenxr_loader $STATIC -ld3d11 -ldxgi -ladvapi32 -lole32 -lpathcch -lshlwapi

# 32-bit smoke test, through the real 32-bit loader.
$CXX32 $CFLAGS -Ithird_party/vulkan-headers tests/selftest.cpp build/icon32.o -o $OUT/xrbridge_selftest32.exe -L"$L32" -lopenxr_loader $STATIC -ld3d11 -ldxgi -lopengl32 -lgdi32 -ladvapi32 -lole32 -lpathcch -lshlwapi

# D3D9 virtual screen proxies, one per architecture, named d3d9.dll when installed in a game.
$CXX32 $CFLAGS -Os d3d9proxy/d3d9proxy.cpp d3d9proxy/d3d9_32.def -shared -o $OUT/d3d9proxy32.dll -L"$L32" -lopenxr_loader $STATIC -ld3d11 -ldxgi -ladvapi32 -lole32 -lpathcch -lshlwapi
$CXX64 $CFLAGS -Os d3d9proxy/d3d9proxy.cpp d3d9proxy/d3d9.def -shared -o $OUT/d3d9proxy64.dll -L"$L64" -lopenxr_loader $STATIC -ld3d11 -ldxgi -ladvapi32 -lole32 -lpathcch -lshlwapi

# Test-only mock runtime, not shipped.
$CXX64 $CFLAGS tests/mock_runtime.cpp -shared -o build/mock_runtime.dll $STATIC -ld3d11 -ldxgi

# Installer with the payload embedded.
$RC64 -I setup -I "$OUT" setup/setup.rc -O coff -o build/setup_res.o
$CXX64 $CFLAGS -mwindows -municode setup/setup.cpp build/setup_res.o -o build/XRBridge32-Setup.exe $STATIC \
    -lcomdlg32 -lversion -ldwmapi -lcomctl32 -luuid -ladvapi32 -lshell32 -luser32 -lgdi32 -lole32

$CXX32 -std=c++17 -O1 tests/d3d9_app.cpp -o build/d3d9_app32.exe -static -lgdi32
$CXX64 -std=c++17 -O1 tests/d3d9_app.cpp -o build/d3d9_app64.exe -static -lgdi32
ls -la $OUT build/XRBridge32-Setup.exe
