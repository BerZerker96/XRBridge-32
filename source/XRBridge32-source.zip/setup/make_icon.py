#!/usr/bin/env python3
# Draws the XRBridge32 icon: a VR visor with an arc linking two lenses, on a dark tile.
# Supersampled at each size so small sizes stay clean. Usage: make_icon.py <out.ico> [preview.png]
import sys
from PIL import Image, ImageChops, ImageDraw


def gradient(size, a, b):
    """Diagonal two-colour gradient."""
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            t = (x + y) / (2 * size - 2)
            px[x, y] = tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)
    return img


def tile(size):
    ss = 4
    s = size * ss
    u = s / 256.0  # design units on a 256 grid

    def box(x0, y0, x1, y1):
        return [x0 * u, y0 * u, x1 * u, y1 * u]

    # Rounded dark tile.
    bg = gradient(s, (32, 37, 52), (15, 17, 26))
    tile_mask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(tile_mask).rounded_rectangle(box(8, 8, 248, 248), radius=52 * u, fill=255)
    out = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    out.paste(bg, (0, 0), tile_mask)

    # Visor: an accent-gradient band with two lens holes cut out.
    accent = gradient(s, (64, 214, 200), (136, 104, 255))
    mask = Image.new("L", (s, s), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle(box(36, 88, 220, 178), radius=34 * u, fill=255)
    d.ellipse(box(62, 110, 112, 160), fill=0)
    d.ellipse(box(144, 110, 194, 160), fill=0)
    d.polygon([(106 * u, 178 * u), (150 * u, 178 * u), (140 * u, 150 * u), (116 * u, 150 * u)], fill=0)
    out.paste(accent, (0, 0), mask)

    # The bridge: an arc over the visor joining the two lens centres.
    arc = Image.new("L", (s, s), 0)
    ad = ImageDraw.Draw(arc)
    w = int(14 * u) if size >= 32 else int(20 * u)
    ad.arc(box(84, 40, 172, 128), start=180, end=360, fill=255, width=w)
    r = (w / u) * 0.5
    ad.ellipse(box(84 - 0.0, 84 - r, 84 + 2 * r, 84 + r), fill=255)
    ad.ellipse(box(172 - 2 * r, 84 - r, 172, 84 + r), fill=255)
    out.paste(accent, (0, 0), arc)

    # Keep everything inside the tile.
    alpha = ImageChops.multiply(out.getchannel("A"), tile_mask)
    out.putalpha(alpha)
    return out.resize((size, size), Image.LANCZOS)


if __name__ == "__main__":
    sizes = [16, 20, 24, 32, 40, 48, 64, 128, 256]
    images = [tile(n) for n in sizes]
    images[-1].save(sys.argv[1], format="ICO", append_images=images[:-1], sizes=[(n, n) for n in sizes])
    if len(sys.argv) > 2:
        sheet = Image.new("RGBA", (256 + 128 + 64 + 48 + 32 + 16 + 70, 276), (40, 40, 44, 255))
        x = 10
        for n in [256, 128, 64, 48, 32, 16]:
            im = tile(n)
            sheet.paste(im, (x, 10), im)
            x += n + 10
        sheet.save(sys.argv[2])
