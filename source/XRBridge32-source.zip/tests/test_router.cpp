// Test-only runtime for 64-bit test runs. The loader ignores XR_RUNTIME_JSON in elevated
// processes, so a single registered runtime picks the target: the host gets the mock,
// and the test app gets the bridge.
#include <windows.h>
#include <openxr/openxr.h>
#include <openxr/openxr_loader_negotiation.h>
#include <cstring>
extern "C" __declspec(dllexport) XrResult XRAPI_CALL xrNegotiateLoaderRuntimeInterface(const XrNegotiateLoaderInfo* i, XrNegotiateRuntimeRequest* r) {
    char exe[MAX_PATH];
    GetModuleFileNameA(nullptr, exe, MAX_PATH);
    HMODULE m = LoadLibraryA(strstr(exe, "xrbridge_host") ? "C:\\xb\\mock\\mock_runtime.dll" : "C:\\xb\\bin32\\xrbridge32.dll");
    if (!m) return XR_ERROR_RUNTIME_UNAVAILABLE;
    auto fn = (PFN_xrNegotiateLoaderRuntimeInterface)GetProcAddress(m, "xrNegotiateLoaderRuntimeInterface");
    return fn ? fn(i, r) : XR_ERROR_RUNTIME_UNAVAILABLE;
}
