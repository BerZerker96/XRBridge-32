// d3d9.dll proxy: shows any flat Direct3D 9 game on a virtual screen in the headset.
//
// This is not stereo. True stereo for D3D9 needs per-game work (see the Dishonored and
// Mirror's Edge mods in the README). What it gives every D3D9 game is a large, head-stable
// screen rendered through OpenXR, with the runtime's reprojection keeping it smooth even
// when the game runs slowly.
//
// Flow: the game's Present is hooked, the back buffer is read back, and a separate thread
// runs the OpenXR frame loop at the headset's rate with the newest frame on a quad or
// cylinder layer. It uses the normal OpenXR loader, so a 32-bit game gets a native 32-bit
// runtime or the XRBridge32 bridge, and a 64-bit game gets the normal runtime.
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#include <windows.h>
#include <unknwn.h>
#include <d3d9.h>
#include <d3d11.h>
#include <dxgi.h>
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <atomic>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

// The installer finds this in the file to recognise its own proxy.
extern "C" __declspec(dllexport) const char XRBridgeD3D9Proxy[] = "XRB_D3D9_PROXY_MARKER_V1";

static HMODULE g_real;
static FILE* g_log;
static std::mutex g_logMutex;
static void logf(const char* fmt, ...) {
    std::lock_guard<std::mutex> l(g_logMutex);
    if (!g_log) {
        wchar_t dir[MAX_PATH];
        if (!GetEnvironmentVariableW(L"LOCALAPPDATA", dir, MAX_PATH)) return;
        std::wstring path = std::wstring(dir) + L"\\XRBridge32";
        CreateDirectoryW(path.c_str(), nullptr);
        path += L"\\d3d9.log";
        g_log = _wfopen(path.c_str(), L"w");
        if (!g_log) return;
    }
    va_list a; va_start(a, fmt); vfprintf(g_log, fmt, a); va_end(a);
    fputc('\n', g_log); fflush(g_log);
}

// ---------------------------------------------------------------- settings
struct Settings {
    float width = 3.0f;      // metres
    float distance = 2.5f;   // metres
    bool curved = true;
    int recenterKey = VK_F8;
} g_cfg;

static void loadSettings() {
    char exe[MAX_PATH];
    GetModuleFileNameA(nullptr, exe, MAX_PATH);
    std::string ini = exe;
    ini = ini.substr(0, ini.find_last_of('\\') + 1) + "xrb_d3d9.ini";
    char b[64];
    GetPrivateProfileStringA("screen", "width", "3.0", b, sizeof(b), ini.c_str());
    g_cfg.width = (float)atof(b);
    GetPrivateProfileStringA("screen", "distance", "2.5", b, sizeof(b), ini.c_str());
    g_cfg.distance = (float)atof(b);
    g_cfg.curved = GetPrivateProfileIntA("screen", "curved", 1, ini.c_str()) != 0;
    g_cfg.recenterKey = GetPrivateProfileIntA("screen", "recenterKey", VK_F8, ini.c_str());
    if (g_cfg.width < 0.1f) g_cfg.width = 3.0f;
    if (g_cfg.distance < 0.1f) g_cfg.distance = 2.5f;
}

// ---------------------------------------------------------------- shared frame
// One buffer written by the game, swapped to the XR thread. When the headset has not taken
// the last frame the readback is skipped, so a fast game does not stall on it for nothing.
struct Frame {
    std::vector<uint8_t> pixels; // BGRA8, tightly packed
    uint32_t width = 0, height = 0;
    uint64_t number = 0;
};
static std::mutex g_frameMutex;
static Frame g_ready;
static std::atomic<bool> g_frameTaken{true};
static std::atomic<bool> g_xrWantsFrames{false};
static std::atomic<bool> g_quit{false};
static std::thread g_xrThread;
static std::once_flag g_xrStart;

// ---------------------------------------------------------------- pixel conversion
static bool convertRow(D3DFORMAT f, const uint8_t* in, uint8_t* out, uint32_t w) {
    switch (f) {
    case D3DFMT_X8R8G8B8: case D3DFMT_A8R8G8B8:
        for (uint32_t x = 0; x < w; ++x) { out[x * 4] = in[x * 4]; out[x * 4 + 1] = in[x * 4 + 1]; out[x * 4 + 2] = in[x * 4 + 2]; out[x * 4 + 3] = 255; }
        return true;
    case D3DFMT_A8B8G8R8: case D3DFMT_X8B8G8R8:
        for (uint32_t x = 0; x < w; ++x) { out[x * 4] = in[x * 4 + 2]; out[x * 4 + 1] = in[x * 4 + 1]; out[x * 4 + 2] = in[x * 4]; out[x * 4 + 3] = 255; }
        return true;
    case D3DFMT_R5G6B5:
        for (uint32_t x = 0; x < w; ++x) {
            uint16_t p = ((const uint16_t*)in)[x];
            out[x * 4] = (uint8_t)((p & 31) * 255 / 31); out[x * 4 + 1] = (uint8_t)(((p >> 5) & 63) * 255 / 63); out[x * 4 + 2] = (uint8_t)(((p >> 11) & 31) * 255 / 31); out[x * 4 + 3] = 255;
        }
        return true;
    case D3DFMT_X1R5G5B5: case D3DFMT_A1R5G5B5:
        for (uint32_t x = 0; x < w; ++x) {
            uint16_t p = ((const uint16_t*)in)[x];
            out[x * 4] = (uint8_t)((p & 31) * 255 / 31); out[x * 4 + 1] = (uint8_t)(((p >> 5) & 31) * 255 / 31); out[x * 4 + 2] = (uint8_t)(((p >> 10) & 31) * 255 / 31); out[x * 4 + 3] = 255;
        }
        return true;
    case D3DFMT_A2R10G10B10:
        for (uint32_t x = 0; x < w; ++x) {
            uint32_t p = ((const uint32_t*)in)[x];
            out[x * 4] = (uint8_t)((p & 1023) >> 2); out[x * 4 + 1] = (uint8_t)(((p >> 10) & 1023) >> 2); out[x * 4 + 2] = (uint8_t)(((p >> 20) & 1023) >> 2); out[x * 4 + 3] = 255;
        }
        return true;
    case D3DFMT_A2B10G10R10:
        for (uint32_t x = 0; x < w; ++x) {
            uint32_t p = ((const uint32_t*)in)[x];
            out[x * 4] = (uint8_t)(((p >> 20) & 1023) >> 2); out[x * 4 + 1] = (uint8_t)(((p >> 10) & 1023) >> 2); out[x * 4 + 2] = (uint8_t)((p & 1023) >> 2); out[x * 4 + 3] = 255;
        }
        return true;
    default:
        return false;
    }
}

// ---------------------------------------------------------------- capture
// Reading a back buffer on the CPU stalls the game until the GPU catches up. Instead the
// back buffer is copied on the GPU into one of two slots, with an event query behind it, and
// read a frame or so later once the query says the copy is done. That costs one frame of
// latency on the virtual screen but nothing on the game's frame time.
struct CaptureSlot {
    IDirect3DSurface9* rt = nullptr; // default pool: released before every Reset
    IDirect3DQuery9* done = nullptr;
    bool pending = false;
};
static CaptureSlot g_slots[2];
static int g_nextSlot;
static IDirect3DSurface9* g_sysmem;
static UINT g_capW, g_capH;
static D3DFORMAT g_capFormat;
static uint64_t g_captureCount;
static bool g_badFormatLogged;

static void releaseCapture() {
    for (auto& sl : g_slots) {
        if (sl.rt) { sl.rt->Release(); sl.rt = nullptr; }
        if (sl.done) { sl.done->Release(); sl.done = nullptr; }
        sl.pending = false;
    }
    if (g_sysmem) { g_sysmem->Release(); g_sysmem = nullptr; }
    g_capW = g_capH = 0;
}

// Copies a finished slot to the CPU and hands it to the XR thread.
static void readSlot(IDirect3DDevice9* dev, CaptureSlot& sl) {
    sl.pending = false;
    if (FAILED(dev->GetRenderTargetData(sl.rt, g_sysmem))) return;
    D3DLOCKED_RECT lr;
    if (FAILED(g_sysmem->LockRect(&lr, nullptr, D3DLOCK_READONLY))) return;
    {
        std::lock_guard<std::mutex> l(g_frameMutex);
        g_ready.pixels.resize((size_t)g_capW * g_capH * 4);
        bool ok = true;
        for (UINT y = 0; y < g_capH && ok; ++y)
            ok = convertRow(g_capFormat, (const uint8_t*)lr.pBits + (size_t)lr.Pitch * y, g_ready.pixels.data() + (size_t)g_capW * 4 * y, g_capW);
        if (ok) {
            g_ready.width = g_capW; g_ready.height = g_capH; ++g_ready.number;
            if (g_captureCount++ == 0) {
                const uint8_t* p = g_ready.pixels.data();
                logf("first frame captured, top-left BGRA %02x%02x%02x%02x", p[0], p[1], p[2], p[3]);
            }
            g_frameTaken.store(false, std::memory_order_release);
        } else if (!g_badFormatLogged) {
            g_badFormatLogged = true;
            logf("back buffer format %d is not supported", (int)g_capFormat);
        }
    }
    g_sysmem->UnlockRect();
}

static void captureBackBuffer(IDirect3DDevice9* dev) {
    if (!g_xrWantsFrames.load(std::memory_order_relaxed)) return;
    // Collect the oldest copy the GPU has finished, if the headset is ready for a frame.
    if (g_frameTaken.load(std::memory_order_acquire)) {
        for (int k = 0; k < 2; ++k) {
            CaptureSlot& sl = g_slots[(g_nextSlot + k) % 2];
            if (sl.pending && sl.done->GetData(nullptr, 0, 0) == S_OK) { readSlot(dev, sl); break; }
        }
    }
    CaptureSlot& sl = g_slots[g_nextSlot];
    if (sl.pending) return; // both copies still in flight: the GPU is behind, so add no work
    IDirect3DSurface9* bb = nullptr;
    if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb)) || !bb) return;
    D3DSURFACE_DESC d;
    if (FAILED(bb->GetDesc(&d))) { bb->Release(); return; }
    if (d.Width != g_capW || d.Height != g_capH || d.Format != g_capFormat) {
        releaseCapture();
        bool ok = SUCCEEDED(dev->CreateOffscreenPlainSurface(d.Width, d.Height, d.Format, D3DPOOL_SYSTEMMEM, &g_sysmem, nullptr));
        for (auto& s2 : g_slots) {
            ok = ok && SUCCEEDED(dev->CreateRenderTarget(d.Width, d.Height, d.Format, D3DMULTISAMPLE_NONE, 0, FALSE, &s2.rt, nullptr));
            if (ok && FAILED(dev->CreateQuery(D3DQUERYTYPE_EVENT, &s2.done))) s2.done = nullptr; // read at once instead
        }
        if (!ok) {
            logf("could not create capture surfaces %ux%u format %d", d.Width, d.Height, (int)d.Format);
            releaseCapture();
            bb->Release();
            return;
        }
        g_capW = d.Width; g_capH = d.Height; g_capFormat = d.Format;
        logf("capturing %ux%u, D3D format %d, multisample %d, %s", d.Width, d.Height, (int)d.Format, (int)d.MultiSampleType,
             g_slots[0].done ? "asynchronous" : "synchronous");
    }
    // A GPU copy, which also resolves a multisampled back buffer.
    HRESULT hr = dev->StretchRect(bb, nullptr, sl.rt, nullptr, D3DTEXF_NONE);
    bb->Release();
    if (FAILED(hr)) return;
    g_nextSlot = (g_nextSlot + 1) % 2;
    if (sl.done) {
        sl.done->Issue(D3DISSUE_END);
        sl.pending = true;
    } else if (g_frameTaken.load(std::memory_order_acquire)) {
        readSlot(dev, sl);
    }
}

// ---------------------------------------------------------------- OpenXR thread
#define XR_CHECK(call) do { XrResult r_ = (call); if (XR_FAILED(r_)) { logf("%s failed: %d. The game continues flat.", #call, (int)r_); return; } } while (0)

static bool nullGfx() { char b[8]; return GetEnvironmentVariableA("XRB_NULL_GFX", b, sizeof(b)) > 0; }

// Yaw-only pose on a circle around the head, so the screen does not tilt with a nodding head.
static XrPosef placeScreen(XrSpace view, XrSpace local, XrTime t) {
    XrPosef out{{0, 0, 0, 1}, {0, 0, -g_cfg.distance}};
    XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
    if (XR_FAILED(xrLocateSpace(view, local, t, &loc)) || !(loc.locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT)) return out;
    const XrQuaternionf& q = loc.pose.orientation;
    float yaw = atan2f(2 * (q.w * q.y + q.x * q.z), 1 - 2 * (q.y * q.y + q.x * q.x));
    out.orientation = {0, sinf(yaw / 2), 0, cosf(yaw / 2)};
    if (g_cfg.curved) {
        // A cylinder layer is centred on its axis, which sits at the head.
        out.position = loc.pose.position;
    } else {
        out.position = {loc.pose.position.x - sinf(yaw) * g_cfg.distance, loc.pose.position.y, loc.pose.position.z - cosf(yaw) * g_cfg.distance};
    }
    return out;
}

static void xrThreadMain() {
    loadSettings();
    uint32_t n = 0;
    XR_CHECK(xrEnumerateInstanceExtensionProperties(nullptr, 0, &n, nullptr));
    std::vector<XrExtensionProperties> exts(n, {XR_TYPE_EXTENSION_PROPERTIES});
    XR_CHECK(xrEnumerateInstanceExtensionProperties(nullptr, n, &n, exts.data()));
    bool hasD3D11 = false, hasCylinder = false;
    for (auto& e : exts) {
        if (!strcmp(e.extensionName, XR_KHR_D3D11_ENABLE_EXTENSION_NAME)) hasD3D11 = true;
        if (!strcmp(e.extensionName, XR_KHR_COMPOSITION_LAYER_CYLINDER_EXTENSION_NAME)) hasCylinder = true;
    }
    if (!hasD3D11) { logf("this OpenXR runtime has no D3D11 support. The game continues flat."); return; }
    if (!hasCylinder) g_cfg.curved = false;
    std::vector<const char*> en = {XR_KHR_D3D11_ENABLE_EXTENSION_NAME};
    if (g_cfg.curved) en.push_back(XR_KHR_COMPOSITION_LAYER_CYLINDER_EXTENSION_NAME);

    XrInstanceCreateInfo ici{XR_TYPE_INSTANCE_CREATE_INFO};
    strcpy(ici.applicationInfo.applicationName, "XRBridge32 D3D9 screen");
    ici.applicationInfo.apiVersion = XR_MAKE_VERSION(1, 0, 0);
    ici.enabledExtensionCount = (uint32_t)en.size();
    ici.enabledExtensionNames = en.data();
    XrInstance inst = XR_NULL_HANDLE;
    XR_CHECK(xrCreateInstance(&ici, &inst));
    XrInstanceProperties ip{XR_TYPE_INSTANCE_PROPERTIES};
    if (XR_SUCCEEDED(xrGetInstanceProperties(inst, &ip))) logf("OpenXR runtime: %s", ip.runtimeName);

    XrSystemGetInfo sgi{XR_TYPE_SYSTEM_GET_INFO};
    sgi.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    XrSystemId sys = XR_NULL_SYSTEM_ID;
    XR_CHECK(xrGetSystem(inst, &sgi, &sys));
    PFN_xrGetD3D11GraphicsRequirementsKHR getReq = nullptr;
    XR_CHECK(xrGetInstanceProcAddr(inst, "xrGetD3D11GraphicsRequirementsKHR", (PFN_xrVoidFunction*)&getReq));
    XrGraphicsRequirementsD3D11KHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
    XR_CHECK(getReq(inst, sys, &rq));

    // Our own device on the headset's GPU. The game's D3D9 device is never shared with it.
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    const bool null = nullGfx();
    if (!null) {
        IDXGIFactory1* f = nullptr; IDXGIAdapter1* a = nullptr;
        if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&f))) { logf("no DXGI"); return; }
        for (UINT i = 0; f->EnumAdapters1(i, &a) == S_OK; ++i) {
            DXGI_ADAPTER_DESC1 d; a->GetDesc1(&d);
            if (!memcmp(&d.AdapterLuid, &rq.adapterLuid, sizeof(LUID))) break;
            a->Release(); a = nullptr;
        }
        f->Release();
        if (!a) { logf("no adapter matches the headset. The game continues flat."); return; }
        D3D_FEATURE_LEVEL fl = D3D_FEATURE_LEVEL_11_0;
        HRESULT hr = D3D11CreateDevice(a, D3D_DRIVER_TYPE_UNKNOWN, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, &fl, 1, D3D11_SDK_VERSION, &dev, nullptr, &ctx);
        a->Release();
        if (FAILED(hr)) { logf("D3D11CreateDevice failed 0x%08lx", hr); return; }
    }
    XrGraphicsBindingD3D11KHR gb{XR_TYPE_GRAPHICS_BINDING_D3D11_KHR};
    gb.device = dev;
    XrSessionCreateInfo sci{XR_TYPE_SESSION_CREATE_INFO, &gb, 0, sys};
    XrSession session = XR_NULL_HANDLE;
    XR_CHECK(xrCreateSession(inst, &sci, &session));

    uint32_t fc = 0;
    XR_CHECK(xrEnumerateSwapchainFormats(session, 0, &fc, nullptr));
    std::vector<int64_t> fmts(fc);
    XR_CHECK(xrEnumerateSwapchainFormats(session, fc, &fc, fmts.data()));
    // The bytes are already sRGB encoded, so sRGB swapchains show them as the game intended.
    int64_t chosen = 0;
    bool swizzle = false;
    for (int64_t f : fmts) if (f == DXGI_FORMAT_B8G8R8A8_UNORM_SRGB) chosen = f;
    if (!chosen) for (int64_t f : fmts) if (f == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB) { chosen = f; swizzle = true; }
    if (!chosen) for (int64_t f : fmts) if (f == DXGI_FORMAT_B8G8R8A8_UNORM) chosen = f;
    if (!chosen) for (int64_t f : fmts) if (f == DXGI_FORMAT_R8G8B8A8_UNORM) { chosen = f; swizzle = true; }
    if (!chosen) { logf("no 8-bit colour swapchain format is available. The game continues flat."); return; }
    logf("swapchain format %lld", (long long)chosen);

    XrReferenceSpaceCreateInfo rs{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
    rs.poseInReferenceSpace = {{0, 0, 0, 1}, {0, 0, 0}};
    rs.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_LOCAL;
    XrSpace local = XR_NULL_HANDLE, view = XR_NULL_HANDLE;
    XR_CHECK(xrCreateReferenceSpace(session, &rs, &local));
    rs.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_VIEW;
    XR_CHECK(xrCreateReferenceSpace(session, &rs, &view));

    XrSwapchain chain = XR_NULL_HANDLE;
    std::vector<ID3D11Texture2D*> images;
    ID3D11Texture2D* upload = nullptr;
    uint32_t chainW = 0, chainH = 0;
    std::vector<uint8_t> local_pixels;
    uint32_t frameW = 0, frameH = 0;
    bool haveImage = false, running = false, placed = false, keyDown = false;
    XrPosef screen{{0, 0, 0, 1}, {0, 0, -g_cfg.distance}};
    uint64_t submitted = 0;
    XrSessionState state = XR_SESSION_STATE_UNKNOWN;

    while (!g_quit.load()) {
        for (;;) {
            XrEventDataBuffer ev{XR_TYPE_EVENT_DATA_BUFFER};
            XrResult r = xrPollEvent(inst, &ev);
            if (r != XR_SUCCESS) break;
            if (ev.type == XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED) {
                state = ((XrEventDataSessionStateChanged*)&ev)->state;
                if (state == XR_SESSION_STATE_READY) {
                    XrSessionBeginInfo bi{XR_TYPE_SESSION_BEGIN_INFO};
                    bi.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
                    if (XR_SUCCEEDED(xrBeginSession(session, &bi))) running = true;
                    logf("session started");
                } else if (state == XR_SESSION_STATE_STOPPING) {
                    xrEndSession(session);
                    running = false;
                    g_xrWantsFrames = false;
                } else if (state == XR_SESSION_STATE_EXITING || state == XR_SESSION_STATE_LOSS_PENDING) {
                    logf("session ended by the runtime");
                    g_xrWantsFrames = false;
                    xrDestroyInstance(inst);
                    return;
                }
            }
        }
        if (!running) { Sleep(20); continue; }
        g_xrWantsFrames = true;

        XrFrameState fs{XR_TYPE_FRAME_STATE};
        if (XR_FAILED(xrWaitFrame(session, nullptr, &fs))) break;
        if (XR_FAILED(xrBeginFrame(session, nullptr))) break;

        if (!placed) { screen = placeScreen(view, local, fs.predictedDisplayTime); placed = true; }
        const bool down = (GetAsyncKeyState(g_cfg.recenterKey) & 0x8000) != 0;
        if (down && !keyDown) screen = placeScreen(view, local, fs.predictedDisplayTime);
        keyDown = down;

        // Newest game frame, if any. Taken by swap so the game thread never waits on the upload.
        bool newFrame = false;
        if (!g_frameTaken.load(std::memory_order_acquire)) {
            std::lock_guard<std::mutex> l(g_frameMutex);
            local_pixels.swap(g_ready.pixels);
            frameW = g_ready.width; frameH = g_ready.height;
            newFrame = true;
            g_frameTaken.store(true, std::memory_order_release);
        }
        if (newFrame && (frameW != chainW || frameH != chainH)) {
            if (chain) {
                xrDestroySwapchain(chain);
                images.clear();
                if (upload) { upload->Release(); upload = nullptr; }
            }
            XrSwapchainCreateInfo sc{XR_TYPE_SWAPCHAIN_CREATE_INFO};
            sc.usageFlags = XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT | XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
            sc.format = chosen; sc.sampleCount = 1; sc.width = frameW; sc.height = frameH; sc.faceCount = 1; sc.arraySize = 1; sc.mipCount = 1;
            if (XR_FAILED(xrCreateSwapchain(session, &sc, &chain))) { logf("xrCreateSwapchain failed"); break; }
            uint32_t ic = 0;
            xrEnumerateSwapchainImages(chain, 0, &ic, nullptr);
            std::vector<XrSwapchainImageD3D11KHR> im(ic, {XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR});
            xrEnumerateSwapchainImages(chain, ic, &ic, (XrSwapchainImageBaseHeader*)im.data());
            for (auto& i : im) images.push_back(i.texture);
            if (dev) {
                D3D11_TEXTURE2D_DESC td{};
                td.Width = frameW; td.Height = frameH; td.MipLevels = 1; td.ArraySize = 1; td.SampleDesc.Count = 1;
                td.Format = swizzle ? DXGI_FORMAT_R8G8B8A8_UNORM : DXGI_FORMAT_B8G8R8A8_UNORM;
                // A typed format of the same family, so a raw copy keeps the game's bytes.
                td.Format = (DXGI_FORMAT)chosen;
                td.Usage = D3D11_USAGE_DEFAULT;
                dev->CreateTexture2D(&td, nullptr, &upload);
            }
            chainW = frameW; chainH = frameH;
            logf("screen swapchain %ux%u", frameW, frameH);
        }
        if (newFrame && chain) {
            uint32_t idx = 0;
            if (XR_SUCCEEDED(xrAcquireSwapchainImage(chain, nullptr, &idx))) {
                XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
                wi.timeout = 100000000;
                XrResult wr = XR_TIMEOUT_EXPIRED;
                for (int tries = 0; tries < 20 && wr == XR_TIMEOUT_EXPIRED; ++tries) wr = xrWaitSwapchainImage(chain, &wi);
                if (wr == XR_SUCCESS) {
                    if (dev && upload && idx < images.size()) {
                        if (swizzle) {
                            uint8_t* p = local_pixels.data();
                            for (size_t i = 0; i < local_pixels.size(); i += 4) { uint8_t t = p[i]; p[i] = p[i + 2]; p[i + 2] = t; }
                        }
                        ctx->UpdateSubresource(upload, 0, nullptr, local_pixels.data(), frameW * 4, 0);
                        ctx->CopyResource(images[idx], upload);
                        ctx->Flush();
                    }
                    xrReleaseSwapchainImage(chain, nullptr);
                    haveImage = true;
                    ++submitted;
                }
            }
        }

        const XrCompositionLayerBaseHeader* layers[1];
        uint32_t layerCount = 0;
        XrCompositionLayerQuad quad{XR_TYPE_COMPOSITION_LAYER_QUAD};
        XrCompositionLayerCylinderKHR cyl{XR_TYPE_COMPOSITION_LAYER_CYLINDER_KHR};
        if (haveImage && fs.shouldRender && chainW) {
            XrSwapchainSubImage sub{};
            sub.swapchain = chain;
            sub.imageRect = {{0, 0}, {(int32_t)chainW, (int32_t)chainH}};
            if (g_cfg.curved) {
                cyl.space = local; cyl.eyeVisibility = XR_EYE_VISIBILITY_BOTH; cyl.subImage = sub; cyl.pose = screen;
                cyl.radius = g_cfg.distance;
                cyl.centralAngle = g_cfg.width / g_cfg.distance;
                cyl.aspectRatio = (float)chainW / (float)chainH;
                layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&cyl;
            } else {
                quad.space = local; quad.eyeVisibility = XR_EYE_VISIBILITY_BOTH; quad.subImage = sub; quad.pose = screen;
                quad.size = {g_cfg.width, g_cfg.width * chainH / chainW};
                layers[layerCount++] = (const XrCompositionLayerBaseHeader*)&quad;
            }
        }
        XrFrameEndInfo fe{XR_TYPE_FRAME_END_INFO};
        fe.displayTime = fs.predictedDisplayTime;
        fe.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
        fe.layerCount = layerCount;
        fe.layers = layers;
        if (XR_FAILED(xrEndFrame(session, &fe))) { logf("xrEndFrame failed"); break; }
        if (submitted == 1 && layerCount) { logf("first frame shown in the headset"); ++submitted; }
    }
    g_xrWantsFrames = false;
    xrDestroyInstance(inst);
}

// ---------------------------------------------------------------- vtable hooks
// Originals are kept per vtable: a game, overlay or wrapper (ReShade, a chained d3d9.dll) can
// hand out objects of different classes, and each must reach its own original function.
struct HookEntry { void** vtbl; int index; void* original; };
static HookEntry g_hooks[64];
static int g_hookCount;
static std::mutex g_hookMutex;
static void patchSlot(void* object, int index, void* hook) {
    void** vtbl = *(void***)object;
    std::lock_guard<std::mutex> l(g_hookMutex);
    if (vtbl[index] == hook) return;
    for (int i = 0; i < g_hookCount; ++i) if (g_hooks[i].vtbl == vtbl && g_hooks[i].index == index) return; // someone hooked over us
    if (g_hookCount == 64) return;
    DWORD old;
    if (!VirtualProtect(&vtbl[index], sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) return;
    g_hooks[g_hookCount++] = {vtbl, index, vtbl[index]};
    vtbl[index] = hook;
    VirtualProtect(&vtbl[index], sizeof(void*), old, &old);
    FlushInstructionCache(GetCurrentProcess(), &vtbl[index], sizeof(void*));
}
static void* original(void* object, int index) {
    void** vtbl = *(void***)object;
    std::lock_guard<std::mutex> l(g_hookMutex);
    void* any = nullptr;
    for (int i = 0; i < g_hookCount; ++i) if (g_hooks[i].index == index) {
        if (g_hooks[i].vtbl == vtbl) return g_hooks[i].original;
        if (!any) any = g_hooks[i].original;
    }
    return any; // reached through another hooker's copy of the vtable
}

// Slots are fixed by the COM ABI of IDirect3DDevice9 and friends.
enum { DEV_RESET = 16, DEV_PRESENT = 17, DEV_PRESENTEX = 121, DEV_RESETEX = 132, D3D_CREATEDEVICE = 16, D3D_CREATEDEVICEEX = 20, SC_PRESENT = 3 };

typedef HRESULT(STDMETHODCALLTYPE* PresentFn)(IDirect3DDevice9*, const RECT*, const RECT*, HWND, const RGNDATA*);
typedef HRESULT(STDMETHODCALLTYPE* ResetFn)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
typedef HRESULT(STDMETHODCALLTYPE* PresentExFn)(IDirect3DDevice9Ex*, const RECT*, const RECT*, HWND, const RGNDATA*, DWORD);
typedef HRESULT(STDMETHODCALLTYPE* ResetExFn)(IDirect3DDevice9Ex*, D3DPRESENT_PARAMETERS*, D3DDISPLAYMODEEX*);
typedef HRESULT(STDMETHODCALLTYPE* CreateDeviceFn)(IDirect3D9*, UINT, D3DDEVTYPE, HWND, DWORD, D3DPRESENT_PARAMETERS*, IDirect3DDevice9**);
typedef HRESULT(STDMETHODCALLTYPE* CreateDeviceExFn)(IDirect3D9Ex*, UINT, D3DDEVTYPE, HWND, DWORD, D3DPRESENT_PARAMETERS*, D3DDISPLAYMODEEX*, IDirect3DDevice9Ex**);
typedef HRESULT(STDMETHODCALLTYPE* SwapPresentFn)(IDirect3DSwapChain9*, const RECT*, const RECT*, HWND, const RGNDATA*, DWORD);

static DWORD g_presentGuard = TLS_OUT_OF_INDEXES; // a swap chain Present can call the device's

static void beforePresent(IDirect3DDevice9* dev) {
    std::call_once(g_xrStart, [] { g_xrThread = std::thread(xrThreadMain); g_xrThread.detach(); });
    if (TlsGetValue(g_presentGuard)) return;
    TlsSetValue(g_presentGuard, (void*)1);
    captureBackBuffer(dev);
    TlsSetValue(g_presentGuard, nullptr);
}
static HRESULT STDMETHODCALLTYPE hkPresent(IDirect3DDevice9* d, const RECT* a, const RECT* b, HWND c, const RGNDATA* e) {
    beforePresent(d);
    return ((PresentFn)original(d, DEV_PRESENT))(d, a, b, c, e);
}
static HRESULT STDMETHODCALLTYPE hkPresentEx(IDirect3DDevice9Ex* d, const RECT* a, const RECT* b, HWND c, const RGNDATA* e, DWORD f) {
    beforePresent(d);
    return ((PresentExFn)original(d, DEV_PRESENTEX))(d, a, b, c, e, f);
}
static HRESULT STDMETHODCALLTYPE hkSwapPresent(IDirect3DSwapChain9* s, const RECT* a, const RECT* b, HWND c, const RGNDATA* e, DWORD f) {
    IDirect3DDevice9* d = nullptr;
    if (SUCCEEDED(s->GetDevice(&d)) && d) {
        beforePresent(d);
        d->Release();
    }
    return ((SwapPresentFn)original(s, SC_PRESENT))(s, a, b, c, e, f);
}
// Default-pool surfaces block Reset, so ours must go first.
static HRESULT STDMETHODCALLTYPE hkReset(IDirect3DDevice9* d, D3DPRESENT_PARAMETERS* p) {
    releaseCapture();
    return ((ResetFn)original(d, DEV_RESET))(d, p);
}
static HRESULT STDMETHODCALLTYPE hkResetEx(IDirect3DDevice9Ex* d, D3DPRESENT_PARAMETERS* p, D3DDISPLAYMODEEX* m) {
    releaseCapture();
    return ((ResetExFn)original(d, DEV_RESETEX))(d, p, m);
}
static void hookDevice(IDirect3DDevice9* d) {
    patchSlot(d, DEV_PRESENT, (void*)hkPresent);
    patchSlot(d, DEV_RESET, (void*)hkReset);
    IDirect3DSwapChain9* sc = nullptr;
    if (SUCCEEDED(d->GetSwapChain(0, &sc)) && sc) {
        patchSlot(sc, SC_PRESENT, (void*)hkSwapPresent);
        sc->Release();
    }
    IDirect3DDevice9Ex* ex = nullptr;
    if (SUCCEEDED(d->QueryInterface(__uuidof(IDirect3DDevice9Ex), (void**)&ex)) && ex) {
        patchSlot(ex, DEV_PRESENTEX, (void*)hkPresentEx);
        patchSlot(ex, DEV_RESETEX, (void*)hkResetEx);
        ex->Release();
    }
    logf("device hooked");
}
static HRESULT STDMETHODCALLTYPE hkCreateDevice(IDirect3D9* o, UINT a, D3DDEVTYPE t, HWND w, DWORD f, D3DPRESENT_PARAMETERS* p, IDirect3DDevice9** out) {
    HRESULT hr = ((CreateDeviceFn)original(o, D3D_CREATEDEVICE))(o, a, t, w, f, p, out);
    if (SUCCEEDED(hr) && out && *out) hookDevice(*out);
    return hr;
}
static HRESULT STDMETHODCALLTYPE hkCreateDeviceEx(IDirect3D9Ex* o, UINT a, D3DDEVTYPE t, HWND w, DWORD f, D3DPRESENT_PARAMETERS* p, D3DDISPLAYMODEEX* m, IDirect3DDevice9Ex** out) {
    HRESULT hr = ((CreateDeviceExFn)original(o, D3D_CREATEDEVICEEX))(o, a, t, w, f, p, m, out);
    if (SUCCEEDED(hr) && out && *out) hookDevice(*out);
    return hr;
}

// ---------------------------------------------------------------- exports
static void loadReal() {
    if (g_real) return;
    // A wrapper already in the game folder keeps working: Setup renames it to d3d9_chain.dll.
    wchar_t path[MAX_PATH];
    GetModuleFileNameW(nullptr, path, MAX_PATH);
    std::wstring chain = path;
    chain = chain.substr(0, chain.find_last_of(L'\\') + 1) + L"d3d9_chain.dll";
    g_real = LoadLibraryW(chain.c_str());
    if (g_real) { logf("using d3d9_chain.dll"); return; }
    GetSystemDirectoryW(path, MAX_PATH);
    g_real = LoadLibraryW((std::wstring(path) + L"\\d3d9.dll").c_str());
    if (!g_real) logf("could not load the system d3d9.dll");
}
static FARPROC realProc(const char* name) {
    loadReal();
    return g_real ? GetProcAddress(g_real, name) : nullptr;
}

extern "C" {
IDirect3D9* WINAPI Direct3DCreate9(UINT v) {
    auto fn = (IDirect3D9*(WINAPI*)(UINT))realProc("Direct3DCreate9");
    IDirect3D9* d = fn ? fn(v) : nullptr;
    if (d) patchSlot(d, D3D_CREATEDEVICE, (void*)hkCreateDevice);
    return d;
}
HRESULT WINAPI Direct3DCreate9Ex(UINT v, IDirect3D9Ex** out) {
    auto fn = (HRESULT(WINAPI*)(UINT, IDirect3D9Ex**))realProc("Direct3DCreate9Ex");
    if (!fn) return E_NOTIMPL;
    HRESULT hr = fn(v, out);
    if (SUCCEEDED(hr) && out && *out) {
        patchSlot(*out, D3D_CREATEDEVICE, (void*)hkCreateDevice);
        patchSlot(*out, D3D_CREATEDEVICEEX, (void*)hkCreateDeviceEx);
    }
    return hr;
}
#define FWD(ret, name, sig, args, fallback) ret WINAPI name sig { auto fn = (ret(WINAPI*) sig)realProc(#name); return fn ? fn args : fallback; }
FWD(int, D3DPERF_BeginEvent, (D3DCOLOR a, LPCWSTR b), (a, b), -1)
FWD(int, D3DPERF_EndEvent, (void), (), -1)
FWD(BOOL, D3DPERF_QueryRepeatFrame, (void), (), FALSE)
FWD(DWORD, D3DPERF_GetStatus, (void), (), 0)
void WINAPI D3DPERF_SetMarker(D3DCOLOR a, LPCWSTR b) { auto fn = (void(WINAPI*)(D3DCOLOR, LPCWSTR))realProc("D3DPERF_SetMarker"); if (fn) fn(a, b); }
void WINAPI D3DPERF_SetRegion(D3DCOLOR a, LPCWSTR b) { auto fn = (void(WINAPI*)(D3DCOLOR, LPCWSTR))realProc("D3DPERF_SetRegion"); if (fn) fn(a, b); }
void WINAPI D3DPERF_SetOptions(DWORD a) { auto fn = (void(WINAPI*)(DWORD))realProc("D3DPERF_SetOptions"); if (fn) fn(a); }
void* WINAPI Direct3DShaderValidatorCreate9(void) { auto fn = (void*(WINAPI*)(void))realProc("Direct3DShaderValidatorCreate9"); return fn ? fn() : nullptr; }
void WINAPI PSGPError(void* a, DWORD b, DWORD c) { auto fn = (void(WINAPI*)(void*, DWORD, DWORD))realProc("PSGPError"); if (fn) fn(a, b, c); }
void WINAPI PSGPSampleTexture(void* a, DWORD b, float* c, DWORD d, float* e) { auto fn = (void(WINAPI*)(void*, DWORD, float*, DWORD, float*))realProc("PSGPSampleTexture"); if (fn) fn(a, b, c, d, e); }
void WINAPI Direct3D9EnableMaximizedWindowedModeShim(UINT a) { auto fn = (void(WINAPI*)(UINT))realProc("Direct3D9EnableMaximizedWindowedModeShim"); if (fn) fn(a); }
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD why, LPVOID) {
    if (why == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        g_presentGuard = TlsAlloc();
    } else if (why == DLL_PROCESS_DETACH) {
        g_quit = true;
    }
    return TRUE;
}
