#!/usr/bin/env python3
"""Generates 32/64-bit OpenXR marshalling from the Khronos registry (xr.xml).

Every struct whose data can cross a process boundary gets four functions, compiled
natively on each side so field offsets are always right:
  sI_T  write what the app passes in (including the shape of output arrays)
  dI_T  rebuild it on the other side, allocating from an Arena
  sO_T  write results back
  dO_T  store results into the app's struct, keeping its pointers

Every extension function whose parameters are all portable gets a shim thunk and a host
case. An extension is exposed only when ALL of its functions and structs are portable, so
the bridge never advertises something it would silently break.

Usage: gen_marshal.py <xr.xml> <out.inc>
"""
import re
import sys
import xml.etree.ElementTree as ET

xml_path, out_path = sys.argv[1], sys.argv[2]
reg = ET.parse(xml_path).getroot()

# Graphics bindings are done by hand on top of the host's D3D11 session, the loader owns
# debug utils and the loader-init extensions, and headless sessions have no binding at all.
EXCLUDED_EXT = re.compile(
    r"^(XR_KHR_(D3D11|D3D12|vulkan|opengl|android|loader|win32_convert|visibility_mask|metal)|XR_EXT_debug_utils|"
    r"XR_MND_headless|XR_MNDX_egl|XR_EXT_(win32|android|conformance|thermal_query_android)|XR_MNDX_force_feedback_curl_x)")
# Core and hand-written functions are never generated.
HAND_FUNCS = {"xrGetVisibilityMaskKHR", "xrConvertWin32PerformanceCounterToTimeKHR", "xrConvertTimeToWin32PerformanceCounterKHR"}
POD_BASE = {"char", "float", "double", "int8_t", "uint8_t", "int16_t", "uint16_t", "int32_t", "uint32_t", "int64_t", "uint64_t",
            "size_t_never", "wchar_t"}


class Member:
    def __init__(self, el):
        self.type = el.find("type").text
        self.name = el.find("name").text
        text = "".join(el.itertext())
        self.raw = text
        before = text[: text.index(self.name)]
        after = text[text.index(self.name) + len(self.name):]
        self.stars = before.count("*")
        self.const = before.strip().startswith("const") or "const" in before
        self.const_ptr_to_ptr = before.count("const") >= 2
        self.array = "[" in after
        self.len = el.get("len")
        self.optional = el.get("optional")
        self.values = el.get("values")


types = {}
for t in reg.find("types"):
    name = t.get("name") or (t.find("name").text if t.find("name") is not None else None)
    if not name:
        continue
    types[name] = t

structs, cat = {}, {}
children = {}
aliases = {}
for name, t in types.items():
    c = t.get("category")
    cat[name] = c
    if t.get("alias"):
        aliases[name] = t.get("alias")
    if c == "struct" and not t.get("alias"):
        structs[name] = [Member(m) for m in t.findall("member")]
        p = t.get("parentstruct")
        if p:
            children.setdefault(p, []).append(name)

commands = {}
for group in reg.findall("commands"):
    for c in group.findall("command"):
        if c.get("alias") or c.find("proto") is None:
            continue
        name = c.find("proto/name").text
        commands[name] = [Member(p) for p in c.findall("param")]

# Types and commands behind platform guards cannot be named in a portable build.
protected_types, protected_cmds = set(), set()
ext_requires = {}
for e in reg.find("extensions"):
    name = e.get("name")
    if e.get("supported") == "disabled":
        continue
    ts, cs = set(), set()
    for r in e.findall("require"):
        for x in r.findall("type"):
            ts.add(x.get("name"))
        for x in r.findall("command"):
            cs.add(x.get("name"))
    ext_requires[name] = (ts, cs, e)
for n, t in types.items():
    if t.get("protect"):
        protected_types.add(n)
for group in reg.findall("commands"):
    for c in group.findall("command"):
        if c.get("protect") and c.find("proto") is not None:
            protected_cmds.add(c.find("proto/name").text)
for name, (ts, cs, e) in ext_requires.items():
    if e.get("protect") or e.get("platform") or EXCLUDED_EXT.match(name):
        protected_types |= {t for t in ts if not cat.get(t) in (None, "enum", "define", "bitmask", "handle", "basetype")}
        protected_cmds |= cs


def resolve(t):
    while t in aliases:
        t = aliases[t]
    return t


def is_scalar(t):
    t = resolve(t)
    return t in POD_BASE or cat.get(t) in ("basetype", "bitmask", "enum", "handle")


memo_plain = {}


def is_plain(t):
    """Same bytes in both architectures: no pointers anywhere."""
    t = resolve(t)
    if t in memo_plain:
        return memo_plain[t]
    if is_scalar(t):
        return True
    if t not in structs or t in protected_types:
        return False
    memo_plain[t] = False
    ok = all(m.stars == 0 and is_plain(m.type) for m in structs[t])
    memo_plain[t] = ok
    return ok


memo_port = {}


def is_typed(t):
    return t in structs and any(m.name == "type" and m.type == "XrStructureType" for m in structs[t])


def is_polymorphic(t):
    return t in children


def member_ok(m, owner):
    t = resolve(m.type)
    if m.name == "next" and t == "void":
        return True
    if m.stars == 0:
        return is_plain(t) or is_portable(t)
    if t == "void":
        return bool(m.len) and m.stars == 1 and m.len in [x.name for x in owner]
    if t == "char":
        if m.stars == 1 and m.len == "null-terminated":
            return True
        if m.stars == 2 and m.len and m.len.split(",")[0] in [x.name for x in owner]:
            return True
        if m.stars == 1 and m.len and m.len.split(",")[0] in [x.name for x in owner]:
            return True
        return False
    if m.stars == 1:
        if is_polymorphic(t):
            return not m.len and all(is_portable(c) for c in children[t])
        if not (is_plain(t) or is_portable(t)):
            return False
        if not m.len:
            return True
        return m.len.split(",")[0] in [x.name for x in owner]
    if m.stars == 2 and is_polymorphic(t):
        # Only arrays of const pointers can be rebuilt on the other side.
        if m.raw.count("const") < 2:
            return False
        return bool(m.len) and m.len.split(",")[0] in [x.name for x in owner] and all(is_portable(c) for c in children[t])
    return False


def is_portable(t):
    t = resolve(t)
    if t in memo_port:
        return memo_port[t]
    if t not in structs or t in protected_types:
        return False
    memo_port[t] = True  # recursion guard
    ok = all(member_ok(m, structs[t]) for m in structs[t])
    memo_port[t] = ok
    return ok


def is_mutable(t):
    t = resolve(t)
    # Events are returned by the runtime even though their `next` is declared const.
    return t in structs and (types[t].get("returnedonly") == "true" or any(m.name == "next" and not m.const for m in structs[t]))


def field_len(m, prefix):
    return f"{prefix}{m.len.split(',')[0]}"


def gen_struct(t, w):
    ms = structs[t]
    out = []
    # ---- sI
    out.append(f"static void sI_{t}(Writer& w, const {t}& s) {{ (void)w; (void)s;")
    for m in ms:
        ty = resolve(m.type)
        if m.name == "next" and ty == "void":
            out.append("  chainIn(w, s.next);")
        elif m.stars == 0:
            if m.array or is_plain(ty):
                out.append(f"  w.raw(&s.{m.name}, sizeof(s.{m.name}));")
            else:
                out.append(f"  sI_{ty}(w, s.{m.name});")
        elif ty == "char" and m.stars == 1 and m.len == "null-terminated":
            out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.str(s.{m.name});")
        elif ty == "char" and m.stars == 2:
            out.append(f"  for (uint32_t i = 0; i < (uint32_t)s.{m.len.split(',')[0]}; ++i) w.str(s.{m.name} ? s.{m.name}[i] : \"\");")
        elif ty in ("char", "void") or (m.len and is_plain(ty)):
            cnt = f"s.{m.len.split(',')[0]}"
            es = "1" if ty in ("char", "void") else f"sizeof({m.type})"
            if m.const:
                out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.raw(s.{m.name}, (size_t){cnt} * {es});")
            else:
                out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0));")
        elif m.stars == 2:
            out.append(f"  for (uint32_t i = 0; i < (uint32_t)s.{m.len.split(',')[0]}; ++i) sIAny(w, s.{m.name}[i]);")
        elif is_polymorphic(ty):
            out.append(f"  sIAny(w, s.{m.name});")
        elif m.len:
            cnt = f"s.{m.len.split(',')[0]}"
            out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) sI_{ty}(w, s.{m.name}[i]);")
        else:
            if is_plain(ty):
                out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.raw(s.{m.name}, sizeof(*s.{m.name}));")
            else:
                out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) sI_{ty}(w, *s.{m.name});")
    out.append("}")
    # ---- dI
    out.append(f"static void dI_{t}(Reader& r, {t}& s, Arena& a) {{ (void)r; (void)s; (void)a;")
    for m in ms:
        ty = resolve(m.type)
        lhs = f"s.{m.name}"
        if m.name == "next" and ty == "void":
            out.append(f"  {lhs} = (decltype({lhs}))dChainIn(r, a);")
        elif m.stars == 0:
            if m.array or is_plain(ty):
                out.append(f"  r.raw(&{lhs}, sizeof({lhs}));")
            else:
                out.append(f"  dI_{ty}(r, {lhs}, a);")
        elif ty == "char" and m.stars == 1 and m.len == "null-terminated":
            out.append(f"  {lhs} = r.get<uint8_t>() ? a.str(r.str()) : nullptr;")
        elif ty == "char" and m.stars == 2:
            cnt = f"s.{m.len.split(',')[0]}"
            out.append(f"  {{ auto* p = a.alloc<const char*>({cnt}); for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) p[i] = a.str(r.str()); {lhs} = p; }}")
        elif ty in ("char", "void") or (m.len and is_plain(ty)):
            cnt = f"s.{m.len.split(',')[0]}"
            el = "uint8_t" if ty == "void" else "char" if ty == "char" else m.type
            cast = f"({'const ' if m.const else ''}{'void' if ty == 'void' else el}*)"
            if m.const:
                out.append(f"  if (r.get<uint8_t>()) {{ auto* p = a.alloc<{el}>({cnt}); r.raw((void*)p, (size_t){cnt} * sizeof({el})); {lhs} = {cast}p; }} else {lhs} = nullptr;")
            else:
                out.append(f"  if (r.get<uint8_t>()) {lhs} = {cast}a.alloc<{el}>({cnt}); else {lhs} = nullptr;")
        elif m.stars == 2:
            cnt = f"s.{m.len.split(',')[0]}"
            q = f"const {m.type}*"
            out.append(f"  {{ auto* p = a.alloc<{q}>({cnt}); for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) p[i] = (const {m.type}*)dIAny(r, a); {lhs} = p; }}")
        elif is_polymorphic(ty):
            out.append(f"  {lhs} = ({'const ' if m.const else ''}{m.type}*)dIAny(r, a);")
        elif m.len:
            cnt = f"s.{m.len.split(',')[0]}"
            out.append(f"  if (r.get<uint8_t>()) {{ auto* p = a.alloc<{ty}>({cnt}); for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) dI_{ty}(r, p[i], a); {lhs} = p; }} else {lhs} = nullptr;")
        else:
            if is_plain(ty):
                c = "const " if m.const else ""
                out.append(f"  if (r.get<uint8_t>()) {{ auto* p = a.alloc<{ty}>(1); r.raw(p, sizeof(*p)); {lhs} = ({c}{ty}*)p; }} else {lhs} = nullptr;")
            else:
                out.append(f"  if (r.get<uint8_t>()) {{ auto* p = a.alloc<{ty}>(1); dI_{ty}(r, *p, a); {lhs} = p; }} else {lhs} = nullptr;")
    out.append("}")
    # ---- sO / dO: only for what the runtime can write
    if is_mutable(t) or cat.get(t) == "struct":
        out.append(f"static void sO_{t}(Writer& w, const {t}& s) {{ (void)w; (void)s;")
        d = [f"static void dO_{t}(Reader& r, {t}& s) {{ (void)r; (void)s;"]
        for m in ms:
            ty = resolve(m.type)
            if m.name == "next" and ty == "void":
                if not m.const:
                    out.append("  chainOut(w, s.next);")
                    d.append("  dChainOut(r, s.next);")
            elif m.stars == 0:
                if m.name == "type":
                    continue
                if m.array or is_plain(ty):
                    out.append(f"  w.raw(&s.{m.name}, sizeof(s.{m.name}));")
                    d.append(f"  r.raw((void*)&s.{m.name}, sizeof(s.{m.name}));")
                else:
                    out.append(f"  sO_{ty}(w, s.{m.name});")
                    d.append(f"  dO_{ty}(r, s.{m.name});")
            elif not m.const and m.stars == 1 and ty != "void" and (m.len or True) and not is_polymorphic(ty):
                if ty == "char" and m.len and m.len != "null-terminated":
                    cnt = f"s.{m.len.split(',')[0]}"
                    out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.raw(s.{m.name}, (size_t){cnt});")
                    d.append(f"  if (r.get<uint8_t>()) r.raw(s.{m.name}, (size_t){cnt});")
                elif ty == "char":
                    continue
                elif m.len:
                    cnt = f"s.{m.len.split(',')[0]}"
                    if is_plain(ty):
                        out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.raw(s.{m.name}, (size_t){cnt} * sizeof({ty}));")
                        d.append(f"  if (r.get<uint8_t>()) r.raw(s.{m.name}, (size_t){cnt} * sizeof({ty}));")
                    else:
                        out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) sO_{ty}(w, s.{m.name}[i]);")
                        d.append(f"  if (r.get<uint8_t>()) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) dO_{ty}(r, s.{m.name}[i]);")
                else:
                    if is_plain(ty):
                        out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.raw(s.{m.name}, sizeof(*s.{m.name}));")
                        d.append(f"  if (r.get<uint8_t>()) r.raw(s.{m.name}, sizeof(*s.{m.name}));")
                    else:
                        out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) sO_{ty}(w, *s.{m.name});")
                        d.append(f"  if (r.get<uint8_t>()) dO_{ty}(r, *s.{m.name});")
            elif not m.const and m.stars == 1 and ty == "void" and m.len:
                cnt = f"s.{m.len.split(',')[0]}"
                out.append(f"  w.put((uint8_t)(s.{m.name} ? 1 : 0)); if (s.{m.name}) w.raw(s.{m.name}, (size_t){cnt});")
                d.append(f"  if (r.get<uint8_t>()) r.raw(s.{m.name}, (size_t){cnt});")
        out.append("}")
        d.append("}")
        out += d
    w.extend(out)


def topo():
    seen, order = set(), []

    def visit(t):
        if t in seen:
            return
        seen.add(t)
        for m in structs[t]:
            ty = resolve(m.type)
            if ty in structs and is_portable(ty) and not is_polymorphic(ty):
                visit(ty)
        order.append(t)

    for t in structs:
        if is_portable(t):
            visit(t)
    return order


port = topo()
typed_port = [t for t in port if is_typed(t) and types[t].get("structextends") is not None or (is_typed(t))]


def type_value(t):
    for m in structs[t]:
        if m.name == "type" and m.values:
            return m.values
    return None


def cmd_ok(name):
    if name in protected_cmds or name in HAND_FUNCS or name not in commands:
        return False
    ps = commands[name]
    names = [p.name for p in ps]
    for p in ps:
        t = resolve(p.type)
        if p.array:
            return False  # fixed-size array parameters are the core string functions
        if p.stars == 0:
            if not is_plain(t):
                return False
        elif t == "void":
            return False
        elif t == "char":
            if p.stars != 1:
                return False
            if not (p.len == "null-terminated" or (p.len and p.len.split(",")[0] in names)):
                return False
        elif p.stars == 1:
            if is_polymorphic(t):
                # A function can be carried when some of the struct types it accepts can be.
                # The thunk refuses the others before the call leaves the game, so the
                # runtime never sees a struct it was not sent (XR_FB_swapchain_update_state:
                # the foveation state crosses, the Android and GLES sampler states cannot).
                if p.len or not any(is_portable(c) for c in children[t]):
                    return False
            elif p.len and p.len.split(",")[0] not in names:
                return False
            elif not (is_plain(t) or is_portable(t)):
                return False
        else:
            return False
    return True


exposed, gen_cmds = [], []
for name, (ts, cs, e) in sorted(ext_requires.items()):
    if EXCLUDED_EXT.match(name) or e.get("protect") or e.get("platform"):
        continue
    bad = False
    for c in cs:
        if c in HAND_FUNCS:
            continue
        if c in commands and not cmd_ok(c):
            bad = True
    for t in ts:
        if t in structs and not is_portable(t) and not is_polymorphic(t) and not cat.get(t) == "union":
            bad = True
        if cat.get(t) == "union":
            bad = True
    if bad:
        continue
    exposed.append(name)
    gen_cmds += [c for c in sorted(cs) if c in commands and c not in HAND_FUNCS and c not in gen_cmds]

w = ["// GENERATED by tools/gen_marshal.py from xr.xml. Do not edit.", "#pragma once", ""]
w.append("static void chainIn(Writer& w, const void* next);")
w.append("static const void* dChainIn(Reader& r, Arena& a);")
w.append("static void chainOut(Writer& w, const void* next);")
w.append("static void dChainOut(Reader& r, void* next);")
w.append("static void sIAny(Writer& w, const void* base);")
w.append("static void* dIAny(Reader& r, Arena& a);")
w.append("")
for t in port:
    gen_struct(t, w)
w.append("")

typed = [t for t in port if is_typed(t) and type_value(t)]
w.append("static void chainIn(Writer& w, const void* next) {")
w.append("  for (auto* b = (const XrBaseInStructure*)next; b; b = b->next) {")
w.append("    switch ((int)b->type) {")
for t in typed:
    w.append(f"    case {type_value(t)}: w.put((int32_t)b->type); sI_{t}(w, *(const {t}*)b); break;")
w.append("    default: xrbChainDropped((int)b->type); break;")
w.append("    }")
w.append("  }")
w.append("  w.put((int32_t)0);")
w.append("}")
w.append("static void* dIAnyTyped(int type, Reader& r, Arena& a) {")
w.append("  switch (type) {")
for t in typed:
    w.append(f"  case {type_value(t)}: {{ auto* p = a.alloc<{t}>(1); p->type = (XrStructureType)type; dI_{t}(r, *p, a); return p; }}")
w.append("  default: return nullptr;")
w.append("  }")
w.append("}")
w.append("static const void* dChainIn(Reader& r, Arena& a) {")
w.append("  const void* head = nullptr; XrBaseInStructure* tail = nullptr;")
w.append("  for (;;) {")
w.append("    int type = r.get<int32_t>();")
w.append("    if (!type || r.bad) return head;")
w.append("    auto* p = (XrBaseInStructure*)dIAnyTyped(type, r, a);")
w.append("    if (!p) { r.bad = true; return head; }")
w.append("    if (tail) tail->next = p; else head = p;")
w.append("    tail = p;")
w.append("  }")
w.append("}")
w.append("static void sIAny(Writer& w, const void* base) {")
w.append("  if (!base) { w.put((int32_t)0); return; }")
w.append("  auto* b = (const XrBaseInStructure*)base;")
w.append("  switch ((int)b->type) {")
for t in typed:
    w.append(f"  case {type_value(t)}: w.put((int32_t)b->type); sI_{t}(w, *(const {t}*)b); break;")
w.append("  default: xrbChainDropped((int)b->type); w.put((int32_t)-1); break;")
w.append("  }")
w.append("}")
w.append("static void* dIAny(Reader& r, Arena& a) {")
w.append("  int type = r.get<int32_t>();")
w.append("  if (type == 0 || type == -1 || r.bad) return nullptr;")
w.append("  return dIAnyTyped(type, r, a);")
w.append("}")
mut = [t for t in typed if is_mutable(t)]
w.append("static void sOAny(Writer& w, const void* base) {")
w.append("  auto* b = (const XrBaseInStructure*)base;")
w.append("  switch ((int)b->type) {")
for t in mut:
    w.append(f"  case {type_value(t)}: sO_{t}(w, *(const {t}*)b); break;")
w.append("  default: break;")
w.append("  }")
w.append("}")
w.append("static bool dOAny(Reader& r, void* base) {")
w.append("  auto* b = (XrBaseOutStructure*)base;")
w.append("  switch ((int)b->type) {")
for t in mut:
    w.append(f"  case {type_value(t)}: dO_{t}(r, *({t}*)b); return true;")
w.append("  default: return false;")
w.append("  }")
w.append("}")
w.append("static bool isKnownOut(int type) {")
w.append("  switch (type) {")
for t in mut:
    w.append(f"  case {type_value(t)}:")
w.append("    return true;")
w.append("  default: return false;")
w.append("  }")
w.append("}")
w.append("static void chainOut(Writer& w, const void* next) {")
w.append("  for (auto* b = (const XrBaseInStructure*)next; b; b = b->next)")
w.append("    if (isKnownOut((int)b->type)) { w.put((int32_t)b->type); sOAny(w, b); }")
w.append("  w.put((int32_t)0);")
w.append("}")
w.append("static void dChainOut(Reader& r, void* next) {")
w.append("  auto* b = (XrBaseOutStructure*)next;")
w.append("  for (;;) {")
w.append("    int type = r.get<int32_t>();")
w.append("    if (!type || r.bad) return;")
w.append("    while (b && (int)b->type != type) b = b->next;")
w.append("    if (!b) { r.bad = true; return; }")
w.append("    dOAny(r, b);")
w.append("    b = b->next;")
w.append("  }")
w.append("}")
w.append("")

w.append("static const char* const kGenExtensions[] = {")
for e in exposed:
    w.append(f'  "{e}",')
w.append("};")
w.append("")
w.append("enum GenFn {")
for c in gen_cmds:
    w.append(f"  GEN_{c},")
w.append("  GEN_COUNT };")
w.append("static const char* const kGenFnNames[] = {")
for c in gen_cmds:
    w.append(f'  "{c}",')
w.append("};")
w.append("")


def proto(c):
    args = []
    for p in commands[c]:
        s = p.raw.strip()
        s = re.sub(r"\s+", " ", s)
        args.append(s)
    return ", ".join(args)


w.append("#ifdef XRB_GEN_SHIM")
w.append("template <class F> static XrResult genCall(uint32_t fn, F&& write, Rpc& c) { c.w.put(fn); write(); return c.call(); }")
for c in gen_cmds:
    ps = commands[c]
    names = [p.name for p in ps]
    body = [f"static XrResult XRAPI_CALL gx_{c}({proto(c)}) {{", "  Rpc c(OP_GENERIC);", f"  c.w.put((uint32_t)GEN_{c});"]
    after = []
    for p in ps:
        t = resolve(p.type)
        n = p.name
        if p.stars == 0:
            body.append(f"  c.w.raw(&{n}, sizeof({n}));")
        elif t == "char" and p.len == "null-terminated":
            body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) c.w.str({n});")
        elif t == "char":
            cnt = p.len.split(",")[0]
            after.append(f"    if (c.r.get<uint8_t>()) c.r.raw({n}, (size_t){cnt});")
            body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0));")
        elif is_polymorphic(t):
            ok_types = sorted({type_value(ch) for ch in children[t] if is_portable(ch) and type_value(ch)})
            if not all(is_portable(ch) for ch in children[t]):
                conds = " && ".join(f"((const XrBaseInStructure*){n})->type != {v}" for v in ok_types)
                body.append(f"  if ({n} && {conds}) return XR_ERROR_VALIDATION_FAILURE; // a struct type that cannot cross")
            body.append(f"  sIAny(c.w, {n});")
            if not p.const:
                after.append(f"    if ({n}) dOAny(c.r, {n});")
        elif p.len:
            cnt = p.len.split(",")[0]
            if p.const:
                if is_plain(t):
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) c.w.raw({n}, (size_t){cnt} * sizeof(*{n}));")
                else:
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) sI_{t}(c.w, {n}[i]);")
            else:
                if is_plain(t):
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0));")
                    after.append(f"    if (c.r.get<uint8_t>()) c.r.raw({n}, (size_t){cnt} * sizeof(*{n}));")
                else:
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) sI_{t}(c.w, {n}[i]);")
                    after.append(f"    if (c.r.get<uint8_t>()) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) dO_{t}(c.r, {n}[i]);")
        else:
            if p.const:
                if is_plain(t):
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) c.w.raw({n}, sizeof(*{n}));")
                else:
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) sI_{t}(c.w, *{n});")
            else:
                if is_plain(t):
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0));")
                    after.append(f"    if (c.r.get<uint8_t>()) c.r.raw({n}, sizeof(*{n}));")
                else:
                    body.append(f"  c.w.put((uint8_t)({n} ? 1 : 0)); if ({n}) sI_{t}(c.w, *{n});")
                    after.append(f"    if (c.r.get<uint8_t>()) dO_{t}(c.r, *{n});")
    body.append("  XrResult res = c.call();")
    body.append("  if (XR_SUCCEEDED(res) || res == XR_ERROR_SIZE_INSUFFICIENT) {")
    body += after
    body.append("    if (c.r.bad) return XR_ERROR_RUNTIME_FAILURE;")
    body.append("  }")
    body.append("  return res;")
    body.append("}")
    w += body
w.append("static const struct { const char* name; PFN_xrVoidFunction fn; } kGenThunks[] = {")
for c in gen_cmds:
    w.append(f'  {{"{c}", (PFN_xrVoidFunction)gx_{c}}},')
w.append("};")
w.append("#endif // XRB_GEN_SHIM")
w.append("")

w.append("#ifdef XRB_GEN_HOST")
w.append("static XrResult genDispatch(uint32_t fn, Reader& in, Writer& out, Arena& a, PFN_xrVoidFunction raw) {")
w.append("  (void)a; (void)out; (void)in;")
w.append("  switch (fn) {")
for c in gen_cmds:
    ps = commands[c]
    w.append(f"  case GEN_{c}: {{")
    args, after = [], []
    for p in ps:
        t = resolve(p.type)
        n = "p_" + p.name
        if p.stars == 0:
            w.append(f"    {p.type} {n}; in.raw(&{n}, sizeof({n}));")
            args.append(n)
        elif t == "char" and p.len == "null-terminated":
            w.append(f"    const char* {n} = in.get<uint8_t>() ? a.str(in.str()) : nullptr;")
            args.append(n)
        elif t == "char":
            cnt = "p_" + p.len.split(",")[0]
            w.append(f"    char* {n} = in.get<uint8_t>() ? a.alloc<char>({cnt}) : nullptr;")
            args.append(n)
            after.append(f"      out.put((uint8_t)({n} ? 1 : 0)); if ({n}) out.raw({n}, (size_t){cnt});")
        elif is_polymorphic(t):
            cq = "const " if p.const else ""
            w.append(f"    {cq}{p.type}* {n} = ({cq}{p.type}*)dIAny(in, a);")
            args.append(n)
            if not p.const:
                after.append(f"      if ({n}) sOAny(out, {n});")
        elif p.len:
            cnt = "p_" + p.len.split(",")[0]
            if p.const:
                if is_plain(t):
                    w.append(f"    const {p.type}* {n} = nullptr; if (in.get<uint8_t>()) {{ auto* q = a.alloc<{t}>({cnt}); in.raw((void*)q, (size_t){cnt} * sizeof({t})); {n} = (const {p.type}*)q; }}")
                else:
                    w.append(f"    const {t}* {n} = nullptr; if (in.get<uint8_t>()) {{ auto* q = a.alloc<{t}>({cnt}); for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) dI_{t}(in, q[i], a); {n} = q; }}")
            else:
                if is_plain(t):
                    w.append(f"    {p.type}* {n} = nullptr; if (in.get<uint8_t>()) {n} = ({p.type}*)a.alloc<{t}>({cnt});")
                    after.append(f"      out.put((uint8_t)({n} ? 1 : 0)); if ({n}) out.raw((const void*){n}, (size_t){cnt} * sizeof({t}));")
                else:
                    w.append(f"    {t}* {n} = nullptr; if (in.get<uint8_t>()) {{ {n} = a.alloc<{t}>({cnt}); for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) dI_{t}(in, {n}[i], a); }}")
                    after.append(f"      out.put((uint8_t)({n} ? 1 : 0)); if ({n}) for (uint32_t i = 0; i < (uint32_t){cnt}; ++i) sO_{t}(out, {n}[i]);")
            args.append(n)
        else:
            if p.const:
                if is_plain(t):
                    w.append(f"    const {p.type}* {n} = nullptr; if (in.get<uint8_t>()) {{ auto* q = a.alloc<{t}>(1); in.raw((void*)q, sizeof({t})); {n} = (const {p.type}*)q; }}")
                else:
                    w.append(f"    const {t}* {n} = nullptr; if (in.get<uint8_t>()) {{ auto* q = a.alloc<{t}>(1); dI_{t}(in, *q, a); {n} = q; }}")
            else:
                if is_plain(t):
                    w.append(f"    {p.type}* {n} = nullptr; if (in.get<uint8_t>()) {n} = ({p.type}*)a.alloc<{t}>(1);")
                    after.append(f"      out.put((uint8_t)({n} ? 1 : 0)); if ({n}) out.raw((const void*){n}, sizeof({t}));")
                else:
                    w.append(f"    {t}* {n} = nullptr; if (in.get<uint8_t>()) {{ {n} = a.alloc<{t}>(1); dI_{t}(in, *{n}, a); }}")
                    after.append(f"      out.put((uint8_t)({n} ? 1 : 0)); if ({n}) sO_{t}(out, *{n});")
            args.append(n)
    w.append("    if (in.bad) return XR_ERROR_RUNTIME_FAILURE;")
    w.append(f"    XrResult res = reinterpret_cast<PFN_{c}>(raw)({', '.join(args)});")
    w.append("    if (XR_SUCCEEDED(res) || res == XR_ERROR_SIZE_INSUFFICIENT) {")
    w += after
    w.append("    }")
    w.append("    return res;")
    w.append("  }")
w.append("  default: return XR_ERROR_FUNCTION_UNSUPPORTED;")
w.append("  }")
w.append("}")
w.append("#endif // XRB_GEN_HOST")

with open(out_path, "w") as f:
    f.write("\n".join(w) + "\n")
print(f"structs portable: {len(port)} of {len(structs)}; typed: {len(typed)}")
print(f"extensions exposed: {len(exposed)}; generated functions: {len(gen_cmds)}")
for key in ("XR_KHR_composition_layer_depth", "XR_VARJO_quad_views", "XR_VARJO_foveated_rendering", "XR_FB_foveation", "XR_META_foveation_eye_tracked",
            "XR_FB_eye_tracking_social", "XR_EXT_hand_tracking", "XR_FB_display_refresh_rate", "XR_EXT_eye_gaze_interaction", "XR_KHR_binding_modification",
            "XR_EXT_dpad_binding", "XR_FB_passthrough", "XR_EXT_performance_settings", "XR_HTC_facial_tracking", "XR_KHR_composition_layer_cylinder",
            "XR_KHR_composition_layer_color_scale_bias", "XR_EXT_view_configuration_depth_range", "XR_FB_composition_layer_settings", "XR_VALVE_analog_threshold"):
    print(f"  {key}: {'yes' if key in exposed else 'NO'}")
