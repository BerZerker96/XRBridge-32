// XRBridge32-Setup.exe: install, enable, disable and uninstall, as GUI or command line.
//
// What it changes, and how each change is undone:
//  - Files in %ProgramFiles%\XRBridge32                    -> deleted on uninstall
//  - HKLM\SOFTWARE\WOW6432Node\Khronos\OpenXR\1\ActiveRuntime -> previous value saved, restored on disable
//  - "runtime" list in %LOCALAPPDATA%\openvr\openvrpaths.vrpath -> our entry added first, only our entry removed on disable
// It never touches the 64-bit ActiveRuntime: that remains the user's real runtime.
#ifndef UNICODE
#define UNICODE
#endif
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <dwmapi.h>
#include <shellapi.h>
#include <shlobj.h>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#define IDR_SHIM 101
#define IDR_HOST 102
#define IDR_TEST 103
#define IDR_D3D9_32 104
#define IDR_D3D9_64 105
#define IDI_APP 1

using std::string;
using std::wstring;

static const wchar_t* KHR_KEY = L"SOFTWARE\\Khronos\\OpenXR\\1";
static const wchar_t* OWN_KEY = L"SOFTWARE\\XRBridge32";
static const wchar_t* UNINSTALL_KEY = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\XRBridge32";

enum { LVL_GOOD, LVL_WARN, LVL_BAD, LVL_OFF };
struct StatusRow { wstring label, value; int level; };

// Written by the worker thread, read by the UI thread.
static std::mutex g_stateMutex;
static wstring g_output;
static std::vector<StatusRow> g_rows;
static HWND g_hwndOut, g_hwndMain;
static bool g_cli;

static string toUtf8(const wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), s.data(), n, nullptr, nullptr);
    return s;
}
static wstring toWide(const string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), n);
    return w;
}
static void say(const wstring& line) {
    {
        std::lock_guard<std::mutex> l(g_stateMutex);
        g_output += line + L"\r\n";
    }
    if (g_cli) {
        string u = toUtf8(line + L"\n");
        DWORD w;
        WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), u.data(), (DWORD)u.size(), &w, nullptr);
    } else if (g_hwndMain) {
        PostMessageW(g_hwndMain, WM_APP + 1, 0, 0);
    }
}

// ------------------------------------------------------------------ paths
static wstring envVar(const wchar_t* n) {
    wchar_t b[MAX_PATH * 2];
    DWORD c = GetEnvironmentVariableW(n, b, MAX_PATH * 2);
    return c ? wstring(b, c) : L"";
}
static wstring installDir() {
    wstring pf = envVar(L"ProgramW6432");
    if (pf.empty()) pf = envVar(L"ProgramFiles");
    return pf + L"\\XRBridge32";
}
static wstring manifestPath() { return installDir() + L"\\bin32\\xrbridge32.json"; }
static wstring ocDir() { return installDir() + L"\\OpenComposite"; }
// Elevating through a different admin account changes %LOCALAPPDATA%, but SteamVR's file
// belongs to whoever is at the desktop, so that user's folder comes from the shell's token.
static wstring desktopUserLocalAppData() {
    static wstring cached;
    if (!cached.empty()) return cached;
    DWORD pid = 0;
    GetWindowThreadProcessId(GetShellWindow(), &pid);
    if (pid) {
        HANDLE proc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid), token = nullptr;
        if (proc && OpenProcessToken(proc, TOKEN_QUERY | TOKEN_IMPERSONATE | TOKEN_DUPLICATE, &token)) {
            PWSTR path = nullptr;
            if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, token, &path)) && path) cached = path;
            CoTaskMemFree(path);
            CloseHandle(token);
        }
        if (proc) CloseHandle(proc);
    }
    if (cached.empty()) cached = envVar(L"LOCALAPPDATA");
    return cached;
}
static wstring vrpathFile() { return desktopUserLocalAppData() + L"\\openvr\\openvrpaths.vrpath"; }
static bool fileExists(const wstring& p) {
    DWORD a = GetFileAttributesW(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
static void makeDirs(const wstring& p) {
    for (size_t i = 3; i < p.size(); ++i)
        if (p[i] == L'\\') CreateDirectoryW(p.substr(0, i).c_str(), nullptr);
    CreateDirectoryW(p.c_str(), nullptr);
}
static string readFile(const wstring& p) {
    std::ifstream f(p.c_str(), std::ios::binary);
    std::stringstream s;
    s << f.rdbuf();
    return s.str();
}
static bool writeFile(const wstring& p, const string& data) {
    std::ofstream f(p.c_str(), std::ios::binary | std::ios::trunc);
    f.write(data.data(), (std::streamsize)data.size());
    return f.good();
}

// ------------------------------------------------------------------ registry
static bool regGet(HKEY root, const wchar_t* key, const wchar_t* val, REGSAM view, wstring& out) {
    wchar_t b[1024];
    DWORD size = sizeof(b);
    if (RegGetValueW(root, key, val, RRF_RT_REG_SZ | (view == KEY_WOW64_32KEY ? RRF_SUBKEY_WOW6432KEY : RRF_SUBKEY_WOW6464KEY),
                     nullptr, b, &size) != ERROR_SUCCESS)
        return false;
    out = b;
    return true;
}
static LONG regSet(HKEY root, const wchar_t* key, const wchar_t* val, REGSAM view, const wstring& data) {
    HKEY h;
    LONG r = RegCreateKeyExW(root, key, 0, nullptr, 0, KEY_SET_VALUE | view, nullptr, &h, nullptr);
    if (r != ERROR_SUCCESS) return r;
    r = RegSetValueExW(h, val, 0, REG_SZ, (const BYTE*)data.c_str(), (DWORD)((data.size() + 1) * sizeof(wchar_t)));
    RegCloseKey(h);
    return r;
}
static void regDelVal(HKEY root, const wchar_t* key, const wchar_t* val, REGSAM view) {
    HKEY h;
    if (RegOpenKeyExW(root, key, 0, KEY_SET_VALUE | view, &h) == ERROR_SUCCESS) {
        RegDeleteValueW(h, val);
        RegCloseKey(h);
    }
}
static wstring lower(wstring s) { for (auto& c : s) c = towlower(c); return s; }

// True when the manifest exists and the DLL it names exists too.
static bool runtimeManifestValid(const wstring& json) {
    if (!fileExists(json)) return false;
    string t = readFile(json);
    size_t k = t.find("\"library_path\"");
    if (k == string::npos) return false;
    size_t a = t.find('"', t.find(':', k));
    if (a == string::npos) return false;
    string lib;
    for (size_t i = a + 1; i < t.size() && t[i] != '"'; ++i) {
        if (t[i] == '\\' && i + 1 < t.size()) ++i;
        lib += t[i];
    }
    wstring w = toWide(lib);
    for (auto& c : w) if (c == L'/') c = L'\\';
    bool absolute = w.size() > 2 && (w[1] == L':' || w[0] == L'\\');
    if (!absolute) w = json.substr(0, json.find_last_of(L'\\') + 1) + w;
    return fileExists(w);
}
static bool isOurs(const wstring& v) { return lower(v).find(L"xrbridge32.json") != wstring::npos; }

// ------------------------------------------------------------------ vrpath file
// A deliberately small editor: it replaces only the "runtime" array and leaves
// every other byte of Steam's file alone.
static string jsonEscape(const string& s) {
    string o;
    for (char c : s) { if (c == '\\' || c == '"') o += '\\'; o += c; }
    return o;
}
// Finds the value of the top-level "runtime" key: [open, close] spans the array, or the
// literal null Steam can leave there. Returns false when the key is absent.
static bool findRuntimeValue(const string& t, size_t& open, size_t& close, bool* isArray = nullptr) {
    size_t k = t.find("\"runtime\"");
    if (k == string::npos) return false;
    size_t c = t.find(':', k + 9);
    if (c == string::npos) return false;
    size_t v = t.find_first_not_of(" \t\r\n", c + 1);
    if (v == string::npos) return false;
    if (t[v] != '[') {
        size_t e = t.find_first_of(",}\r\n", v);
        if (e == string::npos) return false;
        open = v; close = e - 1;
        if (isArray) *isArray = false;
        return true;
    }
    open = v;
    if (isArray) *isArray = true;
    bool inStr = false;
    for (size_t i = open + 1; i < t.size(); ++i) {
        if (inStr) {
            if (t[i] == '\\') ++i;
            else if (t[i] == '"') inStr = false;
        } else if (t[i] == '"') inStr = true;
        else if (t[i] == ']') { close = i; return true; }
    }
    return false;
}
static std::vector<string> parseRuntimes(const string& t) {
    std::vector<string> out;
    size_t a, b;
    bool isArray = false;
    if (!findRuntimeValue(t, a, b, &isArray) || !isArray) return out;
    for (size_t i = a + 1; i < b; ++i) {
        if (t[i] != '"') continue;
        string v;
        for (++i; i < b && t[i] != '"'; ++i) {
            if (t[i] == '\\' && i + 1 < b) ++i;
            v += t[i];
        }
        out.push_back(v);
    }
    return out;
}
static bool writeRuntimes(const wstring& path, string text, const std::vector<string>& rts) {
    string arr = "[\n";
    for (size_t i = 0; i < rts.size(); ++i)
        arr += "\t\t\"" + jsonEscape(rts[i]) + "\"" + (i + 1 < rts.size() ? ",\n" : "\n");
    arr += "\t]";
    size_t a, b, brace;
    if (findRuntimeValue(text, a, b)) {
        text = text.substr(0, a) + arr + text.substr(b + 1);
    } else if ((brace = text.rfind('}')) != string::npos && text.find('{') < brace) {
        // A valid file without the key keeps everything it has.
        bool empty = text.find_first_not_of(" \t\r\n", text.find('{') + 1) == brace;
        text = text.substr(0, brace) + (empty ? "" : ",\n") + "\t\"runtime\" : " + arr + "\n" + text.substr(brace);
    } else {
        text = "{\n\t\"config\" : [],\n\t\"external_drivers\" : null,\n\t\"jsonid\" : \"vrpathreg\",\n\t\"log\" : [],\n\t\"runtime\" : " + arr + ",\n\t\"version\" : 1\n}\n";
    }
    makeDirs(path.substr(0, path.find_last_of(L'\\')));
    return writeFile(path, text);
}
static bool sameFolder(const string& a, const wstring& b) {
    wstring x = lower(toWide(a)), y = lower(b);
    for (auto& c : x) if (c == L'/') c = L'\\';
    while (!x.empty() && x.back() == L'\\') x.pop_back();
    return x == y;
}

// ------------------------------------------------------------------ OpenComposite
// Machine check so a captive-portal page or a wrong-arch file is never installed.
static WORD peMachine(const wstring& p) {
    string d = readFile(p);
    if (d.size() < 0x200 || d[0] != 'M' || d[1] != 'Z') return 0;
    uint32_t off = *(const uint32_t*)(d.data() + 0x3C);
    if (off + 6 > d.size() || memcmp(d.data() + off, "PE\0\0", 4)) return 0;
    return *(const WORD*)(d.data() + off + 4);
}
// Everything Setup installs ships in the package beside it. Nothing is downloaded.
static wstring packageDir() {
    wchar_t self[MAX_PATH];
    GetModuleFileNameW(nullptr, self, MAX_PATH);
    wstring d = self;
    return d.substr(0, d.find_last_of(L'\\'));
}
static bool getOpenCompositeDll(const wstring& name, WORD machine, const wstring& localDir) {
    wstring dest = ocDir() + L"\\bin\\" + name;
    wstring local = localDir + L"\\" + name;
    if (!localDir.empty() && fileExists(local) && peMachine(local) == machine) {
        if (lower(local) == lower(dest)) { say(L"  " + name + L": already present"); return true; }
        if (!CopyFileW(local.c_str(), dest.c_str(), FALSE)) { say(L"  could not copy " + local + L". If a game is running, close it and try again."); return false; }
        say(L"  " + name + L": copied from " + localDir);
        return true;
    }
    if (fileExists(dest) && peMachine(dest) == machine) { say(L"  " + name + L": already present"); return true; }
    say(L"  " + name + L" not found in " + localDir);
    return false;
}
static bool openCompositePresent() {
    return peMachine(ocDir() + L"\\bin\\vrclient.dll") == IMAGE_FILE_MACHINE_I386 &&
           peMachine(ocDir() + L"\\bin\\vrclient_x64.dll") == IMAGE_FILE_MACHINE_AMD64;
}

// OpenComposite is built with a recent MSVC. An older 32-bit msvcp140.dll makes it
// crash inside std::mutex, so an outdated runtime is called out instead of looking
// like a bridge failure.
static bool vcRuntime32Ok(wstring& found) {
    wstring dll = envVar(L"SystemRoot") + L"\\SysWOW64\\msvcp140.dll";
    DWORD dummy = 0, size = GetFileVersionInfoSizeW(dll.c_str(), &dummy);
    if (!size) { found = L"not installed"; return false; }
    std::vector<BYTE> data(size);
    VS_FIXEDFILEINFO* info = nullptr;
    UINT len = 0;
    if (!GetFileVersionInfoW(dll.c_str(), 0, size, data.data()) || !VerQueryValueW(data.data(), L"\\", (void**)&info, &len) || !info) {
        found = L"unknown version";
        return false;
    }
    DWORD major = HIWORD(info->dwFileVersionMS), minor = LOWORD(info->dwFileVersionMS);
    found = std::to_wstring(major) + L"." + std::to_wstring(minor);
    return major > 14 || (major == 14 && minor >= 40);
}
static void warnVcRuntime() {
    wstring v;
    if (!vcRuntime32Ok(v))
        say(L"  ! 32-bit Visual C++ runtime is " + v + L". OpenComposite needs 14.40 or newer, or games crash at startup. Run VC_redist.x86.exe from the XRBridge32 package.");
}
// The package carries Microsoft's signed 32-bit runtime installer, run only when the
// installed runtime is too old for OpenComposite.
static void installBundledVcRuntime() {
    wstring v;
    if (vcRuntime32Ok(v)) return;
    wstring exe = packageDir() + L"\\VC_redist.x86.exe";
    if (!fileExists(exe)) { warnVcRuntime(); return; }
    say(L"Installing the 32-bit Visual C++ runtime (found " + v + L", OpenComposite needs 14.40 or newer)...");
    wstring cmd = L"\"" + exe + L"\" /install /quiet /norestart";
    STARTUPINFOW si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) { say(L"  could not start VC_redist.x86.exe"); return; }
    WaitForSingleObject(pi.hProcess, 10 * 60 * 1000);
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    // 3010: installed, a restart finishes it. 1638: a newer version is already there.
    if (code == 0 || code == 1638) say(L"  done");
    else if (code == 3010) say(L"  done. Restart Windows before playing.");
    else { say(L"  the runtime installer returned " + std::to_wstring(code)); warnVcRuntime(); }
}

// ------------------------------------------------------------------ settings
static bool zeroCopyOn() {
    DWORD v = 0, size = sizeof(v);
    RegGetValueW(HKEY_LOCAL_MACHINE, OWN_KEY, L"ZeroCopy", RRF_RT_REG_DWORD | RRF_SUBKEY_WOW6464KEY, nullptr, &v, &size);
    return v != 0;
}
static void setZeroCopy(bool on) {
    HKEY h;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, OWN_KEY, 0, nullptr, 0, KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &h, nullptr) != ERROR_SUCCESS) return;
    DWORD v = on ? 1 : 0;
    RegSetValueExW(h, L"ZeroCopy", 0, REG_DWORD, (const BYTE*)&v, sizeof(v));
    RegCloseKey(h);
}

// ------------------------------------------------------------------ actions
static bool extractResource(int id, const wstring& dest) {
    HRSRC r = FindResourceW(nullptr, MAKEINTRESOURCEW(id), (LPCWSTR)RT_RCDATA);
    if (!r) return false;
    HGLOBAL g = LoadResource(nullptr, r);
    DWORD n = SizeofResource(nullptr, r);
    if (!g || !n) return false;
    return writeFile(dest, string((const char*)LockResource(g), n));
}
// Adds or removes the D3D9 virtual screen for one game. Files sit beside the game, so
// uninstalling XRBridge32 leaves them: removal has to name the game too.
static const char kProxyMarker[] = "XRB_D3D9_PROXY_MARKER_V1";
static bool isOurProxy(const wstring& path) {
    return fileExists(path) && readFile(path).find(kProxyMarker) != string::npos;
}
static bool doD3D9Add(const wstring& exe) {
    WORD machine = peMachine(exe);
    if (machine != IMAGE_FILE_MACHINE_I386 && machine != IMAGE_FILE_MACHINE_AMD64) { say(L"ERROR: that does not look like a game executable: " + exe); return false; }
    wstring dir = exe.substr(0, exe.find_last_of(L'\\'));
    wstring proxy = dir + L"\\d3d9.dll", chain = dir + L"\\d3d9_chain.dll";
    if (isOurProxy(proxy)) { say(L"Already added to " + dir); return true; }
    // A wrapper already there (DXVK, a mod) keeps working: the proxy loads it instead of the system one.
    if (fileExists(proxy)) {
        if (fileExists(chain)) { say(L"ERROR: both d3d9.dll and d3d9_chain.dll exist in that folder; nothing changed."); return false; }
        if (!MoveFileW(proxy.c_str(), chain.c_str())) { say(L"ERROR: could not rename the existing d3d9.dll. Is the game running?"); return false; }
        say(L"Kept the existing d3d9.dll as d3d9_chain.dll.");
    }
    if (!extractResource(machine == IMAGE_FILE_MACHINE_I386 ? IDR_D3D9_32 : IDR_D3D9_64, proxy)) { say(L"ERROR: could not write " + proxy); return false; }
    say(L"D3D9 virtual screen added to " + dir + (machine == IMAGE_FILE_MACHINE_I386 ? L" (32-bit game)." : L" (64-bit game)."));
    say(L"Start the game normally. F8 recenters the screen. Settings: xrb_d3d9.ini beside the game, keys under [screen]: width, distance, curved.");
    say(L"Avoid this on online games with anti-cheat, which can treat a replaced d3d9.dll as cheating.");
    say(L"32-bit D3D9 mods with their own stereo (Dishonored VR, Mirror's Edge VR) do not need this: they use the bridge directly.");
    return true;
}
static bool doD3D9Remove(const wstring& exe) {
    wstring dir = exe.substr(0, exe.find_last_of(L'\\'));
    wstring proxy = dir + L"\\d3d9.dll", chain = dir + L"\\d3d9_chain.dll";
    if (!isOurProxy(proxy)) { say(L"The virtual screen is not installed in " + dir + L"; nothing changed."); return true; }
    if (!DeleteFileW(proxy.c_str())) { say(L"ERROR: could not remove " + proxy + L". Is the game running?"); return false; }
    if (fileExists(chain)) MoveFileW(chain.c_str(), proxy.c_str());
    say(L"D3D9 virtual screen removed from " + dir);
    return true;
}
static bool doEnableBridge(bool force);
static bool doEnableOpenVR();
static bool doDisable();

static bool doInstall(const wstring& ocLocal) {
    wstring d = installDir();
    say(L"Installing to " + d);
    makeDirs(d + L"\\bin32");
    makeDirs(d + L"\\bin64");
    makeDirs(ocDir() + L"\\bin");
    if (!extractResource(IDR_SHIM, d + L"\\bin32\\xrbridge32.dll") ||
        !extractResource(IDR_HOST, d + L"\\bin64\\xrbridge_host.exe") ||
        !extractResource(IDR_TEST, d + L"\\xrbridge_selftest32.exe")) {
        say(L"ERROR: could not write the program files. If a game is running, close it and try again.");
        return false;
    }
    writeFile(manifestPath(),
              "{\n  \"file_format_version\": \"1.0.0\",\n  \"runtime\": {\n    \"library_path\": \"./xrbridge32.dll\",\n    \"name\": \"XRBridge32\"\n  }\n}\n");

    wchar_t self[MAX_PATH];
    GetModuleFileNameW(nullptr, self, MAX_PATH);
    wstring selfDest = d + L"\\XRBridge32-Setup.exe";
    if (lower(self) != lower(selfDest)) CopyFileW(self, selfDest.c_str(), FALSE);

    regSet(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, L"DisplayName", KEY_WOW64_64KEY, L"XRBridge32");
    regSet(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, L"Publisher", KEY_WOW64_64KEY, L"XRBridge32");
    regSet(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, L"DisplayVersion", KEY_WOW64_64KEY, L"3.3.0");
    regSet(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, L"DisplayIcon", KEY_WOW64_64KEY, selfDest + L",0");
    regSet(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, L"InstallLocation", KEY_WOW64_64KEY, d);
    regSet(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, L"UninstallString", KEY_WOW64_64KEY, L"\"" + selfDest + L"\" --uninstall");

    say(L"Installing OpenComposite (SteamVR API translator, GPLv3, by ZNix and contributors):");
    const wstring from = ocLocal.empty() ? packageDir() + L"\\OpenComposite" : ocLocal;
    bool a = getOpenCompositeDll(L"vrclient.dll", IMAGE_FILE_MACHINE_I386, from);
    bool b = getOpenCompositeDll(L"vrclient_x64.dll", IMAGE_FILE_MACHINE_AMD64, from);
    if (!a || !b) {
        say(L"WARNING: OpenComposite is missing. The 32-bit OpenXR bridge is installed, but SteamVR games cannot be redirected yet.");
        say(L"  Fix: run Setup from the unzipped XRBridge32 folder, which has an OpenComposite folder beside it.");
    }
    installBundledVcRuntime();
    // OpenComposite normally starts with a temporary Vulkan session, which would make every
    // D3D game depend on the Vulkan interop path. An existing file is the user's and is kept.
    wstring ini = ocDir() + L"\\bin\\opencomposite.ini";
    if (!fileExists(ini)) writeFile(ini, "; Written by XRBridge32. Use D3D11 for OpenComposite's startup session.\r\ninitUsingVulkan=false\r\n");
    say(L"Installed. Nothing is active until you click Enable.");
    return true;
}

static bool doEnableBridge(bool force) {
    if (!fileExists(manifestPath())) { say(L"ERROR: not installed yet."); return false; }
    wstring cur;
    bool has = regGet(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_32KEY, cur);
    if (has && isOurs(cur)) { say(L"32-bit bridge: already enabled."); return true; }
    if (has && runtimeManifestValid(cur) && !force) {
        say(L"32-bit bridge: NOT enabled, because a working native 32-bit runtime is already set:");
        say(L"  " + cur);
        say(L"  A native runtime has less overhead than the bridge, so it was kept. Tick 'Replace an existing native 32-bit runtime' (or pass --force) to override.");
        return true;
    }
    if (has) {
        LONG r = regSet(HKEY_LOCAL_MACHINE, OWN_KEY, L"PrevActiveRuntime32", KEY_WOW64_64KEY, cur);
        if (r != ERROR_SUCCESS) { say(L"ERROR: could not save the previous runtime; nothing changed."); return false; }
    }
    else regDelVal(HKEY_LOCAL_MACHINE, OWN_KEY, L"PrevActiveRuntime32", KEY_WOW64_64KEY); // nothing to restore later
    LONG r = regSet(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_32KEY, manifestPath());
    if (r != ERROR_SUCCESS) { say(L"ERROR: could not write the 32-bit ActiveRuntime. Run as administrator."); return false; }
    say(L"32-bit bridge: enabled.");
    return true;
}

static bool doEnableOpenVR() {
    if (!openCompositePresent()) { say(L"ERROR: OpenComposite DLLs are missing; SteamVR redirect not enabled."); return false; }
    wstring vp = vrpathFile();
    string text = readFile(vp);
    if (!text.empty() && !fileExists(installDir() + L"\\openvrpaths.backup"))
        writeFile(installDir() + L"\\openvrpaths.backup", text);
    std::vector<string> rts = parseRuntimes(text), out;
    out.push_back(toUtf8(ocDir()));
    string steamvr;
    for (auto& r : rts) {
        if (sameFolder(r, ocDir())) continue;
        if (lower(toWide(r)).find(L"steamvr") != wstring::npos && steamvr.empty()) steamvr = r;
        out.push_back(r);
    }
    if (!writeRuntimes(vp, text, out)) { say(L"ERROR: could not write " + vp); return false; }
    // OpenComposite's own launcher does this too: with a matching version.txt the
    // Steam client does not change the runtime back on its own.
    if (!steamvr.empty()) {
        wstring v = toWide(steamvr) + L"\\bin\\version.txt";
        if (fileExists(v)) CopyFileW(v.c_str(), (ocDir() + L"\\bin\\version.txt").c_str(), FALSE);
    }
    say(L"SteamVR redirect: enabled. OpenVR games now load OpenComposite instead of SteamVR.");
    warnVcRuntime();
    return true;
}

static bool doDisable() {
    wstring cur, prev;
    if (regGet(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_32KEY, cur) && isOurs(cur)) {
        if (regGet(HKEY_LOCAL_MACHINE, OWN_KEY, L"PrevActiveRuntime32", KEY_WOW64_64KEY, prev)) {
            regSet(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_32KEY, prev);
            say(L"32-bit runtime restored to " + prev);
        } else {
            regDelVal(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_32KEY);
            say(L"32-bit bridge: disabled (no previous 32-bit runtime to restore).");
        }
        regDelVal(HKEY_LOCAL_MACHINE, OWN_KEY, L"PrevActiveRuntime32", KEY_WOW64_64KEY);
    } else {
        say(L"32-bit bridge: was not active; left as it is.");
    }
    wstring vp = vrpathFile();
    if (fileExists(vp)) {
        string text = readFile(vp);
        std::vector<string> rts = parseRuntimes(text), out;
        bool removed = false;
        for (auto& r : rts) { if (sameFolder(r, ocDir())) removed = true; else out.push_back(r); }
        if (removed) {
            if (writeRuntimes(vp, text, out)) say(L"SteamVR redirect: disabled.");
            else { say(L"ERROR: could not write " + vp); return false; }
        } else say(L"SteamVR redirect: was not active; left as it is.");
    }
    return true;
}

static bool doUninstall() {
    if (!doDisable()) return false;
    wstring d = installDir();
    RegDeleteKeyExW(HKEY_LOCAL_MACHINE, UNINSTALL_KEY, KEY_WOW64_64KEY, 0);
    RegDeleteKeyExW(HKEY_LOCAL_MACHINE, OWN_KEY, KEY_WOW64_64KEY, 0);
    wchar_t self[MAX_PATH];
    GetModuleFileNameW(nullptr, self, MAX_PATH);
    bool fromInside = lower(self).rfind(lower(d) + L"\\", 0) == 0;
    wstring cmd = L"cmd.exe /c ";
    if (fromInside) cmd += L"ping -n 3 127.0.0.1 >nul & ";
    cmd += L"rmdir /s /q \"" + d + L"\"";
    STARTUPINFOW si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, L"C:\\", &si, &pi)) {
        if (!fromInside) WaitForSingleObject(pi.hProcess, 15000);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    }
    say(L"Uninstalled.");
    return true;
}

// Runs a program and returns its stdout. Used for the bridge check.
static string captureOutput(const wstring& cmdline, DWORD timeoutMs) {
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    HANDLE rd, wr;
    if (!CreatePipe(&rd, &wr, &sa, 1 << 20)) return {}; // big enough that the child never blocks on it
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOW si{}; si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES; si.hStdOutput = wr; si.hStdError = wr;
    PROCESS_INFORMATION pi{};
    wstring cmd = cmdline;
    if (!CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        CloseHandle(rd); CloseHandle(wr);
        return {};
    }
    CloseHandle(wr);
    string out; char buf[1024]; DWORD n;
    while (WaitForSingleObject(pi.hProcess, timeoutMs) == WAIT_TIMEOUT) { TerminateProcess(pi.hProcess, 3); break; }
    while (ReadFile(rd, buf, sizeof(buf), &n, nullptr) && n) out.append(buf, n);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread); CloseHandle(rd);
    return out;
}
// The newest line in a bridge log that says what went wrong.
static wstring lastProblem(const wchar_t* file) {
    std::stringstream ss(readFile(desktopUserLocalAppData() + L"\\XRBridge32\\" + file));
    string line, found;
    while (std::getline(ss, line))
        if (line.find("] op ") != string::npos) continue; // the generic echo of a reason logged just before
        else if (line.find("could not") != string::npos || line.find("failed") != string::npos || line.find("timed out") != string::npos || line.find("exited early") != string::npos) found = line;
    size_t tag = found.find("] ");
    if (tag != string::npos) found = found.substr(tag + 2);
    while (!found.empty() && (found.back() == '\r' || found.back() == '\n')) found.pop_back();
    return toWide(found);
}
// Asks the active 32-bit runtime what a game would see. This is the only way to tell apart the
// causes of a game's "missing XR extension" error, because the loader hides the failure.
static void addRuntimeCheck(std::vector<StatusRow>& rows, bool bridgeActive, bool has32) {
    wstring exe = installDir() + L"\\xrbridge_selftest32.exe";
    if (!has32 || !fileExists(exe)) return;
    string out = captureOutput(L"\"" + exe + L"\" --check", 15000);
    const bool d3d11 = out.find("ext XR_KHR_D3D11_enable") != string::npos, d3d12 = out.find("ext XR_KHR_D3D12_enable") != string::npos,
               vk = out.find("ext XR_KHR_vulkan_enable") != string::npos, gl = out.find("ext XR_KHR_opengl_enable") != string::npos;
    wstring offered;
    auto add = [&](bool on, const wchar_t* n) { if (on) { if (!offered.empty()) offered += L", "; offered += n; } };
    add(d3d11, L"D3D11"); add(d3d12, L"D3D12"); add(vk, L"Vulkan"); add(gl, L"OpenGL");
    if (offered.empty()) {
        // A host that cannot start writes nothing, so its log may hold an older, unrelated error.
        wstring why = bridgeActive ? lastProblem(L"shim.log") : L"";
        if (bridgeActive && why.find(L"could not start") == wstring::npos) {
            wstring hostWhy = lastProblem(L"host.log");
            if (!hostWhy.empty()) why = hostWhy;
        }
        if (why.empty()) why = bridgeActive ? L"see shim.log and host.log" : L"the active 32-bit runtime did not answer";
        rows.push_back({L"Offered to 32-bit games", L"Nothing: " + why, LVL_BAD});
        say(L"Games will report a missing XR extension until this is fixed.");
        if (bridgeActive) say(L"Check that your 64-bit runtime is set, and that antivirus has not removed xrbridge_host.exe.");
        return;
    }
    rows.push_back({L"Offered to 32-bit games", offered, d3d11 && d3d12 && vk && gl ? LVL_GOOD : LVL_WARN});
    if (!bridgeActive && !(d3d11 && vk && d3d12 && gl)) {
        say(L"The active native 32-bit runtime does not offer every graphics API. Mods that need the others will report a missing XR extension.");
        say(L"To use the bridge instead, tick 'Replace an existing native 32-bit runtime' and click Enable.");
    } else if (bridgeActive && !vk) {
        wstring why = lastProblem(L"shim.log");
        say(L"Vulkan is not offered. " + (why.empty() ? wstring(L"Your GPU driver may be missing the 32-bit Vulkan loader.") : why));
    }
}

static void doStatus() {
    std::vector<StatusRow> rows;
    wstring v64, v32;
    bool installed = fileExists(manifestPath());
    rows.push_back({L"Installed", installed ? L"Yes" : L"No", installed ? LVL_GOOD : LVL_OFF});

    bool has64 = regGet(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_64KEY, v64);
    if (!has64 || !runtimeManifestValid(v64))
        rows.push_back({L"64-bit OpenXR runtime", L"None working. Set PimaxXR or your headset's runtime first", LVL_BAD});
    else if (lower(v64).find(L"steamxr") != wstring::npos || lower(v64).find(L"steamvr") != wstring::npos)
        rows.push_back({L"64-bit OpenXR runtime", L"SteamVR, so games still run through it. Set PimaxXR to bypass", LVL_WARN});
    else
        rows.push_back({L"64-bit OpenXR runtime", v64, LVL_GOOD});

    bool has32 = regGet(HKEY_LOCAL_MACHINE, KHR_KEY, L"ActiveRuntime", KEY_WOW64_32KEY, v32);
    if (!has32) rows.push_back({L"32-bit OpenXR runtime", L"None", LVL_OFF});
    else if (isOurs(v32)) rows.push_back({L"32-bit OpenXR runtime", L"XRBridge32 (enabled)", LVL_GOOD});
    else if (runtimeManifestValid(v32)) rows.push_back({L"32-bit OpenXR runtime", L"Native: " + v32, LVL_GOOD});
    else rows.push_back({L"32-bit OpenXR runtime", L"Broken, file missing: " + v32, LVL_WARN});
    addRuntimeCheck(rows, has32 && isOurs(v32), has32);

    auto rts = parseRuntimes(readFile(vrpathFile()));
    bool ocFiles = openCompositePresent();
    if (!rts.empty() && sameFolder(rts[0], ocDir())) rows.push_back({L"SteamVR games", L"Redirected to OpenComposite", ocFiles ? LVL_GOOD : LVL_BAD});
    else if (!rts.empty()) rows.push_back({L"SteamVR games", L"Using " + toWide(rts[0]), LVL_OFF});
    else rows.push_back({L"SteamVR games", L"No OpenVR runtime registered", LVL_OFF});
    if (installed && !ocFiles) rows.push_back({L"OpenComposite", L"Missing. Run Install again when online", LVL_WARN});

    wstring vc;
    bool vcOk = vcRuntime32Ok(vc);
    rows.push_back({L"32-bit Visual C++ runtime", vcOk ? vc : vc + L", needs 14.40 or newer", vcOk ? LVL_GOOD : LVL_WARN});
    {
        std::lock_guard<std::mutex> l(g_stateMutex);
        g_rows = rows;
    }
    if (g_cli) for (auto& r : rows) say(r.label + L": " + r.value);
    if (!vcOk) warnVcRuntime();
}

// Runs one 32-bit test app per graphics API. Its output goes to the log area.
struct TestWatchdog {
    HANDLE proc, stop;
    static DWORD WINAPI run(LPVOID p) {
        auto* k = (TestWatchdog*)p;
        if (WaitForSingleObject(k->stop, 45000) == WAIT_TIMEOUT) TerminateProcess(k->proc, 3); // a hung runtime must not hang Setup
        return 0;
    }
};
static int runOneTest(const wstring& exe, const wstring& api) {
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    HANDLE rd, wr;
    if (!CreatePipe(&rd, &wr, &sa, 0)) return 2;
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOW si{}; si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES; si.hStdOutput = wr; si.hStdError = wr;
    PROCESS_INFORMATION pi{};
    wstring cmd = L"\"" + exe + L"\" --api " + api;
    if (!CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        say(L"ERROR: could not start the test.");
        CloseHandle(rd); CloseHandle(wr);
        return 2;
    }
    CloseHandle(wr);
    TestWatchdog killer{pi.hProcess, CreateEventW(nullptr, TRUE, FALSE, nullptr)};
    HANDLE timer = CreateThread(nullptr, 0, TestWatchdog::run, &killer, 0, nullptr);
    string out; char buf[1024]; DWORD n;
    while (ReadFile(rd, buf, sizeof(buf), &n, nullptr) && n) out.append(buf, n);
    WaitForSingleObject(pi.hProcess, 50000);
    SetEvent(killer.stop);
    WaitForSingleObject(timer, 2000);
    CloseHandle(timer); CloseHandle(killer.stop);
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread); CloseHandle(rd);
    std::stringstream ss(out);
    string line;
    while (std::getline(ss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        // Keep the log readable: results and failures, not every state change.
        if (line.rfind("FAIL", 0) == 0 || line.rfind("runtime:", 0) == 0) say(L"  " + toWide(line));
    }
    return (int)code;
}
static int doSelfTest(const string& onlyApi) {
    wstring exe = installDir() + L"\\xrbridge_selftest32.exe";
    if (!fileExists(exe)) { say(L"ERROR: not installed yet."); return 2; }
    say(L"Put on your headset. Each graphics API shows its colour for about 4 seconds.");
    say(L"D3D11, D3D12 and OpenGL also show a white TOP half: if it is on the bottom, the image is upside down.");
    struct { const char* api; const wchar_t* name; const wchar_t* color; } tests[] = {
        {"d3d11", L"D3D11", L"green"}, {"d3d12", L"D3D12", L"blue"}, {"vulkan", L"Vulkan", L"orange"}, {"opengl", L"OpenGL", L"purple"}};
    int failures = 0;
    for (auto& t : tests) {
        if (!onlyApi.empty() && onlyApi != t.api) continue;
        say(wstring(L"Testing ") + t.name + L" (expect " + t.color + L")...");
        int code = runOneTest(exe, toWide(t.api));
        say(wstring(L"  ") + t.name + (code == 0 ? L": calls succeeded. Did you see the colour?" : L": FAILED"));
        if (code) ++failures;
        Sleep(800); // lets the runtime settle between sessions
    }
    say(failures ? L"Some tests failed. Logs: %LOCALAPPDATA%\\XRBridge32\\shim.log and host.log" : L"All calls succeeded.");
    return failures ? 1 : 0;
}

#include "gui.inc"

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, PWSTR, int show) {
    int argc = 0;
    wchar_t** argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (argc > 1) {
        g_cli = true;
        CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
        AttachConsole(ATTACH_PARENT_PROCESS);
        if (GetStdHandle(STD_OUTPUT_HANDLE) == nullptr || GetStdHandle(STD_OUTPUT_HANDLE) == INVALID_HANDLE_VALUE) {
            HANDLE con = CreateFileW(L"CONOUT$", GENERIC_WRITE, FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
            SetStdHandle(STD_OUTPUT_HANDLE, con);
        }
        bool force = false, noOpenVR = false, ok = true;
        wstring ocLocal, action, apiArg;
        for (int i = 1; i < argc; ++i) {
            wstring a = argv[i];
            if (a == L"--force") force = true;
            else if (a == L"--no-openvr") noOpenVR = true;
            else if (a == L"--oc-dir" && i + 1 < argc) ocLocal = argv[++i];
            else if (a == L"--api" && i + 1 < argc) apiArg = argv[++i];
            else if ((a == L"--d3d9-add" || a == L"--d3d9-remove") && i + 1 < argc) { action = a; ocLocal = argv[++i]; }
            else if (a == L"--zero-copy" && i + 1 < argc) { action = a; ocLocal = argv[++i]; }
            else action = a;
        }
        if (action == L"--install") ok = doInstall(ocLocal);
        else if (action == L"--enable") { ok = doEnableBridge(force); if (!noOpenVR) ok = doEnableOpenVR() && ok; }
        else if (action == L"--disable") ok = doDisable();
        else if (action == L"--uninstall") {
            ok = doUninstall();
            if (ok && GetConsoleWindow() == nullptr && !GetStdHandle(STD_OUTPUT_HANDLE))
                MessageBoxW(nullptr, L"XRBridge32 has been removed.", L"XRBridge32", MB_OK);
        }
        else if (action == L"--status") doStatus();
        else if (action == L"--d3d9-add") ok = doD3D9Add(ocLocal);
        else if (action == L"--d3d9-remove") ok = doD3D9Remove(ocLocal);
        else if (action == L"--zero-copy") setZeroCopy(ocLocal == L"on");
        else if (action == L"--selftest") return doSelfTest(toUtf8(apiArg));
        else {
            say(L"XRBridge32-Setup --install [--oc-dir <folder>] | --enable [--force] [--no-openvr] | --disable | --uninstall | --status | --selftest [--api d3d11|d3d12|vulkan|opengl] | --d3d9-add <game.exe> | --d3d9-remove <game.exe> | --zero-copy on|off");
            return 2;
        }
        return ok ? 0 : 1;
    }
    return runGui(inst, show);
}
