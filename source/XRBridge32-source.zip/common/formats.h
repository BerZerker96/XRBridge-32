// Swapchain formats the bridge can carry, and how each graphics API names them.
// The real runtime always sees DXGI formats, because the host talks D3D11 to it.
#pragma once
#include <cstdint>

struct XrbFormat { int dxgi; int typeless; int vk; int gl; int bytesPerPixel; bool depth; bool stencil; };

// DXGI values come from dxgiformat.h. VkFormat and GL values are numeric so this
// header does not need the Vulkan or OpenGL headers. Order is the preference order
// only when the runtime does not state one.
static const XrbFormat kXrbFormats[] = {
    {29 /*R8G8B8A8_UNORM_SRGB*/, 27, 43 /*R8G8B8A8_SRGB*/, 0x8C43 /*SRGB8_ALPHA8*/, 4, false, false},
    {28 /*R8G8B8A8_UNORM*/, 27, 37 /*R8G8B8A8_UNORM*/, 0x8058 /*RGBA8*/, 4, false, false},
    {91 /*B8G8R8A8_UNORM_SRGB*/, 90, 50 /*B8G8R8A8_SRGB*/, 0, 4, false, false},
    {87 /*B8G8R8A8_UNORM*/, 90, 44 /*B8G8R8A8_UNORM*/, 0, 4, false, false},
    {93 /*B8G8R8X8_UNORM_SRGB*/, 92, 0, 0, 4, false, false},
    {88 /*B8G8R8X8_UNORM*/, 92, 0, 0, 4, false, false},
    {10 /*R16G16B16A16_FLOAT*/, 9, 97 /*R16G16B16A16_SFLOAT*/, 0x881A /*RGBA16F*/, 8, false, false},
    {11 /*R16G16B16A16_UNORM*/, 9, 91 /*R16G16B16A16_UNORM*/, 0x805B /*RGBA16*/, 8, false, false},
    {24 /*R10G10B10A2_UNORM*/, 23, 64 /*A2B10G10R10_UNORM_PACK32*/, 0x8059 /*RGB10_A2*/, 4, false, false},
    {26 /*R11G11B10_FLOAT*/, 26, 122 /*B10G11R11_UFLOAT_PACK32*/, 0x8C3A /*R11F_G11F_B10F*/, 4, false, false},
    {2 /*R32G32B32A32_FLOAT*/, 1, 109 /*R32G32B32A32_SFLOAT*/, 0x8814 /*RGBA32F*/, 16, false, false},
    // Depth: shared with the same legacy handles. Typeless so D3D games can also sample them.
    {40 /*D32_FLOAT*/, 39, 126 /*D32_SFLOAT*/, 0x8CAC /*DEPTH_COMPONENT32F*/, 4, true, false},
    {20 /*D32_FLOAT_S8X24_UINT*/, 19, 130 /*D32_SFLOAT_S8_UINT*/, 0x8CAD /*DEPTH32F_STENCIL8*/, 8, true, true},
    {45 /*D24_UNORM_S8_UINT*/, 44, 129 /*D24_UNORM_S8_UINT*/, 0x88F0 /*DEPTH24_STENCIL8*/, 4, true, true},
    {55 /*D16_UNORM*/, 53, 124 /*D16_UNORM*/, 0x81A5 /*DEPTH_COMPONENT16*/, 2, true, false},
};
inline const XrbFormat* xrbFindDxgi(int dxgi) {
    for (auto& f : kXrbFormats) if (f.dxgi == dxgi) return &f;
    return nullptr;
}
inline const XrbFormat* xrbFindVk(int vk) {
    if (vk <= 0) return nullptr;
    for (auto& f : kXrbFormats) if (f.vk == vk) return &f;
    return nullptr;
}
inline const XrbFormat* xrbFindGl(int gl) {
    if (gl <= 0) return nullptr;
    for (auto& f : kXrbFormats) if (f.gl == gl) return &f;
    return nullptr;
}
