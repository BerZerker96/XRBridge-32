// xrbridge_host.exe: 64-bit process that owns the real OpenXR session.
//
// It links the Khronos loader, so it uses the 64-bit ActiveRuntime and 64-bit
// API layers (OpenXR Toolkit and so on) exactly as a native 64-bit game would.
// One pipe connection is served per app thread, so a blocking xrWaitFrame on one
// app thread cannot stall xrLocateSpace on another.
#define XR_USE_PLATFORM_WIN32
#define XR_USE_GRAPHICS_API_D3D11
#include <windows.h>
#include <unknwn.h>
#include <d3d11_1.h>
#include <d3d11_4.h>
#include <algorithm>
#include <dxgi1_2.h>
#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <atomic>
#include <thread>
#include "../common/ipc.h"
#include "../common/formats.h"

static void logf(const char* fmt, ...);
static void xrbChainDropped(int type) { logf("dropped unsupported struct type %d", type); }
#define XRB_GEN_HOST
#include "../common/gen_marshal.inc"

static FILE* g_log;
static std::mutex g_logMutex;
static HANDLE g_game;
static bool g_zeroCopy;
static void logf(const char* fmt, ...) {
    std::lock_guard<std::mutex> l(g_logMutex);
    if (!g_log) return;
    SYSTEMTIME t; GetLocalTime(&t);
    fprintf(g_log, "%02d:%02d:%02d.%03d [host] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list a; va_start(a, fmt); vfprintf(g_log, fmt, a); va_end(a);
    fputc('\n', g_log); fflush(g_log);
}
static void openLog(DWORD gamePid) {
    wchar_t dir[MAX_PATH];
    if (!GetEnvironmentVariableW(L"LOCALAPPDATA", dir, MAX_PATH)) return;
    std::wstring path = std::wstring(dir) + L"\\XRBridge32";
    CreateDirectoryW(path.c_str(), nullptr);
    path += L"\\host.log";
    g_log = _wfopen(path.c_str(), L"w");
    logf("xrbridge_host started for game pid %lu", gamePid);
}

// Extensions the app may see: the generated list holds every one whose functions and
// structs can all cross the process boundary, and these two are marshalled by hand.
static bool extensionAllowed(const char* name) {
    static const std::set<std::string> allowed = [] {
        std::set<std::string> a = {"XR_KHR_visibility_mask", "XR_KHR_win32_convert_performance_counter"};
        for (auto* e : kGenExtensions) a.insert(e);
        return a;
    }();
    return allowed.count(name) != 0;
}

template <class H> static uint64_t U(H h);
template <class T> static void safeRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

struct HostSession {
    XrInstance instance = XR_NULL_HANDLE;
    ID3D11Device* device = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    ID3D11DeviceContext4* ctx4 = nullptr;
    ID3D11Fence* fence = nullptr;
    HANDLE fenceHandle = nullptr;
    std::mutex ctxMutex;
    ~HostSession() {
        if (fenceHandle) CloseHandle(fenceHandle);
        safeRelease(fence); safeRelease(ctx4); safeRelease(ctx); safeRelease(device);
    }
};
struct HostSwapchain {
    std::shared_ptr<HostSession> session;
    std::vector<ID3D11Texture2D*> real;
    std::vector<ID3D11Texture2D*> shared;
    std::deque<uint32_t> acquired;
    bool bottomUp = false; // the game's API measures image rects from the bottom row
    uint32_t height = 0;
    ~HostSwapchain() { for (auto*& t : shared) safeRelease(t); }
};

static std::mutex g_mapMutex;
static std::map<uint64_t, std::shared_ptr<HostSession>> g_sessions;
static std::map<uint64_t, std::shared_ptr<HostSwapchain>> g_swapchains;
static std::set<uint64_t> g_instances;
static std::atomic<int> g_connections{0};
static std::atomic<bool> g_hadInstance{false};
static bool g_nullGfx;

template <class H> static uint64_t U(H h) { return (uint64_t)h; }
template <class P> static P extFn(XrInstance inst, const char* name) {
    PFN_xrVoidFunction fn = nullptr;
    xrGetInstanceProcAddr(inst, name, &fn);
    return reinterpret_cast<P>(fn);
}
static std::shared_ptr<HostSwapchain> findSwapchain(uint64_t h) {
    std::lock_guard<std::mutex> l(g_mapMutex);
    auto it = g_swapchains.find(h);
    return it == g_swapchains.end() ? nullptr : it->second;
}
static std::shared_ptr<HostSession> findSession(uint64_t h) {
    std::lock_guard<std::mutex> l(g_mapMutex);
    auto it = g_sessions.find(h);
    return it == g_sessions.end() ? nullptr : it->second;
}

// Creates the host's own D3D11 device on the adapter the runtime asked for.
static XrResult makeSessionDevice(XrInstance inst, XrSystemId sys, HostSession& s) {
    auto getReq = extFn<PFN_xrGetD3D11GraphicsRequirementsKHR>(inst, "xrGetD3D11GraphicsRequirementsKHR");
    if (!getReq) return XR_ERROR_EXTENSION_NOT_PRESENT;
    XrGraphicsRequirementsD3D11KHR req{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
    XrResult r = getReq(inst, sys, &req);
    if (XR_FAILED(r)) return r;

    IDXGIFactory1* factory = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&factory))) return XR_ERROR_RUNTIME_FAILURE;
    IDXGIAdapter1* adapter = nullptr;
    for (UINT i = 0; factory->EnumAdapters1(i, &adapter) == S_OK; ++i) {
        DXGI_ADAPTER_DESC1 d;
        adapter->GetDesc1(&d);
        if (!memcmp(&d.AdapterLuid, &req.adapterLuid, sizeof(LUID))) break;
        adapter->Release();
        adapter = nullptr;
    }
    factory->Release();
    if (!adapter) { logf("no DXGI adapter matches runtime LUID"); return XR_ERROR_RUNTIME_FAILURE; }

    D3D_FEATURE_LEVEL want[] = {D3D_FEATURE_LEVEL_12_1, D3D_FEATURE_LEVEL_12_0, D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0};
    HRESULT hr = D3D11CreateDevice(adapter, D3D_DRIVER_TYPE_UNKNOWN, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                                   want, ARRAYSIZE(want), D3D11_SDK_VERSION, &s.device, nullptr, &s.ctx);
    adapter->Release();
    if (FAILED(hr)) { logf("D3D11CreateDevice failed 0x%08lx", hr); return XR_ERROR_RUNTIME_FAILURE; }
    // The copy into the runtime's texture sits on the critical path to the compositor, so it
    // should not queue behind the game's next frame. Positive values need a privilege the
    // host may not have; that is harmless.
    {
        IDXGIDevice* dx = nullptr;
        if (SUCCEEDED(s.device->QueryInterface(__uuidof(IDXGIDevice), (void**)&dx))) { dx->SetGPUThreadPriority(7); dx->Release(); }
    }
    ID3D11Multithread* mt = nullptr;
    if (SUCCEEDED(s.ctx->QueryInterface(__uuidof(ID3D11Multithread), (void**)&mt))) {
        mt->SetMultithreadProtected(TRUE);
        mt->Release();
    }
    // Shared fence for frame sync. Without one the shim waits on the CPU instead,
    // so a failure here costs some latency rather than breaking the session.
    char noFence[8];
    if (!GetEnvironmentVariableA("XRB_NO_FENCE", noFence, sizeof(noFence))) {
        ID3D11Device5* d5 = nullptr;
        if (SUCCEEDED(s.device->QueryInterface(__uuidof(ID3D11Device5), (void**)&d5)) &&
            SUCCEEDED(s.ctx->QueryInterface(__uuidof(ID3D11DeviceContext4), (void**)&s.ctx4)) &&
            SUCCEEDED(d5->CreateFence(0, D3D11_FENCE_FLAG_SHARED, __uuidof(ID3D11Fence), (void**)&s.fence)) &&
            SUCCEEDED(s.fence->CreateSharedHandle(nullptr, GENERIC_ALL, nullptr, &s.fenceHandle))) {
            logf("shared fence ready");
        } else {
            logf("no shared fence on this system; using CPU sync");
            safeRelease(s.fence);
            s.fenceHandle = nullptr;
        }
        safeRelease(d5);
    }
    return XR_SUCCESS;
}

template <class T, class F>
static void twoCall(Reader& in, Writer& out, XrResult& res, F fn) {
    uint32_t cap = in.get<uint32_t>(), n = 0;
    if (cap > XRB_MAX_ARRAY) { res = XR_ERROR_VALIDATION_FAILURE; out.put(n); return; }
    std::vector<T> v(cap);
    res = fn(cap, &n, cap ? v.data() : nullptr);
    out.put(n);
    if (XR_SUCCEEDED(res) && cap) { out.put(n); out.raw(v.data(), sizeof(T) * n); }
}

// Resolved once per instance: going through the loader on every call would be wasteful.
static PFN_xrVoidFunction g_genCache[GEN_COUNT];
static uint64_t g_genCacheInstance;
static PFN_xrVoidFunction genFunction(uint32_t fn) {
    std::lock_guard<std::mutex> l(g_mapMutex);
    if (g_instances.empty()) return nullptr;
    uint64_t inst = *g_instances.rbegin();
    if (inst != g_genCacheInstance) {
        memset(g_genCache, 0, sizeof(g_genCache));
        g_genCacheInstance = inst;
    }
    if (!g_genCache[fn]) xrGetInstanceProcAddr((XrInstance)inst, kGenFnNames[fn], &g_genCache[fn]);
    return g_genCache[fn];
}

// OpenGL measures imageRect from the bottom row, but the texture the runtime sees holds the
// image the D3D way up, so the rect is mirrored to select the same pixels.
static void fixRect(XrSwapchainSubImage& sub) {
    auto sc = findSwapchain(U(sub.swapchain));
    if (sc && sc->bottomUp) sub.imageRect.offset.y = (int32_t)sc->height - sub.imageRect.offset.y - sub.imageRect.extent.height;
}
static void fixBottomUpRects(const XrCompositionLayerBaseHeader* h) {
    switch ((int)h->type) {
    case XR_TYPE_COMPOSITION_LAYER_PROJECTION: {
        auto* p = (XrCompositionLayerProjection*)h;
        auto* views = const_cast<XrCompositionLayerProjectionView*>(p->views);
        for (uint32_t i = 0; i < p->viewCount; ++i) {
            fixRect(views[i].subImage);
            for (auto* b = (XrBaseOutStructure*)views[i].next; b; b = b->next)
                if (b->type == XR_TYPE_COMPOSITION_LAYER_DEPTH_INFO_KHR) fixRect(((XrCompositionLayerDepthInfoKHR*)b)->subImage);
        }
        break;
    }
    case XR_TYPE_COMPOSITION_LAYER_QUAD: fixRect(((XrCompositionLayerQuad*)h)->subImage); break;
    case XR_TYPE_COMPOSITION_LAYER_CYLINDER_KHR: fixRect(((XrCompositionLayerCylinderKHR*)h)->subImage); break;
    case XR_TYPE_COMPOSITION_LAYER_EQUIRECT_KHR: fixRect(((XrCompositionLayerEquirectKHR*)h)->subImage); break;
    case XR_TYPE_COMPOSITION_LAYER_EQUIRECT2_KHR: fixRect(((XrCompositionLayerEquirect2KHR*)h)->subImage); break;
    default: break;
    }
}

// Frame timing, logged every 10 s while frames flow: where each frame's time goes,
// so a choppy game shows whether the runtime, the copy, a layer or the game is late.
namespace frame_stats {
struct Op { std::atomic<uint64_t> n{0}, sum{0}, max{0}; };
static Op waitFrame, release, endFrame, interval;
static std::atomic<uint64_t> cpuSynced{0};
static std::atomic<int64_t> lastEnd{0}, nextLog{0};
static double usPerTick() {
    static double v = [] { LARGE_INTEGER f; QueryPerformanceFrequency(&f); return 1e6 / (double)f.QuadPart; }();
    return v;
}
static int64_t now() { LARGE_INTEGER c; QueryPerformanceCounter(&c); return c.QuadPart; }
static void add(Op& o, int64_t ticks) {
    const uint64_t us = (uint64_t)(ticks * usPerTick());
    o.n++; o.sum += us;
    uint64_t m = o.max.load();
    while (us > m && !o.max.compare_exchange_weak(m, us)) {}
}
static void take(Op& o, double& avg, double& mx, uint64_t& n) {
    n = o.n.exchange(0);
    const uint64_t sum = o.sum.exchange(0);
    mx = o.max.exchange(0) / 1000.0;
    avg = n ? sum / 1000.0 / n : 0;
}
static void endFrameDone(int64_t t) {
    const int64_t prev = lastEnd.exchange(t);
    if (prev) add(interval, t - prev);
    int64_t due = nextLog.load();
    if (!due) { nextLog = t + (int64_t)(10e6 / usPerTick()); return; }
    if (t < due || !nextLog.compare_exchange_strong(due, t + (int64_t)(10e6 / usPerTick()))) return;
    double ia, im, wa, wm, ra, rm, ea, em;
    uint64_t in_, wn, rn, en;
    take(interval, ia, im, in_); take(waitFrame, wa, wm, wn); take(release, ra, rm, rn); take(endFrame, ea, em, en);
    const uint64_t cpu = cpuSynced.exchange(0);
    logf("frames: %llu in 10 s (%.1f fps), interval avg %.2f / max %.2f ms | xrWaitFrame avg %.2f / max %.2f | "
         "release (copy + 64-bit layers + runtime) avg %.2f / max %.2f x%llu | xrEndFrame avg %.2f / max %.2f%s",
         (unsigned long long)in_, in_ / 10.0, ia, im, wa, wm, ra, rm, (unsigned long long)rn, ea, em,
         cpu ? " | the game used CPU sync (no shared fence): it waits for its GPU every image" : "");
}
} // namespace frame_stats

// Serves one request. `in` starts after the opcode.
static XrResult dispatchOp(uint32_t op, Reader& in, Writer& out, Arena& a);
static XrResult dispatch(uint32_t op, Reader& in, Writer& out, Arena& a) {
    if (op != OP_WAIT_FRAME && op != OP_RELEASE_IMAGE && op != OP_END_FRAME) return dispatchOp(op, in, out, a);
    const int64_t t0 = frame_stats::now();
    const XrResult r = dispatchOp(op, in, out, a);
    const int64_t t1 = frame_stats::now();
    if (op == OP_WAIT_FRAME) frame_stats::add(frame_stats::waitFrame, t1 - t0);
    else if (op == OP_RELEASE_IMAGE) frame_stats::add(frame_stats::release, t1 - t0);
    else { frame_stats::add(frame_stats::endFrame, t1 - t0); frame_stats::endFrameDone(t1); }
    return r;
}
static XrResult dispatchOp(uint32_t op, Reader& in, Writer& out, Arena& a) {
    XrResult res = XR_SUCCESS;
    switch (op) {
    case OP_HELLO: out.put(XRB_PROTOCOL); break;

    case OP_ENUM_EXTENSIONS: {
        uint32_t n = 0;
        res = xrEnumerateInstanceExtensionProperties(nullptr, 0, &n, nullptr);
        if (XR_FAILED(res)) { logf("could not load the 64-bit OpenXR runtime (%d). Is one set active and still installed?", (int)res); break; }
        std::vector<XrExtensionProperties> all(n, {XR_TYPE_EXTENSION_PROPERTIES});
        res = xrEnumerateInstanceExtensionProperties(nullptr, n, &n, all.data());
        if (XR_FAILED(res)) break;
        std::vector<std::pair<std::string, uint32_t>> kept;
        bool d3d11 = false;
        for (uint32_t i = 0; i < n; ++i) {
            if (!strcmp(all[i].extensionName, "XR_KHR_D3D11_enable")) { d3d11 = true; kept.push_back({all[i].extensionName, all[i].extensionVersion}); }
            else if (extensionAllowed(all[i].extensionName)) kept.push_back({all[i].extensionName, all[i].extensionVersion});
        }
        if (!d3d11) logf("the 64-bit runtime has no XR_KHR_D3D11_enable; the bridge cannot present");
        out.put((uint8_t)(d3d11 ? 1 : 0));
        out.put((uint32_t)kept.size());
        for (auto& e : kept) { out.str(e.first.c_str()); out.put(e.second); }
        break;
    }
    case OP_CREATE_INSTANCE: {
        XrInstanceCreateInfo ci{XR_TYPE_INSTANCE_CREATE_INFO};
        ci.createFlags = in.get<XrInstanceCreateFlags>();
        ci.applicationInfo = in.get<XrApplicationInfo>();
        uint32_t nl = in.get<uint32_t>();
        std::vector<std::string> ls, es;
        for (uint32_t i = 0; i < nl && !in.bad; ++i) ls.push_back(in.str());
        uint32_t ne = in.get<uint32_t>();
        for (uint32_t i = 0; i < ne && !in.bad; ++i) es.push_back(in.str());
        std::vector<const char*> lp, ep;
        for (auto& s : ls) lp.push_back(s.c_str());
        // The host always renders through D3D11, whichever API the game uses.
        ep.push_back("XR_KHR_D3D11_enable");
        for (auto& s : es) {
            if (s == "XR_KHR_D3D11_enable") continue;
            if (!extensionAllowed(s.c_str())) { logf("rejected extension %s", s.c_str()); return XR_ERROR_EXTENSION_NOT_PRESENT; }
            ep.push_back(s.c_str());
        }
        ci.enabledApiLayerCount = (uint32_t)lp.size(); ci.enabledApiLayerNames = lp.data();
        ci.enabledExtensionCount = (uint32_t)ep.size(); ci.enabledExtensionNames = ep.data();
        XrInstance inst = XR_NULL_HANDLE;
        res = xrCreateInstance(&ci, &inst);
        logf("xrCreateInstance app='%s' -> %d", ci.applicationInfo.applicationName, res);
        if (XR_SUCCEEDED(res)) {
            std::lock_guard<std::mutex> l(g_mapMutex);
            g_instances.insert(U(inst));
            g_hadInstance = true;
        }
        out.put(U(inst));
        break;
    }
    case OP_DESTROY_INSTANCE: {
        XrInstance inst = (XrInstance)in.get<uint64_t>();
        // Devices stay alive until after xrDestroyInstance: the runtime may still use them.
        std::vector<std::shared_ptr<HostSession>> keepS;
        std::vector<std::shared_ptr<HostSwapchain>> keepC;
        {
            std::lock_guard<std::mutex> l(g_mapMutex);
            for (auto it = g_swapchains.begin(); it != g_swapchains.end();) {
                if (it->second->session->instance == inst) { keepC.push_back(it->second); it = g_swapchains.erase(it); } else ++it;
            }
            for (auto it = g_sessions.begin(); it != g_sessions.end();) {
                if (it->second->instance == inst) { keepS.push_back(it->second); it = g_sessions.erase(it); } else ++it;
            }
            g_instances.erase(U(inst));
        }
        res = xrDestroyInstance(inst);
        break;
    }
    case OP_GET_INSTANCE_PROPERTIES: {
        XrInstanceProperties p{XR_TYPE_INSTANCE_PROPERTIES};
        res = xrGetInstanceProperties((XrInstance)in.get<uint64_t>(), &p);
        out.put(p.runtimeVersion);
        out.str(p.runtimeName);
        break;
    }
    case OP_POLL_EVENT: {
        XrEventDataBuffer ev{XR_TYPE_EVENT_DATA_BUFFER};
        res = xrPollEvent((XrInstance)in.get<uint64_t>(), &ev);
        out.put((uint32_t)ev.type);
        if (res != XR_SUCCESS) break;
        // Every event type in the registry, not just the core ones.
        out.put((uint8_t)(isKnownOut((int)ev.type) ? 1 : 0));
        sOAny(out, &ev);
        break;
    }
    case OP_RESULT_TO_STRING: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        char b[XR_MAX_RESULT_STRING_SIZE] = {};
        res = xrResultToString(i, (XrResult)in.get<int32_t>(), b);
        out.str(b);
        break;
    }
    case OP_STRUCT_TO_STRING: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        char b[XR_MAX_STRUCTURE_NAME_SIZE] = {};
        res = xrStructureTypeToString(i, (XrStructureType)in.get<int32_t>(), b);
        out.str(b);
        break;
    }
    case OP_GET_SYSTEM: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemGetInfo gi{XR_TYPE_SYSTEM_GET_INFO};
        gi.formFactor = (XrFormFactor)in.get<int32_t>();
        XrSystemId id = XR_NULL_SYSTEM_ID;
        res = xrGetSystem(i, &gi, &id);
        out.put(id);
        break;
    }
    case OP_GET_SYSTEM_PROPERTIES: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemId id = in.get<uint64_t>();
        XrSystemProperties p{XR_TYPE_SYSTEM_PROPERTIES};
        p.next = (void*)dChainIn(in, a);
        res = xrGetSystemProperties(i, id, &p);
        out.put(p.vendorId); out.str(p.systemName);
        out.put(p.graphicsProperties); out.put(p.trackingProperties);
        chainOut(out, p.next);
        break;
    }
    case OP_ENUM_BLEND_MODES: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemId id = in.get<uint64_t>();
        auto vc = (XrViewConfigurationType)in.get<int32_t>();
        twoCall<XrEnvironmentBlendMode>(in, out, res, [&](uint32_t c, uint32_t* n, XrEnvironmentBlendMode* v) {
            return xrEnumerateEnvironmentBlendModes(i, id, vc, c, n, v); });
        break;
    }
    case OP_CREATE_SESSION: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSessionCreateFlags flags = in.get<XrSessionCreateFlags>();
        XrSystemId sys = in.get<uint64_t>();
        std::string api = in.str();
        auto s = std::make_shared<HostSession>();
        s->instance = i;
        XrGraphicsBindingD3D11KHR gb{XR_TYPE_GRAPHICS_BINDING_D3D11_KHR};
        if (g_nullGfx) {
            // Test mode: the mock runtime ignores the binding. Spec order is kept.
            auto getReq = extFn<PFN_xrGetD3D11GraphicsRequirementsKHR>(i, "xrGetD3D11GraphicsRequirementsKHR");
            XrGraphicsRequirementsD3D11KHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
            if (getReq) getReq(i, sys, &rq);
        } else {
            res = makeSessionDevice(i, sys, *s);
            if (XR_FAILED(res)) break;
            gb.device = s->device;
        }
        XrSessionCreateInfo ci{XR_TYPE_SESSION_CREATE_INFO, &gb, flags, sys};
        XrSession session = XR_NULL_HANDLE;
        res = xrCreateSession(i, &ci, &session);
        logf("xrCreateSession for a %s game -> %d", api.c_str(), res);
        uint64_t gameFence = 0;
        if (XR_SUCCEEDED(res)) {
            HANDLE dup = nullptr;
            if (s->fenceHandle && !DuplicateHandle(GetCurrentProcess(), s->fenceHandle, g_game, &dup, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
                logf("could not pass the fence to the game (error %lu); using CPU sync", GetLastError());
                dup = nullptr;
            }
            gameFence = (uint64_t)(uintptr_t)dup;
            std::lock_guard<std::mutex> l(g_mapMutex);
            g_sessions[U(session)] = s;
        }
        out.put(U(session));
        out.put(gameFence);
        break;
    }
    case OP_DESTROY_SESSION: {
        uint64_t h = in.get<uint64_t>();
        std::shared_ptr<HostSession> s = findSession(h);
        {
            std::lock_guard<std::mutex> l(g_mapMutex);
            for (auto it = g_swapchains.begin(); it != g_swapchains.end();)
                it = it->second->session == s ? g_swapchains.erase(it) : std::next(it);
            g_sessions.erase(h);
        }
        res = xrDestroySession((XrSession)h);
        break;
    }
    case OP_ENUM_REF_SPACES: {
        XrSession s = (XrSession)in.get<uint64_t>();
        twoCall<XrReferenceSpaceType>(in, out, res, [&](uint32_t c, uint32_t* n, XrReferenceSpaceType* v) {
            return xrEnumerateReferenceSpaces(s, c, n, v); });
        break;
    }
    case OP_CREATE_REF_SPACE: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrReferenceSpaceCreateInfo ci{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
        dI_XrReferenceSpaceCreateInfo(in, ci, a);
        XrSpace sp = XR_NULL_HANDLE;
        res = xrCreateReferenceSpace(s, &ci, &sp);
        out.put(U(sp));
        break;
    }
    case OP_GET_BOUNDS: {
        XrSession s = (XrSession)in.get<uint64_t>();
        auto t = (XrReferenceSpaceType)in.get<int32_t>();
        XrExtent2Df b{};
        res = xrGetReferenceSpaceBoundsRect(s, t, &b);
        out.put(b);
        break;
    }
    case OP_CREATE_ACTION_SPACE: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrActionSpaceCreateInfo ci{XR_TYPE_ACTION_SPACE_CREATE_INFO};
        dI_XrActionSpaceCreateInfo(in, ci, a);
        XrSpace sp = XR_NULL_HANDLE;
        res = xrCreateActionSpace(s, &ci, &sp);
        out.put(U(sp));
        break;
    }
    case OP_LOCATE_SPACE: {
        XrSpace sp = (XrSpace)in.get<uint64_t>();
        XrSpace base = (XrSpace)in.get<uint64_t>();
        XrTime t = in.get<XrTime>();
        XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
        loc.next = (void*)dChainIn(in, a);
        res = xrLocateSpace(sp, base, t, &loc);
        out.put(loc.locationFlags); out.put(loc.pose);
        chainOut(out, loc.next);
        break;
    }
    case OP_DESTROY_SPACE: res = xrDestroySpace((XrSpace)in.get<uint64_t>()); break;
    case OP_ENUM_VIEW_CONFIGS: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemId id = in.get<uint64_t>();
        twoCall<XrViewConfigurationType>(in, out, res, [&](uint32_t c, uint32_t* n, XrViewConfigurationType* v) {
            return xrEnumerateViewConfigurations(i, id, c, n, v); });
        break;
    }
    case OP_GET_VIEW_CONFIG_PROPS: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemId id = in.get<uint64_t>();
        auto vc = (XrViewConfigurationType)in.get<int32_t>();
        XrViewConfigurationProperties p{XR_TYPE_VIEW_CONFIGURATION_PROPERTIES};
        res = xrGetViewConfigurationProperties(i, id, vc, &p);
        out.put((int32_t)p.viewConfigurationType); out.put(p.fovMutable);
        break;
    }
    case OP_ENUM_VIEW_CONFIG_VIEWS: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemId id = in.get<uint64_t>();
        auto vc = (XrViewConfigurationType)in.get<int32_t>();
        uint32_t cap = in.get<uint32_t>(), n = 0;
        if (cap > XRB_MAX_ARRAY) return XR_ERROR_VALIDATION_FAILURE;
        std::vector<XrViewConfigurationView> v(cap, {XR_TYPE_VIEW_CONFIGURATION_VIEW});
        for (auto& e : v) e.next = (void*)dChainIn(in, a);
        res = xrEnumerateViewConfigurationViews(i, id, vc, cap, &n, cap ? v.data() : nullptr);
        out.put(n);
        if (XR_SUCCEEDED(res) && cap) for (uint32_t k = 0; k < n; ++k) {
            uint32_t f[6] = {v[k].recommendedImageRectWidth, v[k].maxImageRectWidth, v[k].recommendedImageRectHeight,
                             v[k].maxImageRectHeight, v[k].recommendedSwapchainSampleCount, v[k].maxSwapchainSampleCount};
            out.raw(f, sizeof(f));
            chainOut(out, v[k].next);
        }
        break;
    }
    case OP_ENUM_SWAPCHAIN_FORMATS: {
        XrSession s = (XrSession)in.get<uint64_t>();
        uint32_t n = 0;
        res = xrEnumerateSwapchainFormats(s, 0, &n, nullptr);
        if (XR_FAILED(res)) break;
        std::vector<int64_t> all(n);
        res = xrEnumerateSwapchainFormats(s, n, &n, all.data());
        std::vector<int64_t> kept;
        if (XR_SUCCEEDED(res)) for (uint32_t i = 0; i < n; ++i) if (xrbFindDxgi((int)all[i])) kept.push_back(all[i]);
        out.put((uint32_t)kept.size());
        out.raw(kept.data(), kept.size() * sizeof(int64_t));
        break;
    }
    case OP_CREATE_SWAPCHAIN: {
        XrSession session = (XrSession)in.get<uint64_t>();
        XrSwapchainCreateInfo ci{XR_TYPE_SWAPCHAIN_CREATE_INFO};
        ci.next = dChainIn(in, a);
        ci.createFlags = in.get<XrSwapchainCreateFlags>();
        ci.usageFlags = in.get<XrSwapchainUsageFlags>();
        ci.format = in.get<int64_t>();
        uint32_t f[6]; in.raw(f, sizeof(f));
        const bool bottomUp = in.get<uint8_t>() != 0;
        bool nt = in.get<uint8_t>() != 0 && !g_nullGfx;
        const XrbFormat* fm = xrbFindDxgi((int)ci.format);
        if (!fm) return XR_ERROR_SWAPCHAIN_FORMAT_UNSUPPORTED;
        ci.usageFlags |= XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;
        ci.usageFlags |= fm->depth ? XR_SWAPCHAIN_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT : XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;
        ci.sampleCount = f[0]; ci.width = f[1]; ci.height = f[2]; ci.faceCount = f[3]; ci.arraySize = f[4]; ci.mipCount = f[5];
        auto sess = findSession(U(session));
        if (!sess) return XR_ERROR_HANDLE_INVALID;
        XrSwapchain sc = XR_NULL_HANDLE;
        res = xrCreateSwapchain(session, &ci, &sc);
        logf("xrCreateSwapchain %ux%u fmt=%lld samples=%u arr=%u faces=%u mips=%u -> %d", ci.width, ci.height, (long long)ci.format,
             ci.sampleCount, ci.arraySize, ci.faceCount, ci.mipCount, res);
        if (XR_FAILED(res)) break;
        uint32_t n = 0;
        res = xrEnumerateSwapchainImages(sc, 0, &n, nullptr);
        std::vector<XrSwapchainImageD3D11KHR> imgs(n, {XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR});
        if (XR_SUCCEEDED(res)) res = xrEnumerateSwapchainImages(sc, n, &n, (XrSwapchainImageBaseHeader*)imgs.data());
        if (XR_FAILED(res)) { xrDestroySwapchain(sc); break; }
        auto h = std::make_shared<HostSwapchain>();
        h->session = sess;
        h->bottomUp = bottomUp;
        h->height = ci.height;
        for (auto& im : imgs) h->real.push_back(im.texture);

        std::vector<uint64_t> handles(n, 0);
        if (!g_nullGfx) {
            // The host owns the shared textures, and the game opens them with whichever
            // API it uses. Legacy shared handles are what D3D12, Vulkan and OpenGL interop
            // on real drivers is known to accept from D3D11.
            // Optional: hand the game the runtime's own textures, which removes the copy.
            // Only some runtimes create shareable textures, and it is not proven on real
            // drivers yet, so it stays opt-in.
            bool direct = g_zeroCopy && !nt && !imgs.empty();
            for (uint32_t i = 0; i < n && direct; ++i) {
                IDXGIResource* r = nullptr;
                HANDLE sh = nullptr;
                if (FAILED(h->real[i]->QueryInterface(__uuidof(IDXGIResource), (void**)&r)) || FAILED(r->GetSharedHandle(&sh)) || !sh) direct = false;
                if (r) r->Release();
                handles[i] = (uint64_t)(uintptr_t)sh;
            }
            if (direct) {
                logf("zero-copy swapchain: the game renders straight into the runtime's textures");
                std::lock_guard<std::mutex> l(g_mapMutex);
                g_swapchains[U(sc)] = h;
                out.put(U(sc));
                out.put((uint8_t)0);
                out.put(n);
                out.raw(handles.data(), handles.size() * sizeof(uint64_t));
                break;
            }
            std::fill(handles.begin(), handles.end(), 0);
            D3D11_TEXTURE2D_DESC d{};
            d.Width = ci.width; d.Height = ci.height;
            d.MipLevels = ci.mipCount; d.ArraySize = ci.arraySize * ci.faceCount;
            d.SampleDesc.Count = ci.sampleCount;
            d.Usage = D3D11_USAGE_DEFAULT;
            d.BindFlags = (fm->depth ? D3D11_BIND_DEPTH_STENCIL : D3D11_BIND_RENDER_TARGET) | D3D11_BIND_SHADER_RESOURCE;
            if ((ci.usageFlags & XR_SWAPCHAIN_USAGE_UNORDERED_ACCESS_BIT) && ci.sampleCount == 1 && !fm->depth) d.BindFlags |= D3D11_BIND_UNORDERED_ACCESS;
            // Typeless lets the app create sRGB or linear views as on a real runtime;
            // the exact format is the fallback for drivers that refuse to share it.
            // NT handles are tried first when the game asked for them, legacy handles last.
            const DXGI_FORMAT candidates[2] = {(DXGI_FORMAT)fm->typeless, (DXGI_FORMAT)fm->dxgi};
            bool handlesNt = false;
            auto dropHandles = [&] {
                for (auto& v : handles) if (v && handlesNt) { HANDLE x = (HANDLE)(uintptr_t)v; DuplicateHandle(g_game, x, nullptr, nullptr, 0, FALSE, DUPLICATE_CLOSE_SOURCE); }
                std::fill(handles.begin(), handles.end(), 0);
            };
            HRESULT hr = E_FAIL;
            for (int kind = nt ? 1 : 0; kind >= 0 && FAILED(hr); --kind) {
                nt = kind == 1;
                d.MiscFlags = nt ? (D3D11_RESOURCE_MISC_SHARED | D3D11_RESOURCE_MISC_SHARED_NTHANDLE) : D3D11_RESOURCE_MISC_SHARED;
                if (ci.faceCount == 6) d.MiscFlags |= D3D11_RESOURCE_MISC_TEXTURECUBE;
                for (int attempt = 0; attempt < 2 && FAILED(hr); ++attempt) {
                    if (attempt == 1 && candidates[0] == candidates[1]) break;
                    dropHandles();
                    for (auto*& t : h->shared) safeRelease(t);
                    h->shared.clear();
                    d.Format = candidates[attempt];
                    hr = S_OK;
                    handlesNt = nt;
                    for (uint32_t i = 0; i < n && SUCCEEDED(hr); ++i) {
                        ID3D11Texture2D* t = nullptr;
                        hr = sess->device->CreateTexture2D(&d, nullptr, &t);
                        if (FAILED(hr)) break;
                        h->shared.push_back(t);
                        HANDLE sh = nullptr;
                        if (nt) {
                            // Made in the host, then moved into the game, which closes it.
                            IDXGIResource1* r = nullptr;
                            hr = t->QueryInterface(__uuidof(IDXGIResource1), (void**)&r);
                            HANDLE mine = nullptr;
                            if (SUCCEEDED(hr)) { hr = r->CreateSharedHandle(nullptr, DXGI_SHARED_RESOURCE_READ | DXGI_SHARED_RESOURCE_WRITE, nullptr, &mine); r->Release(); }
                            if (SUCCEEDED(hr) && !DuplicateHandle(GetCurrentProcess(), mine, g_game, &sh, 0, FALSE, DUPLICATE_SAME_ACCESS | DUPLICATE_CLOSE_SOURCE)) {
                                hr = HRESULT_FROM_WIN32(GetLastError());
                                sh = nullptr;
                            }
                        } else {
                            IDXGIResource* r = nullptr;
                            hr = t->QueryInterface(__uuidof(IDXGIResource), (void**)&r);
                            if (SUCCEEDED(hr)) { hr = r->GetSharedHandle(&sh); r->Release(); }
                        }
                        handles[i] = (uint64_t)(uintptr_t)sh;
                    }
                    if (FAILED(hr)) logf("shared texture failed: %s handle, fmt %d, %ux%u, mips %u, array %u, samples %u, hr 0x%08lx", nt ? "NT" : "legacy", (int)d.Format, d.Width, d.Height, d.MipLevels, d.ArraySize, d.SampleDesc.Count, hr);
                }
            }
            if (FAILED(hr)) { dropHandles(); xrDestroySwapchain(sc); return XR_ERROR_SWAPCHAIN_FORMAT_UNSUPPORTED; }
        }
        {
            std::lock_guard<std::mutex> l(g_mapMutex);
            g_swapchains[U(sc)] = h;
        }
        out.put(U(sc));
        out.put((uint8_t)(nt ? 1 : 0));
        out.put(n);
        out.raw(handles.data(), handles.size() * sizeof(uint64_t));
        break;
    }
    case OP_DESTROY_SWAPCHAIN: {
        uint64_t h = in.get<uint64_t>();
        {
            std::lock_guard<std::mutex> l(g_mapMutex);
            g_swapchains.erase(h);
        }
        res = xrDestroySwapchain((XrSwapchain)h);
        break;
    }
    case OP_ACQUIRE_IMAGE: {
        uint64_t h = in.get<uint64_t>();
        uint32_t idx = 0;
        res = xrAcquireSwapchainImage((XrSwapchain)h, nullptr, &idx);
        if (XR_SUCCEEDED(res)) {
            if (auto sc = findSwapchain(h)) {
                std::lock_guard<std::mutex> l(g_mapMutex);
                sc->acquired.push_back(idx);
            }
        }
        out.put(idx);
        break;
    }
    case OP_WAIT_IMAGE: {
        XrSwapchain sc = (XrSwapchain)in.get<uint64_t>();
        XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
        wi.timeout = in.get<XrDuration>();
        res = xrWaitSwapchainImage(sc, &wi);
        break;
    }
    case OP_RELEASE_IMAGE: {
        uint64_t h = in.get<uint64_t>();
        uint64_t syncValue = in.get<uint64_t>();
        if (!syncValue && !g_nullGfx) frame_stats::cpuSynced++;
        auto sc = findSwapchain(h);
        if (!sc) return XR_ERROR_HANDLE_INVALID;
        uint32_t idx;
        {
            std::lock_guard<std::mutex> l(g_mapMutex);
            if (sc->acquired.empty()) return XR_ERROR_CALL_ORDER_INVALID;
            idx = sc->acquired.front();
            sc->acquired.pop_front();
        }
        if (!g_nullGfx) {
            // The app has finished this image: copy it into the runtime's own texture.
            std::lock_guard<std::mutex> l(sc->session->ctxMutex);
            HostSession& se = *sc->session;
            if (syncValue && se.fence && se.ctx4) se.ctx4->Wait(se.fence, syncValue);
            if (!sc->shared.empty()) {
                if (idx >= sc->shared.size()) return XR_ERROR_RUNTIME_FAILURE;
                se.ctx->CopyResource(sc->real[idx], sc->shared[idx]);
            }
            se.ctx->Flush();
        }
        res = xrReleaseSwapchainImage((XrSwapchain)h, nullptr);
        break;
    }
    case OP_BEGIN_SESSION: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrSessionBeginInfo bi{XR_TYPE_SESSION_BEGIN_INFO};
        dI_XrSessionBeginInfo(in, bi, a);
        res = xrBeginSession(s, &bi);
        break;
    }
    case OP_END_SESSION: res = xrEndSession((XrSession)in.get<uint64_t>()); break;
    case OP_REQUEST_EXIT: res = xrRequestExitSession((XrSession)in.get<uint64_t>()); break;
    case OP_WAIT_FRAME: {
        XrSession se = (XrSession)in.get<uint64_t>();
        XrFrameWaitInfo wi{XR_TYPE_FRAME_WAIT_INFO};
        wi.next = dChainIn(in, a);
        XrFrameState st{XR_TYPE_FRAME_STATE};
        st.next = (void*)dChainIn(in, a);
        res = xrWaitFrame(se, &wi, &st);
        out.put(st.predictedDisplayTime); out.put(st.predictedDisplayPeriod); out.put(st.shouldRender);
        chainOut(out, st.next);
        break;
    }
    case OP_BEGIN_FRAME: {
        XrSession se = (XrSession)in.get<uint64_t>();
        XrFrameBeginInfo bi{XR_TYPE_FRAME_BEGIN_INFO};
        bi.next = dChainIn(in, a);
        res = xrBeginFrame(se, &bi);
        break;
    }
    case OP_END_FRAME: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrFrameEndInfo fi{XR_TYPE_FRAME_END_INFO};
        dI_XrFrameEndInfo(in, fi, a);
        if (in.bad) return XR_ERROR_RUNTIME_FAILURE;
        // Layers the generator could not carry arrive as null, and are left out.
        auto** layers = const_cast<const XrCompositionLayerBaseHeader**>(fi.layers);
        uint32_t kept = 0;
        for (uint32_t i = 0; i < fi.layerCount; ++i) {
            if (!layers[i]) continue;
            layers[kept++] = layers[i];
            fixBottomUpRects(layers[i]);
        }
        fi.layerCount = kept;
        res = xrEndFrame(s, &fi);
        break;
    }
    case OP_LOCATE_VIEWS: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrViewLocateInfo li{XR_TYPE_VIEW_LOCATE_INFO};
        dI_XrViewLocateInfo(in, li, a);
        XrViewState st{XR_TYPE_VIEW_STATE};
        st.next = (void*)dChainIn(in, a);
        uint32_t cap = in.get<uint32_t>(), n = 0;
        if (cap > XRB_MAX_ARRAY) return XR_ERROR_VALIDATION_FAILURE;
        std::vector<XrView> v(cap, {XR_TYPE_VIEW});
        for (auto& e : v) e.next = (void*)dChainIn(in, a);
        res = xrLocateViews(s, &li, &st, cap, &n, cap ? v.data() : nullptr);
        out.put(st.viewStateFlags);
        chainOut(out, st.next);
        out.put(n);
        if (XR_SUCCEEDED(res) && cap) for (uint32_t i = 0; i < n; ++i) { out.put(v[i].pose); out.put(v[i].fov); chainOut(out, v[i].next); }
        break;
    }
    case OP_STRING_TO_PATH: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        std::string s = in.str();
        XrPath p = XR_NULL_PATH;
        res = xrStringToPath(i, s.c_str(), &p);
        out.put(p);
        break;
    }
    case OP_PATH_TO_STRING: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrPath p = in.get<XrPath>();
        uint32_t n = 0;
        res = xrPathToString(i, p, 0, &n, nullptr);
        std::string b(n, 0);
        if (XR_SUCCEEDED(res)) res = xrPathToString(i, p, n, &n, b.data());
        out.put(n);
        out.str(b.c_str());
        break;
    }
    case OP_CREATE_ACTION_SET: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrActionSetCreateInfo ci{XR_TYPE_ACTION_SET_CREATE_INFO};
        dI_XrActionSetCreateInfo(in, ci, a);
        XrActionSet as = XR_NULL_HANDLE;
        res = xrCreateActionSet(i, &ci, &as);
        out.put(U(as));
        break;
    }
    case OP_DESTROY_ACTION_SET: res = xrDestroyActionSet((XrActionSet)in.get<uint64_t>()); break;
    case OP_CREATE_ACTION: {
        XrActionSet st = (XrActionSet)in.get<uint64_t>();
        XrActionCreateInfo ci{XR_TYPE_ACTION_CREATE_INFO};
        dI_XrActionCreateInfo(in, ci, a);
        XrAction act = XR_NULL_HANDLE;
        res = xrCreateAction(st, &ci, &act);
        out.put(U(act));
        break;
    }
    case OP_DESTROY_ACTION: res = xrDestroyAction((XrAction)in.get<uint64_t>()); break;
    case OP_SUGGEST_BINDINGS: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrInteractionProfileSuggestedBinding sb{XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING};
        dI_XrInteractionProfileSuggestedBinding(in, sb, a);
        res = xrSuggestInteractionProfileBindings(i, &sb);
        break;
    }
    case OP_ATTACH_ACTION_SETS: {
        XrSession s = (XrSession)in.get<uint64_t>();
        auto sets = in.vec<uint64_t>();
        std::vector<XrActionSet> h;
        for (auto v : sets) h.push_back((XrActionSet)v);
        XrSessionActionSetsAttachInfo ai{XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO};
        ai.countActionSets = (uint32_t)h.size();
        ai.actionSets = h.data();
        res = xrAttachSessionActionSets(s, &ai);
        break;
    }
    case OP_GET_INTERACTION_PROFILE: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrPath top = in.get<XrPath>();
        XrInteractionProfileState st{XR_TYPE_INTERACTION_PROFILE_STATE};
        res = xrGetCurrentInteractionProfile(s, top, &st);
        out.put(st.interactionProfile);
        break;
    }
    case OP_GET_STATE_BOOL: case OP_GET_STATE_FLOAT: case OP_GET_STATE_VEC2: case OP_GET_STATE_POSE: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO};
        dI_XrActionStateGetInfo(in, gi, a);
        if (op == OP_GET_STATE_BOOL) {
            XrActionStateBoolean st{XR_TYPE_ACTION_STATE_BOOLEAN};
            res = xrGetActionStateBoolean(s, &gi, &st);
            out.put(st.currentState); out.put(st.changedSinceLastSync); out.put(st.lastChangeTime); out.put(st.isActive);
        } else if (op == OP_GET_STATE_FLOAT) {
            XrActionStateFloat st{XR_TYPE_ACTION_STATE_FLOAT};
            res = xrGetActionStateFloat(s, &gi, &st);
            out.put(st.currentState); out.put(st.changedSinceLastSync); out.put(st.lastChangeTime); out.put(st.isActive);
        } else if (op == OP_GET_STATE_VEC2) {
            XrActionStateVector2f st{XR_TYPE_ACTION_STATE_VECTOR2F};
            res = xrGetActionStateVector2f(s, &gi, &st);
            out.put(st.currentState); out.put(st.changedSinceLastSync); out.put(st.lastChangeTime); out.put(st.isActive);
        } else {
            XrActionStatePose st{XR_TYPE_ACTION_STATE_POSE};
            res = xrGetActionStatePose(s, &gi, &st);
            out.put(st.isActive);
        }
        break;
    }
    case OP_SYNC_ACTIONS: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrActionsSyncInfo si{XR_TYPE_ACTIONS_SYNC_INFO};
        dI_XrActionsSyncInfo(in, si, a);
        res = xrSyncActions(s, &si);
        break;
    }
    case OP_ENUM_BOUND_SOURCES: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrBoundSourcesForActionEnumerateInfo ei{XR_TYPE_BOUND_SOURCES_FOR_ACTION_ENUMERATE_INFO};
        ei.action = (XrAction)in.get<uint64_t>();
        twoCall<XrPath>(in, out, res, [&](uint32_t c, uint32_t* n, XrPath* v) {
            return xrEnumerateBoundSourcesForAction(s, &ei, c, n, v); });
        break;
    }
    case OP_GET_SOURCE_NAME: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrInputSourceLocalizedNameGetInfo gi{XR_TYPE_INPUT_SOURCE_LOCALIZED_NAME_GET_INFO};
        gi.sourcePath = in.get<XrPath>();
        gi.whichComponents = in.get<XrInputSourceLocalizedNameFlags>();
        uint32_t n = 0;
        res = xrGetInputSourceLocalizedName(s, &gi, 0, &n, nullptr);
        std::string b(n, 0);
        if (XR_SUCCEEDED(res)) res = xrGetInputSourceLocalizedName(s, &gi, n, &n, b.data());
        out.put(n);
        out.str(b.c_str());
        break;
    }
    case OP_APPLY_HAPTIC: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrHapticActionInfo hi{XR_TYPE_HAPTIC_ACTION_INFO};
        dI_XrHapticActionInfo(in, hi, a);
        auto* h = (const XrHapticBaseHeader*)dIAny(in, a);
        if (!h) return XR_ERROR_VALIDATION_FAILURE;
        res = xrApplyHapticFeedback(s, &hi, h);
        break;
    }
    case OP_STOP_HAPTIC: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrHapticActionInfo hi{XR_TYPE_HAPTIC_ACTION_INFO};
        dI_XrHapticActionInfo(in, hi, a);
        res = xrStopHapticFeedback(s, &hi);
        break;
    }
    case OP_GET_D3D11_REQUIREMENTS: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrSystemId id = in.get<uint64_t>();
        auto fn = extFn<PFN_xrGetD3D11GraphicsRequirementsKHR>(i, "xrGetD3D11GraphicsRequirementsKHR");
        if (!fn) return XR_ERROR_FUNCTION_UNSUPPORTED;
        XrGraphicsRequirementsD3D11KHR rq{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
        res = fn(i, id, &rq);
        out.put(rq.adapterLuid); out.put((int32_t)rq.minFeatureLevel);
        break;
    }
    case OP_GET_VISIBILITY_MASK: {
        XrSession s = (XrSession)in.get<uint64_t>();
        XrInstance i = (XrInstance)in.get<uint64_t>();
        auto vc = (XrViewConfigurationType)in.get<int32_t>();
        uint32_t view = in.get<uint32_t>();
        auto mt = (XrVisibilityMaskTypeKHR)in.get<int32_t>();
        uint32_t vcap = in.get<uint32_t>(), icap = in.get<uint32_t>();
        if (vcap > XRB_MAX_ARRAY || icap > XRB_MAX_ARRAY) return XR_ERROR_VALIDATION_FAILURE;
        auto fn = extFn<PFN_xrGetVisibilityMaskKHR>(i, "xrGetVisibilityMaskKHR");
        if (!fn) return XR_ERROR_FUNCTION_UNSUPPORTED;
        std::vector<XrVector2f> vs(vcap);
        std::vector<uint32_t> is(icap);
        XrVisibilityMaskKHR m{XR_TYPE_VISIBILITY_MASK_KHR};
        m.vertexCapacityInput = vcap; m.vertices = vcap ? vs.data() : nullptr;
        m.indexCapacityInput = icap; m.indices = icap ? is.data() : nullptr;
        res = fn(s, vc, view, mt, &m);
        out.put(m.vertexCountOutput); out.put(m.indexCountOutput);
        if (XR_SUCCEEDED(res) && vcap) out.raw(vs.data(), m.vertexCountOutput * sizeof(XrVector2f));
        if (XR_SUCCEEDED(res) && icap) out.raw(is.data(), m.indexCountOutput * sizeof(uint32_t));
        break;
    }
    case OP_PERF_TO_TIME: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        LARGE_INTEGER c; c.QuadPart = in.get<int64_t>();
        auto fn = extFn<PFN_xrConvertWin32PerformanceCounterToTimeKHR>(i, "xrConvertWin32PerformanceCounterToTimeKHR");
        if (!fn) return XR_ERROR_FUNCTION_UNSUPPORTED;
        XrTime t = 0;
        res = fn(i, &c, &t);
        out.put(t);
        break;
    }
    case OP_TIME_TO_PERF: {
        XrInstance i = (XrInstance)in.get<uint64_t>();
        XrTime t = in.get<XrTime>();
        auto fn = extFn<PFN_xrConvertTimeToWin32PerformanceCounterKHR>(i, "xrConvertTimeToWin32PerformanceCounterKHR");
        if (!fn) return XR_ERROR_FUNCTION_UNSUPPORTED;
        LARGE_INTEGER c{};
        res = fn(i, t, &c);
        out.put((int64_t)c.QuadPart);
        break;
    }
    case OP_LOCATE_SPACES: {
        XrSession se = (XrSession)in.get<uint64_t>();
        XrSpacesLocateInfo li{XR_TYPE_SPACES_LOCATE_INFO};
        li.baseSpace = (XrSpace)in.get<uint64_t>();
        li.time = in.get<XrTime>();
        auto spaces = in.vec<uint64_t>();
        uint8_t wantVel = in.get<uint8_t>();
        std::vector<XrSpace> sp;
        for (auto v : spaces) sp.push_back((XrSpace)v);
        li.spaceCount = (uint32_t)sp.size(); li.spaces = sp.data();
        std::vector<XrSpaceLocationData> locs(sp.size());
        std::vector<XrSpaceVelocityData> vels(sp.size());
        XrSpaceVelocities vc{XR_TYPE_SPACE_VELOCITIES};
        vc.velocityCount = (uint32_t)vels.size(); vc.velocities = vels.data();
        XrSpaceLocations lc{XR_TYPE_SPACE_LOCATIONS, wantVel ? &vc : nullptr};
        lc.locationCount = (uint32_t)locs.size(); lc.locations = locs.data();
        res = xrLocateSpaces(se, &li, &lc);
        if (XR_SUCCEEDED(res)) {
            out.raw(locs.data(), locs.size() * sizeof(XrSpaceLocationData));
            if (wantVel) out.raw(vels.data(), vels.size() * sizeof(XrSpaceVelocityData));
        }
        break;
    }
    case OP_HAS_FUNCTION: {
        // Lets the game probe extension functions honestly: many decide on a feature by
        // whether xrGetInstanceProcAddr succeeds.
        XrInstance i = (XrInstance)in.get<uint64_t>();
        std::string name = in.str();
        PFN_xrVoidFunction f = nullptr;
        res = xrGetInstanceProcAddr(i, name.c_str(), &f);
        if (XR_SUCCEEDED(res) && !f) res = XR_ERROR_FUNCTION_UNSUPPORTED;
        break;
    }
    case OP_GENERIC: {
        uint32_t fn = in.get<uint32_t>();
        if (fn >= GEN_COUNT) return XR_ERROR_FUNCTION_UNSUPPORTED;
        PFN_xrVoidFunction raw = genFunction(fn);
        if (!raw) return XR_ERROR_FUNCTION_UNSUPPORTED;
        return genDispatch(fn, in, out, a, raw);
    }
    default:
        logf("unknown op %u", op);
        return XR_ERROR_FUNCTION_UNSUPPORTED;
    }
    if (in.bad) { logf("malformed request for op %u", op); return XR_ERROR_RUNTIME_FAILURE; }
    return res;
}

static void handleRequest(const uint8_t* data, size_t size, Writer& out, Arena& arena, std::map<uint32_t, int>& failureCounts) {
    Reader in(data, size);
    uint32_t op = in.get<uint32_t>();
    out.buf.clear();
    out.put((int32_t)XR_SUCCESS);
    arena.clear();
    XrResult r = dispatch(op, in, out, arena);
    memcpy(out.buf.data(), &r, sizeof(int32_t));
    // A call failing every frame must not fill the disk.
    if (XR_FAILED(r) && r != XR_ERROR_SIZE_INSUFFICIENT && failureCounts[op]++ < 5) logf("op %u failed: %d", op, r);
}

// Serves one app thread over its shared memory block.
static void serveShared(HANDLE pipe, ShmBlock* block, HANDLE request, HANDLE reply) {
    std::map<uint32_t, int> failureCounts;
    Writer out;
    Arena arena;
    std::vector<uint8_t> big;
    for (;;) {
        LONG state = block->state;
        for (int i = 0; i < XRB_HOST_SPIN && state != SHM_REQUEST && state != SHM_REQUEST_PIPE && state != SHM_CLOSE; ++i) {
            YieldProcessor();
            state = block->state;
        }
        if (state != SHM_REQUEST && state != SHM_REQUEST_PIPE && state != SHM_CLOSE) {
            InterlockedExchange(&block->hostSleeping, 1);
            state = block->state; // a request may have arrived while going to sleep
            if (state != SHM_REQUEST && state != SHM_REQUEST_PIPE && state != SHM_CLOSE) {
                WaitForSingleObject(request, INFINITE);
                InterlockedExchange(&block->hostSleeping, 0);
                continue;
            }
            InterlockedExchange(&block->hostSleeping, 0);
        }
        if (state == SHM_CLOSE) return;
        if (state == SHM_REQUEST) {
            handleRequest(block->data, (size_t)block->size, out, arena, failureCounts);
        } else {
            if (!recvMessage(pipe, big)) return;
            handleRequest(big.data(), big.size(), out, arena, failureCounts);
        }
        LONG next = SHM_REPLY;
        if (out.buf.size() <= XRB_SHM_CAPACITY) {
            memcpy(block->data, out.buf.data(), out.buf.size());
            block->size = (LONG)out.buf.size();
        } else {
            next = SHM_REPLY_PIPE;
        }
        InterlockedExchange(&block->state, next);
        if (block->clientSleeping) SetEvent(reply);
        if (next == SHM_REPLY_PIPE && !sendMessage(pipe, out.buf)) return;
    }
}

static void serve(HANDLE pipe) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
    std::vector<uint8_t> msg;
    std::map<uint32_t, int> failureCounts;
    Writer out;
    Arena arena;
    while (recvMessage(pipe, msg)) {
        // The client's first message may offer a shared memory block by name.
        if (msg.size() > 4 && !memcmp(msg.data(), "SHM:", 4)) {
            std::string prefix((const char*)msg.data() + 4, msg.size() - 4);
            HANDLE map = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, (prefix + "_m").c_str());
            HANDLE req = OpenEventA(EVENT_ALL_ACCESS, FALSE, (prefix + "_q").c_str());
            HANDLE rep = OpenEventA(EVENT_ALL_ACCESS, FALSE, (prefix + "_p").c_str());
            auto* block = map ? (ShmBlock*)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(ShmBlock)) : nullptr;
            std::vector<uint8_t> ack{(uint8_t)(block && req && rep ? 1 : 0)};
            if (!sendMessage(pipe, ack)) break;
            if (block && req && rep) {
                serveShared(pipe, block, req, rep);
                UnmapViewOfFile(block);
                CloseHandle(map); CloseHandle(req); CloseHandle(rep);
                break;
            }
            logf("shared memory setup failed (error %lu); using the pipe", GetLastError());
            continue;
        }
        handleRequest(msg.data(), msg.size(), out, arena, failureCounts);
        if (!sendMessage(pipe, out.buf)) break;
    }
    FlushFileBuffers(pipe);
    DisconnectNamedPipe(pipe);
    CloseHandle(pipe);
    // The runtime DLL was unloaded and nothing is left to serve, so free the headset.
    if (--g_connections == 0 && g_hadInstance) {
        std::lock_guard<std::mutex> l(g_mapMutex);
        if (g_instances.empty()) { logf("no connections or instances left; host exiting"); ExitProcess(0); }
    }
}

// True when `name` is set in the user's or the system's saved environment.
static bool persistentEnv(const wchar_t* name) {
    struct Key { HKEY root; const wchar_t* path; } keys[] = {
        {HKEY_CURRENT_USER, L"Environment"},
        {HKEY_CURRENT_USER, L"Volatile Environment"},
        {HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment"},
    };
    for (auto& k : keys) {
        HKEY h;
        if (RegOpenKeyExW(k.root, k.path, 0, KEY_READ, &h) != ERROR_SUCCESS) continue;
        const bool found = RegQueryValueExW(h, name, nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS;
        RegCloseKey(h);
        if (found) return true;
    }
    return false;
}
static void dropRuntimeLayerSwitchOffs() {
    std::vector<std::wstring> drop;
    if (wchar_t* block = GetEnvironmentStringsW()) {
        for (const wchar_t* e = block; *e; e += wcslen(e) + 1) {
            if (_wcsnicmp(e, L"DISABLE_XR_APILAYER_", 20) != 0) continue;
            const wchar_t* eq = wcschr(e, L'=');
            if (!eq) continue;
            std::wstring name(e, eq);
            if (!persistentEnv(name.c_str())) drop.push_back(name);
        }
        FreeEnvironmentStringsW(block);
    }
    for (auto& n : drop) {
        SetEnvironmentVariableW(n.c_str(), nullptr);
        logf("the game switched a layer off for itself (%ls); the 64-bit layer loads here anyway", n.c_str());
    }
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR cmd, int) {
    // usage: xrbridge_host.exe <pipe-name> <game-pid>
    char pipeName[256] = {};
    unsigned long pid = 0;
    if (sscanf(cmd, "%255s %lu", pipeName, &pid) != 2) return 2;
    openLog(pid);

    // The bridge manifest must never be the runtime this process loads.
    char env[MAX_PATH * 2];
    if (GetEnvironmentVariableA("XRB_HOST_RUNTIME_JSON", env, sizeof(env))) {
        SetEnvironmentVariableA("XR_RUNTIME_JSON", env);
    } else if (GetEnvironmentVariableA("XR_RUNTIME_JSON", env, sizeof(env)) && (strstr(env, "xrbridge32") || strstr(env, "steamxr"))) {
        // Steam can set this for games it launches, which would send the host to SteamVR
        // instead of the runtime the user chose.
        logf("ignoring XR_RUNTIME_JSON=%s; using the registered runtime", env);
        SetEnvironmentVariableA("XR_RUNTIME_JSON", nullptr);
    }
    // A game or VR mod may switch OpenXR layers off in its own process through
    // their disable_environment variables (Dishonored VR and AC Unity VR do, for
    // layers they judge unloadable in a 32-bit D3D9 process). The host inherits
    // them, but here those 64-bit layers run on the host's own D3D11 device, so
    // the reason does not apply: such switches are dropped. A switch-off the user
    // set in Windows' environment settings is kept. XRB_KEEP_LAYER_SWITCH_OFF=1
    // keeps all of them.
    if (!GetEnvironmentVariableA("XRB_KEEP_LAYER_SWITCH_OFF", env, sizeof(env))) dropRuntimeLayerSwitchOffs();
    // XR_ENABLE_API_LAYERS names layers for the game, which its 32-bit loader already
    // loaded. The 64-bit loader would fail the instance if a 64-bit copy is missing, so the
    // host uses XRB_HOST_ENABLE_API_LAYERS instead.
    if (GetEnvironmentVariableA("XR_ENABLE_API_LAYERS", env, sizeof(env))) logf("XR_ENABLE_API_LAYERS is for the game; the host ignores it");
    if (GetEnvironmentVariableA("XRB_HOST_ENABLE_API_LAYERS", env, sizeof(env))) SetEnvironmentVariableA("XR_ENABLE_API_LAYERS", env);
    else SetEnvironmentVariableA("XR_ENABLE_API_LAYERS", nullptr);
    g_nullGfx = GetEnvironmentVariableA("XRB_NULL_GFX", env, sizeof(env)) > 0;
    {
        DWORD on = 0, size = sizeof(on);
        RegGetValueA(HKEY_LOCAL_MACHINE, "SOFTWARE\\XRBridge32", "ZeroCopy", RRF_RT_REG_DWORD | RRF_SUBKEY_WOW6464KEY, nullptr, &on, &size);
        g_zeroCopy = on != 0 || GetEnvironmentVariableA("XRB_ZERO_COPY", env, sizeof(env)) > 0;
    }

    // The host has no window, so Windows 11 treats it as background work: it may run it on
    // efficiency cores at low clock, which would add latency to every frame of the game.
    {
        PROCESS_POWER_THROTTLING_STATE pt{PROCESS_POWER_THROTTLING_CURRENT_VERSION};
        pt.ControlMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED | PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION;
        pt.StateMask = 0;
        SetProcessInformation(GetCurrentProcess(), ProcessPowerThrottling, &pt, sizeof(pt));
        SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);
    }
    g_game = OpenProcess(SYNCHRONIZE | PROCESS_DUP_HANDLE, FALSE, pid);
    if (!g_game) g_game = OpenProcess(SYNCHRONIZE, FALSE, pid);
    if (!g_game) { logf("cannot open game process"); return 3; }
    std::thread([] {
        WaitForSingleObject(g_game, INFINITE);
        logf("game exited; host exiting");
        // If the game crashed, end its instances so the headset is released. A hung
        // runtime must not keep this process alive, hence the short deadline.
        std::thread([] { Sleep(2000); ExitProcess(0); }).detach();
        std::set<uint64_t> live;
        {
            std::lock_guard<std::mutex> l(g_mapMutex);
            live = g_instances;
            g_instances.clear();
        }
        for (uint64_t i : live) xrDestroyInstance((XrInstance)i);
        ExitProcess(0);
    }).detach();

    for (;;) {
        // Local game only: the pipe is never reachable from another machine.
        HANDLE p = CreateNamedPipeA(pipeName, PIPE_ACCESS_DUPLEX,
                                    PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS,
                                    PIPE_UNLIMITED_INSTANCES, 1 << 20, 1 << 20, 0, nullptr);
        if (p == INVALID_HANDLE_VALUE) { logf("CreateNamedPipe failed %lu", GetLastError()); return 4; }
        if (ConnectNamedPipe(p, nullptr) || GetLastError() == ERROR_PIPE_CONNECTED) {
            ++g_connections;
            std::thread(serve, p).detach();
        } else {
            CloseHandle(p);
        }
    }
}
