// xrbridge32.dll: an OpenXR runtime for 32-bit processes.
//
// The 32-bit OpenXR loader reads HKLM\SOFTWARE\WOW6432Node\Khronos\OpenXR\1\ActiveRuntime
// and loads this DLL. Every call is forwarded to xrbridge_host.exe (64-bit), which
// runs the real runtime. Rendered frames cross the process boundary as D3D11
// shared textures guarded by keyed mutexes, so no pixels go through the pipe.
#include "gfx.h"
#include <openxr/openxr_loader_negotiation.h>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <deque>
#include <map>
#include <set>
#include <memory>
#include <mutex>
#include <string>
#include "../common/ipc.h"
#include "../common/formats.h"

static void xrbChainDropped(int type) { logf("dropped unsupported struct type %d", type); }

static HMODULE g_module;
static FILE* g_log;
static std::mutex g_logMutex;

void logf(const char* fmt, ...) {
    std::lock_guard<std::mutex> l(g_logMutex);
    if (!g_log) {
        wchar_t dir[MAX_PATH];
        if (!GetEnvironmentVariableW(L"LOCALAPPDATA", dir, MAX_PATH)) return;
        std::wstring path = std::wstring(dir) + L"\\XRBridge32";
        CreateDirectoryW(path.c_str(), nullptr);
        path += L"\\shim.log";
        g_log = _wfopen(path.c_str(), L"w");
        if (!g_log) return;
    }
    SYSTEMTIME t; GetLocalTime(&t);
    fprintf(g_log, "%02d:%02d:%02d.%03d [shim] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list a; va_start(a, fmt); vfprintf(g_log, fmt, a); va_end(a);
    fputc('\n', g_log); fflush(g_log);
}

// ---------------------------------------------------------------- transport
static std::mutex g_hostMutex;
static char g_pipeName[128];
static HANDLE g_hostProcess;
static DWORD g_tls = TLS_OUT_OF_INDEXES;
static std::mutex g_connMutex;
static std::vector<HANDLE> g_connections;
static volatile LONG g_hostStuck; // a quick call timed out: fail the rest fast instead of waiting again

// Starts the host, or a new one if the last one exited (see host: it leaves once
// every instance is gone and nothing is connected).
static bool ensureHost() {
    std::lock_guard<std::mutex> l(g_hostMutex);
    if (g_hostProcess && WaitForSingleObject(g_hostProcess, 0) == WAIT_TIMEOUT) return true;
    if (g_hostProcess) { CloseHandle(g_hostProcess); g_hostProcess = nullptr; }
    wchar_t path[MAX_PATH];
    if (!GetModuleFileNameW(g_module, path, MAX_PATH)) return false;
    std::wstring exe = path;
    size_t slash = exe.find_last_of(L'\\');
    if (slash == std::wstring::npos) return false;
    exe.resize(slash);
    slash = exe.find_last_of(L'\\');
    if (slash == std::wstring::npos) return false;
    exe.resize(slash);
    std::wstring cwd = exe + L"\\bin64";
    exe = cwd + L"\\xrbridge_host.exe";

    static LONG counter = 0;
    snprintf(g_pipeName, sizeof(g_pipeName), "\\\\.\\pipe\\xrbridge32_%lu_%lu_%ld", GetCurrentProcessId(), GetTickCount(), InterlockedIncrement(&counter));
    std::wstring cmd = L"\"" + exe + L"\" ";
    cmd.append(g_pipeName, g_pipeName + strlen(g_pipeName));
    cmd += L" " + std::to_wstring(GetCurrentProcessId());
    STARTUPINFOW si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(exe.c_str(), cmd.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, cwd.c_str(), &si, &pi)) {
        logf("could not start the 64-bit host (error %lu)", GetLastError());
        return false;
    }
    CloseHandle(pi.hThread);
    g_hostProcess = pi.hProcess;
    logf("started host pid %lu pipe %s", pi.dwProcessId, g_pipeName);
    return true;
}

static HANDLE threadPipe() {
    HANDLE h = (HANDLE)TlsGetValue(g_tls);
    if (h) return h;
    // A first start can take seconds while antivirus scans the exe. The deadline is generous so
    // a slow start is not reported to the game as a missing runtime.
    int restarts = 0;
    if (!ensureHost()) return nullptr;
    const ULONGLONG deadline = GetTickCount64() + 20000;
    while (GetTickCount64() < deadline) {
        h = CreateFileA(g_pipeName, GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr);
        if (h != INVALID_HANDLE_VALUE) {
            TlsSetValue(g_tls, h);
            std::lock_guard<std::mutex> l(g_connMutex);
            g_connections.push_back(h);
            return h;
        }
        if (GetLastError() == ERROR_PIPE_BUSY) { WaitNamedPipeA(g_pipeName, 100); continue; }
        if (WaitForSingleObject(g_hostProcess, 0) == WAIT_OBJECT_0) {
            DWORD code = 0;
            GetExitCodeProcess(g_hostProcess, &code);
            // A host can exit on its own once every thread disconnected, just as a new call
            // arrives. That one is replaced; a host that keeps dying is reported.
            if (code == 0 && restarts++ < 2 && ensureHost()) continue;
            logf("host exited early with code %lu", code);
            return nullptr;
        }
        Sleep(5);
    }
    logf("timed out connecting to the host pipe");
    return nullptr;
}
static void dropThreadPipe() {
    HANDLE h = (HANDLE)TlsGetValue(g_tls);
    if (!h) return;
    TlsSetValue(g_tls, nullptr);
    {
        std::lock_guard<std::mutex> l(g_connMutex);
        for (auto it = g_connections.begin(); it != g_connections.end(); ++it)
            if (*it == h) { g_connections.erase(it); break; }
    }
    CloseHandle(h);
}

// One per app thread. The pipe stays open for setup and oversized messages, and also makes
// the host notice a thread that vanished.
struct ThreadLink {
    HANDLE pipe = nullptr;
    ShmBlock* block = nullptr;
    HANDLE map = nullptr, request = nullptr, reply = nullptr;
    // Buffers kept between calls: this path runs hundreds of times per frame.
    Writer writers[4];
    std::vector<uint8_t> in[4];
    int depth = 0;
    // A posted call (see Rpc::post) whose result has not been collected yet. The
    // next call on this thread collects it first, so calls stay in order.
    bool posted = false;
    uint32_t postedOp = 0;
    std::vector<uint8_t> postedReply;
};
// A plain Win32 TLS slot: mingw's thread_local is emulated, which is slower here and can be
// torn down before DllMain sees the thread exit.
static DWORD g_linkTls = TLS_OUT_OF_INDEXES;
static ThreadLink& threadLink() {
    auto* t = (ThreadLink*)TlsGetValue(g_linkTls);
    if (!t) {
        t = new ThreadLink();
        TlsSetValue(g_linkTls, t);
    }
    return *t;
}

static bool attachShared(ThreadLink& t) {
    char e[8];
    if (GetEnvironmentVariableA("XRB_NO_SHM", e, sizeof(e))) return false;
    static LONG counter = 0;
    char prefix[96];
    snprintf(prefix, sizeof(prefix), "Local\\xrb_%lu_%lu_%ld", GetCurrentProcessId(), GetCurrentThreadId(), InterlockedIncrement(&counter));
    std::string p = prefix;
    t.map = CreateFileMappingA(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(ShmBlock), (p + "_m").c_str());
    t.request = CreateEventA(nullptr, FALSE, FALSE, (p + "_q").c_str());
    t.reply = CreateEventA(nullptr, FALSE, FALSE, (p + "_p").c_str());
    t.block = t.map ? (ShmBlock*)MapViewOfFile(t.map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(ShmBlock)) : nullptr;
    if (t.block && t.request && t.reply) {
        std::string hello = "SHM:" + p;
        std::vector<uint8_t> m(hello.begin(), hello.end()), ack;
        if (sendMessage(t.pipe, m) && recvMessage(t.pipe, ack) && ack.size() == 1 && ack[0]) return true;
    }
    if (t.block) UnmapViewOfFile(t.block);
    if (t.map) CloseHandle(t.map);
    if (t.request) CloseHandle(t.request);
    if (t.reply) CloseHandle(t.reply);
    t.block = nullptr; t.map = t.request = t.reply = nullptr;
    logf("shared memory unavailable; using the pipe");
    return false;
}
static void detachThread() {
    if (g_linkTls == TLS_OUT_OF_INDEXES) return;
    auto* t = (ThreadLink*)TlsGetValue(g_linkTls);
    if (!t) return;
    if (t->block) {
        InterlockedExchange(&t->block->state, SHM_CLOSE);
        SetEvent(t->request);
        UnmapViewOfFile(t->block);
        CloseHandle(t->map); CloseHandle(t->request); CloseHandle(t->reply);
    }
    dropThreadPipe();
    TlsSetValue(g_linkTls, nullptr);
    delete t;
}
// Calls that can block for a good part of a frame: spinning on these wastes a core.
static bool mayBlock(uint32_t op) {
    return op == OP_WAIT_FRAME || op == OP_WAIT_IMAGE || op == OP_END_FRAME || op == OP_CREATE_SESSION || op == OP_CREATE_SWAPCHAIN ||
           op == OP_CREATE_INSTANCE || op == OP_DESTROY_INSTANCE || op == OP_DESTROY_SESSION || op == OP_BEGIN_SESSION || op == OP_END_SESSION;
}

// Hands a request to the host through the shared block. False if the host is gone.
static bool sendRequest(ThreadLink& t, const std::vector<uint8_t>& req) {
    ShmBlock* b = t.block;
    const bool small = req.size() <= XRB_SHM_CAPACITY;
    if (small) {
        memcpy(b->data, req.data(), req.size());
        b->size = (LONG)req.size();
    }
    InterlockedExchange(&b->state, small ? SHM_REQUEST : SHM_REQUEST_PIPE);
    if (b->hostSleeping) SetEvent(t.request);
    return small || sendMessage(t.pipe, req);
}

// Waits for the host's answer to the request in the shared block.
static bool waitReply(ThreadLink& t, uint32_t op, std::vector<uint8_t>& resp) {
    ShmBlock* b = t.block;
    LONG state = b->state;
    const bool slow = mayBlock(op);
    if (!slow)
        for (int i = 0; i < XRB_CLIENT_SPIN && state != SHM_REPLY && state != SHM_REPLY_PIPE; ++i) {
            YieldProcessor();
            state = b->state;
        }
    while (state != SHM_REPLY && state != SHM_REPLY_PIPE) {
        InterlockedExchange(&b->clientSleeping, 1);
        state = b->state;
        if (state == SHM_REPLY || state == SHM_REPLY_PIPE) { InterlockedExchange(&b->clientSleeping, 0); break; }
        // A dead host must not hang the game.
        // Frame calls may legitimately wait as long as the runtime likes. Anything else that
        // takes this long means a stuck runtime, and the game gets an error instead of a hang.
        HANDLE waits[2] = {t.reply, g_hostProcess};
        DWORD w = WaitForMultipleObjects(2, waits, FALSE, slow ? INFINITE : 20000);
        if (w == WAIT_TIMEOUT) {
            state = b->state;
            if (state == SHM_REPLY || state == SHM_REPLY_PIPE) break;
            logf("the 64-bit runtime did not answer op %u within 20 s; treating it as stuck", op);
            InterlockedExchange(&g_hostStuck, 1);
            return false;
        }
        InterlockedExchange(&b->clientSleeping, 0);
        state = b->state;
        if (w != WAIT_OBJECT_0 && state != SHM_REPLY && state != SHM_REPLY_PIPE) return false;
    }
    if (state == SHM_REPLY) {
        resp.resize((size_t)b->size);
        memcpy(resp.data(), b->data, resp.size());
    } else if (!recvMessage(t.pipe, resp)) {
        return false;
    }
    InterlockedExchange(&b->state, SHM_IDLE);
    return true;
}

// Collects the result of this thread's posted call, if there is one.
static bool collectPosted(ThreadLink& t) {
    if (!t.posted) return true;
    t.posted = false;
    if (!waitReply(t, t.postedOp, t.postedReply)) return false;
    if (t.postedReply.size() >= 4) {
        const XrResult r = (XrResult)*(const int32_t*)t.postedReply.data();
        if (XR_FAILED(r)) logf("op %u, run without waiting, failed in the host: %d", t.postedOp, (int)r);
    }
    return true;
}

static bool roundTrip(ThreadLink& t, const std::vector<uint8_t>& req, std::vector<uint8_t>& resp) {
    if (!t.block) return sendMessage(t.pipe, req) && recvMessage(t.pipe, resp);
    if (!collectPosted(t)) return false;
    return sendRequest(t, req) && waitReply(t, *(const uint32_t*)req.data(), resp);
}

struct Rpc {
    ThreadLink& t;
    int slot;
    Writer& w;
    Reader r;
    bool retried = false;
    explicit Rpc(Op op) : t(threadLink()), slot(t.depth < 3 ? t.depth : 3), w(t.writers[slot]) {
        ++t.depth;
        w.buf.clear();
        w.put((uint32_t)op);
    }
    ~Rpc() { --t.depth; }
    Rpc(const Rpc&) = delete;
    XrResult call() {
        if (g_hostStuck) return XR_ERROR_RUNTIME_FAILURE;
        if (!t.pipe) {
            t.pipe = threadPipe();
            if (!t.pipe) return XR_ERROR_RUNTIME_UNAVAILABLE;
            attachShared(t);
        }
        std::vector<uint8_t>& resp = t.in[slot];
        if (!roundTrip(t, w.buf, resp)) {
            logf("host connection lost (op %u)", *(uint32_t*)w.buf.data());
            // The link stays allocated because this Rpc still refers to it, but it is reset
            // so the next call on this thread starts a new connection.
            if (t.block) {
                UnmapViewOfFile(t.block);
                CloseHandle(t.map); CloseHandle(t.request); CloseHandle(t.reply);
                t.block = nullptr; t.map = t.request = t.reply = nullptr;
            }
            dropThreadPipe();
            t.pipe = nullptr;
            // Listing extensions holds no state, so it can safely go to a fresh host.
            const uint32_t op = *(uint32_t*)w.buf.data();
            if (op == OP_ENUM_EXTENSIONS && !retried && g_hostProcess && WaitForSingleObject(g_hostProcess, 0) == WAIT_OBJECT_0) {
                retried = true;
                return call();
            }
            return XR_ERROR_INSTANCE_LOST;
        }
        r = Reader(resp.data(), resp.size());
        return (XrResult)r.get<int32_t>();
    }
    // Sends the call without waiting for the host: for calls whose only result is success,
    // already checked here. The host runs it while the game carries on; the next call on
    // this thread collects the result before it is sent. Falls back to call() whenever the
    // shared block is not in use.
    XrResult post() {
        if (g_hostStuck) return XR_ERROR_RUNTIME_FAILURE;
        if (!t.pipe || !t.block || w.buf.size() > XRB_SHM_CAPACITY) return call();
        if (!collectPosted(t) || !sendRequest(t, w.buf)) return call(); // call() reports the lost connection
        t.posted = true;
        t.postedOp = *(const uint32_t*)w.buf.data();
        return XR_SUCCESS;
    }
};
template <class H> static uint64_t U(H h) { return (uint64_t)h; }

// The OpenXR two-call idiom over RPC, for arrays of pointer-free elements.
template <class T>
static XrResult twoCallFinish(Rpc& c, uint32_t cap, uint32_t* countOut, T* out) {
    c.w.put(cap);
    XrResult res = c.call();
    if (XR_FAILED(res) && res != XR_ERROR_SIZE_INSUFFICIENT) return res;
    uint32_t n = c.r.get<uint32_t>();
    if (countOut) *countOut = n;
    if (XR_SUCCEEDED(res) && cap) {
        auto v = c.r.vec<T>();
        if (v.size() > cap) return XR_ERROR_RUNTIME_FAILURE;
        memcpy(out, v.data(), v.size() * sizeof(T));
    }
    return res;
}

#define XRB_GEN_SHIM
#include "../common/gen_marshal.inc"

// ---------------------------------------------------------------- local state
struct ShimSession {
    uint64_t instance = 0;
    std::unique_ptr<GfxSession> gfx;
    volatile DWORD endFrameThread = 0; // the thread that ends this session's frames
};
struct ShimSwapchain {
    uint64_t session = 0;
    uint32_t imageCount = 0;
    std::shared_ptr<ShimSession> owner;
    std::unique_ptr<GfxImages> images;
    std::deque<uint32_t> acquired;
    std::deque<uint32_t> waited;
    DWORD acquireThread = 0;
};
static std::mutex g_mutex;
static std::map<uint64_t, std::shared_ptr<ShimSession>> g_sessions;
static std::map<uint64_t, std::shared_ptr<ShimSwapchain>> g_swapchains;
static std::map<uint64_t, LUID> g_systemLuid; // by instance, from the graphics requirements call
static std::map<uint64_t, std::set<std::string>> g_instanceExtensions; // enabled at xrCreateInstance
static std::map<std::pair<uint64_t, std::string>, XrPath> g_pathCache; // paths never change within an instance
static bool nullGfx() {
    char b[8];
    return GetEnvironmentVariableA("XRB_NULL_GFX", b, sizeof(b)) > 0;
}
static std::shared_ptr<ShimSwapchain> findSwapchain(XrSwapchain s) {
    std::lock_guard<std::mutex> l(g_mutex);
    auto it = g_swapchains.find(U(s));
    return it == g_swapchains.end() ? nullptr : it->second;
}
static std::shared_ptr<ShimSession> findSession(XrSession s) {
    std::lock_guard<std::mutex> l(g_mutex);
    auto it = g_sessions.find(U(s));
    return it == g_sessions.end() ? nullptr : it->second;
}
static uint64_t instanceOfSession(XrSession s) {
    auto se = findSession(s);
    return se ? se->instance : 0;
}
// Vulkan is offered only where its loader exists. A hard dependency would stop the
// shim loading in a game that has nothing to do with Vulkan.
static bool vulkanAvailable() { return vkLoaderProc() != nullptr; }

// ---------------------------------------------------------------- global functions
static XrResult XRAPI_CALL sh_xrEnumerateApiLayerProperties(uint32_t, uint32_t* n, XrApiLayerProperties*) {
    if (!n) return XR_ERROR_VALIDATION_FAILURE;
    *n = 0;
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrEnumerateInstanceExtensionProperties(const char* layer, uint32_t cap, uint32_t* n, XrExtensionProperties* out) {
    if (layer && *layer) return XR_ERROR_API_LAYER_NOT_PRESENT;
    if (!n) return XR_ERROR_VALIDATION_FAILURE;
    // The loader, layers and the game each ask, often several times. The list cannot change
    // while the game runs, so only the first successful answer costs a call to the host.
    static std::mutex cacheMutex;
    static bool cached = false, hasD3D11 = false;
    static std::vector<std::pair<std::string, uint32_t>> fromHost;
    {
        std::lock_guard<std::mutex> l(cacheMutex);
        if (!cached) {
            Rpc c(OP_ENUM_EXTENSIONS);
            XrResult res = c.call();
            // The loader ignores this failure and reports an empty list, so games then blame a
            // missing extension. The log is the only place the real reason can appear.
            if (XR_FAILED(res)) {
                static bool logged;
                if (!logged) { logged = true; logf("could not get extensions from the 64-bit host: %d", (int)res); }
                return res;
            }
            hasD3D11 = c.r.get<uint8_t>() != 0;
            uint32_t count = c.r.get<uint32_t>();
            for (uint32_t i = 0; i < count && !c.r.bad; ++i) {
                std::string name = c.r.str();
                uint32_t ver = c.r.get<uint32_t>();
                fromHost.push_back({name, ver});
            }
            if (c.r.bad) { fromHost.clear(); return XR_ERROR_RUNTIME_FAILURE; }
            cached = true;
        }
    }
    std::vector<std::pair<std::string, uint32_t>> list = fromHost;
    // All game APIs are implemented here on top of the host's D3D11 session, so they
    // are available exactly when the real runtime offers D3D11.
    if (hasD3D11) {
        list.push_back({"XR_KHR_D3D12_enable", XR_KHR_D3D12_enable_SPEC_VERSION});
        list.push_back({"XR_KHR_opengl_enable", XR_KHR_opengl_enable_SPEC_VERSION});
        if (vulkanAvailable()) {
            list.push_back({"XR_KHR_vulkan_enable", XR_KHR_vulkan_enable_SPEC_VERSION});
            list.push_back({"XR_KHR_vulkan_enable2", XR_KHR_vulkan_enable2_SPEC_VERSION});
        } else {
            static bool logged;
            if (!logged) { logged = true; logf("could not load the 32-bit vulkan-1.dll, so Vulkan is not offered (error %lu)", GetLastError()); }
        }
    } else {
        static bool logged;
        if (!logged) { logged = true; logf("could not offer any graphics API: the 64-bit runtime has no XR_KHR_D3D11_enable"); }
    }
    *n = (uint32_t)list.size();
    if (cap == 0) return XR_SUCCESS;
    if (cap < list.size()) return XR_ERROR_SIZE_INSUFFICIENT;
    for (size_t i = 0; i < list.size(); ++i) {
        out[i].type = XR_TYPE_EXTENSION_PROPERTIES;
        strncpy(out[i].extensionName, list[i].first.c_str(), XR_MAX_EXTENSION_NAME_SIZE - 1);
        out[i].extensionName[XR_MAX_EXTENSION_NAME_SIZE - 1] = 0;
        out[i].extensionVersion = list[i].second;
    }
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrCreateInstance(const XrInstanceCreateInfo* ci, XrInstance* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    XrVersion v = ci->applicationInfo.apiVersion;
    if (XR_VERSION_MAJOR(v) != 1 || XR_VERSION_MINOR(v) > 1) {
        logf("app requested API %u.%u; the bridge exposes up to 1.1", (unsigned)XR_VERSION_MAJOR(v), (unsigned)XR_VERSION_MINOR(v));
        return XR_ERROR_API_VERSION_UNSUPPORTED;
    }
    Rpc c(OP_CREATE_INSTANCE);
    c.w.put(ci->createFlags);
    c.w.put(ci->applicationInfo);
    // Layers the game asked for are already running in the game, above this runtime. Passing
    // their names on would make the 64-bit loader demand 64-bit copies of them, and fail the
    // game's instance when there are none. The host still gets its own 64-bit layers.
    c.w.put((uint32_t)0);
    if (ci->enabledApiLayerCount) logf("%u API layer(s) requested by the game run on the 32-bit side only", ci->enabledApiLayerCount);
    // The loader implements XR_EXT_debug_utils, and the shim implements the graphics
    // extensions, so none of those reach the real runtime.
    std::vector<const char*> ex;
    for (uint32_t i = 0; i < ci->enabledExtensionCount; ++i) {
        const char* e = ci->enabledExtensionNames[i];
        if (strcmp(e, "XR_EXT_debug_utils") && strcmp(e, "XR_KHR_D3D12_enable") && strcmp(e, "XR_KHR_opengl_enable") &&
            strcmp(e, "XR_KHR_vulkan_enable") && strcmp(e, "XR_KHR_vulkan_enable2"))
            ex.push_back(e);
    }
    c.w.put((uint32_t)ex.size());
    for (auto* s : ex) c.w.str(s);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) {
        *out = (XrInstance)c.r.get<uint64_t>();
        std::set<std::string> on;
        for (uint32_t i = 0; i < ci->enabledExtensionCount; ++i) on.insert(ci->enabledExtensionNames[i]);
        std::lock_guard<std::mutex> l(g_mutex);
        g_instanceExtensions[U(*out)] = std::move(on);
    }
    logf("xrCreateInstance -> %d", res);
    return res;
}

// ---------------------------------------------------------------- simple forwards
#define FWD_H(name, op, H) static XrResult XRAPI_CALL sh_##name(H h) { Rpc c(op); c.w.put(U(h)); return c.call(); }
FWD_H(xrDestroySpace, OP_DESTROY_SPACE, XrSpace)
FWD_H(xrEndSession, OP_END_SESSION, XrSession)
FWD_H(xrRequestExitSession, OP_REQUEST_EXIT, XrSession)
FWD_H(xrDestroyActionSet, OP_DESTROY_ACTION_SET, XrActionSet)
FWD_H(xrDestroyAction, OP_DESTROY_ACTION, XrAction)

static XrResult XRAPI_CALL sh_xrDestroyInstance(XrInstance i) {
    // Same order as xrDestroySession: imports first, then the host's objects.
    std::vector<std::shared_ptr<ShimSwapchain>> chains;
    std::vector<std::shared_ptr<ShimSession>> sessions;
    {
        std::lock_guard<std::mutex> l(g_mutex);
        g_systemLuid.erase(U(i));
        g_instanceExtensions.erase(U(i));
        for (auto it = g_pathCache.begin(); it != g_pathCache.end();) it = it->first.first == U(i) ? g_pathCache.erase(it) : std::next(it);
        for (auto se = g_sessions.begin(); se != g_sessions.end();) {
            if (se->second->instance == U(i)) {
                for (auto it = g_swapchains.begin(); it != g_swapchains.end();) {
                    if (it->second->session == se->first) { chains.push_back(it->second); it = g_swapchains.erase(it); } else ++it;
                }
                sessions.push_back(se->second);
                se = g_sessions.erase(se);
            } else ++se;
        }
    }
    chains.clear();
    sessions.clear();
    Rpc c(OP_DESTROY_INSTANCE); c.w.put(U(i));
    return c.call();
}
static XrResult XRAPI_CALL sh_xrGetInstanceProperties(XrInstance i, XrInstanceProperties* p) {
    if (!p) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_INSTANCE_PROPERTIES); c.w.put(U(i));
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    p->runtimeVersion = c.r.get<XrVersion>();
    std::string real = c.r.str();
    snprintf(p->runtimeName, XR_MAX_RUNTIME_NAME_SIZE, "XRBridge32 -> %s", real.c_str());
    return res;
}
static XrResult XRAPI_CALL sh_xrPollEvent(XrInstance i, XrEventDataBuffer* out) {
    if (!out) return XR_ERROR_VALIDATION_FAILURE;
    for (;;) {
        Rpc c(OP_POLL_EVENT); c.w.put(U(i));
        XrResult res = c.call();
        if (res != XR_SUCCESS) return res;
        auto type = (XrStructureType)c.r.get<uint32_t>();
        // Event structs embed `next`, so their offsets differ between 32 and 64 bits.
        // The generated code covers every event type in the registry.
        if (!c.r.get<uint8_t>()) {
            logf("dropped event type %d", (int)type);
            continue;
        }
        memset(out, 0, sizeof(XrEventDataBuffer));
        out->type = type;
        dOAny(c.r, out);
        return c.r.bad ? XR_ERROR_RUNTIME_FAILURE : res;
    }
}
static XrResult XRAPI_CALL sh_xrResultToString(XrInstance i, XrResult v, char buf[XR_MAX_RESULT_STRING_SIZE]) {
    Rpc c(OP_RESULT_TO_STRING); c.w.put(U(i)); c.w.put((int32_t)v);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) { std::string s = c.r.str(); strncpy(buf, s.c_str(), XR_MAX_RESULT_STRING_SIZE - 1); buf[XR_MAX_RESULT_STRING_SIZE - 1] = 0; }
    return res;
}
static XrResult XRAPI_CALL sh_xrStructureTypeToString(XrInstance i, XrStructureType v, char buf[XR_MAX_STRUCTURE_NAME_SIZE]) {
    Rpc c(OP_STRUCT_TO_STRING); c.w.put(U(i)); c.w.put((int32_t)v);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) { std::string s = c.r.str(); strncpy(buf, s.c_str(), XR_MAX_STRUCTURE_NAME_SIZE - 1); buf[XR_MAX_STRUCTURE_NAME_SIZE - 1] = 0; }
    return res;
}
static XrResult XRAPI_CALL sh_xrGetSystem(XrInstance i, const XrSystemGetInfo* gi, XrSystemId* id) {
    if (!gi || !id) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_SYSTEM); c.w.put(U(i)); c.w.put((int32_t)gi->formFactor);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *id = c.r.get<uint64_t>();
    return res;
}
static XrResult XRAPI_CALL sh_xrGetSystemProperties(XrInstance i, XrSystemId id, XrSystemProperties* p) {
    if (!p) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_SYSTEM_PROPERTIES); c.w.put(U(i)); c.w.put(id);
    chainIn(c.w, p->next);
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    p->systemId = id;
    p->vendorId = c.r.get<uint32_t>();
    std::string name = c.r.str();
    strncpy(p->systemName, name.c_str(), XR_MAX_SYSTEM_NAME_SIZE - 1);
    p->systemName[XR_MAX_SYSTEM_NAME_SIZE - 1] = 0;
    p->graphicsProperties = c.r.get<XrSystemGraphicsProperties>();
    p->trackingProperties = c.r.get<XrSystemTrackingProperties>();
    dChainOut(c.r, p->next);
    return res;
}
static XrResult XRAPI_CALL sh_xrEnumerateEnvironmentBlendModes(XrInstance i, XrSystemId id, XrViewConfigurationType vc, uint32_t cap, uint32_t* n, XrEnvironmentBlendMode* out) {
    Rpc c(OP_ENUM_BLEND_MODES); c.w.put(U(i)); c.w.put(id); c.w.put((int32_t)vc);
    return twoCallFinish(c, cap, n, out);
}

// ---------------------------------------------------------------- session
// Host adapter LUID, also what every graphics requirements call reports.
static XrResult hostRequirements(XrInstance i, XrSystemId id, LUID* luid, D3D_FEATURE_LEVEL* level) {
    Rpc c(OP_GET_D3D11_REQUIREMENTS); c.w.put(U(i)); c.w.put(id);
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    LUID got = c.r.get<LUID>();
    auto fl = (D3D_FEATURE_LEVEL)c.r.get<int32_t>();
    if (luid) *luid = got;
    if (level) *level = fl;
    std::lock_guard<std::mutex> l(g_mutex);
    g_systemLuid[U(i)] = got;
    return res;
}

static XrResult XRAPI_CALL sh_xrCreateSession(XrInstance i, const XrSessionCreateInfo* ci, XrSession* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    std::unique_ptr<GfxSession> gfx;
    for (auto* b = (const XrBaseInStructure*)ci->next; b && !gfx; b = b->next) {
        const bool known = b->type == XR_TYPE_GRAPHICS_BINDING_D3D11_KHR || b->type == XR_TYPE_GRAPHICS_BINDING_D3D12_KHR ||
                           b->type == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR || b->type == XR_TYPE_GRAPHICS_BINDING_OPENGL_WIN32_KHR;
        if (!known) continue;
        if (nullGfx()) gfx.reset(makeNullSession(b->type));
        else if (b->type == XR_TYPE_GRAPHICS_BINDING_D3D11_KHR) gfx.reset(makeD3D11Session(*(const XrGraphicsBindingD3D11KHR*)b));
        else if (b->type == XR_TYPE_GRAPHICS_BINDING_D3D12_KHR) gfx.reset(makeD3D12Session(*(const XrGraphicsBindingD3D12KHR*)b));
        else if (b->type == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR) gfx.reset(makeVulkanSession(*(const XrGraphicsBindingVulkanKHR*)b));
        else gfx.reset(makeOpenGLSession(*(const XrGraphicsBindingOpenGLWin32KHR*)b));
    }
    if (!gfx) {
        logf("xrCreateSession: no supported graphics binding in the chain");
        return XR_ERROR_GRAPHICS_DEVICE_INVALID;
    }
    LUID luid{};
    XrResult res = hostRequirements(i, ci->systemId, &luid, nullptr);
    if (XR_FAILED(res)) return res;

    Rpc c(OP_CREATE_SESSION); c.w.put(U(i)); c.w.put(ci->createFlags); c.w.put(ci->systemId); c.w.str(gfx->name());
    res = c.call();
    logf("xrCreateSession (%s) -> %d", gfx->name(), res);
    if (XR_FAILED(res)) return res;
    uint64_t session = c.r.get<uint64_t>();
    HANDLE fence = (HANDLE)(uintptr_t)c.r.get<uint64_t>();
    res = gfx->init(fence, luid);
    if (XR_FAILED(res)) {
        logf("%s session setup failed: %d", gfx->name(), res);
        Rpc d(OP_DESTROY_SESSION); d.w.put(session); d.call();
        return res;
    }
    auto s = std::make_shared<ShimSession>();
    s->instance = U(i);
    s->gfx = std::move(gfx);
    *out = (XrSession)session;
    std::lock_guard<std::mutex> l(g_mutex);
    g_sessions[session] = s;
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrDestroySession(XrSession s) {
    // Game-side imports are released first: the host owns the textures behind them.
    std::vector<std::shared_ptr<ShimSwapchain>> chains;
    std::shared_ptr<ShimSession> session;
    {
        std::lock_guard<std::mutex> l(g_mutex);
        for (auto it = g_swapchains.begin(); it != g_swapchains.end();) {
            if (it->second->session == U(s)) { chains.push_back(it->second); it = g_swapchains.erase(it); } else ++it;
        }
        auto it = g_sessions.find(U(s));
        if (it != g_sessions.end()) { session = it->second; g_sessions.erase(it); }
    }
    chains.clear();
    session.reset();
    Rpc c(OP_DESTROY_SESSION); c.w.put(U(s));
    return c.call();
}
static XrResult XRAPI_CALL sh_xrBeginSession(XrSession s, const XrSessionBeginInfo* bi) {
    if (!bi) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_BEGIN_SESSION); c.w.put(U(s));
    sI_XrSessionBeginInfo(c.w, *bi);
    return c.call();
}

// ---------------------------------------------------------------- spaces
static XrResult XRAPI_CALL sh_xrEnumerateReferenceSpaces(XrSession s, uint32_t cap, uint32_t* n, XrReferenceSpaceType* out) {
    Rpc c(OP_ENUM_REF_SPACES); c.w.put(U(s));
    return twoCallFinish(c, cap, n, out);
}
static XrResult XRAPI_CALL sh_xrCreateReferenceSpace(XrSession s, const XrReferenceSpaceCreateInfo* ci, XrSpace* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_CREATE_REF_SPACE); c.w.put(U(s));
    sI_XrReferenceSpaceCreateInfo(c.w, *ci);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *out = (XrSpace)c.r.get<uint64_t>();
    return res;
}
static XrResult XRAPI_CALL sh_xrGetReferenceSpaceBoundsRect(XrSession s, XrReferenceSpaceType t, XrExtent2Df* out) {
    if (!out) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_BOUNDS); c.w.put(U(s)); c.w.put((int32_t)t);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *out = c.r.get<XrExtent2Df>();
    return res;
}
static XrResult XRAPI_CALL sh_xrCreateActionSpace(XrSession s, const XrActionSpaceCreateInfo* ci, XrSpace* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_CREATE_ACTION_SPACE); c.w.put(U(s));
    sI_XrActionSpaceCreateInfo(c.w, *ci);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *out = (XrSpace)c.r.get<uint64_t>();
    return res;
}
static XrResult XRAPI_CALL sh_xrLocateSpace(XrSpace sp, XrSpace base, XrTime t, XrSpaceLocation* loc) {
    if (!loc) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_LOCATE_SPACE); c.w.put(U(sp)); c.w.put(U(base)); c.w.put(t);
    chainIn(c.w, loc->next);
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    loc->locationFlags = c.r.get<XrSpaceLocationFlags>();
    loc->pose = c.r.get<XrPosef>();
    dChainOut(c.r, loc->next);
    return res;
}

static XrResult XRAPI_CALL sh_xrLocateSpaces(XrSession s, const XrSpacesLocateInfo* li, XrSpaceLocations* out) {
    if (!li || !out || li->spaceCount != out->locationCount) return XR_ERROR_VALIDATION_FAILURE;
    XrSpaceVelocities* vel = nullptr;
    for (auto* b = (XrBaseOutStructure*)out->next; b; b = b->next)
        if (b->type == XR_TYPE_SPACE_VELOCITIES) vel = (XrSpaceVelocities*)b;
    if (vel && vel->velocityCount != li->spaceCount) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_LOCATE_SPACES); c.w.put(U(s)); c.w.put(U(li->baseSpace)); c.w.put(li->time); c.w.put(li->spaceCount);
    for (uint32_t i = 0; i < li->spaceCount; ++i) c.w.put(U(li->spaces[i]));
    c.w.put((uint8_t)(vel ? 1 : 0));
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    c.r.raw(out->locations, li->spaceCount * sizeof(XrSpaceLocationData));
    if (vel) c.r.raw(vel->velocities, li->spaceCount * sizeof(XrSpaceVelocityData));
    return res;
}

// ---------------------------------------------------------------- views
static XrResult XRAPI_CALL sh_xrEnumerateViewConfigurations(XrInstance i, XrSystemId id, uint32_t cap, uint32_t* n, XrViewConfigurationType* out) {
    Rpc c(OP_ENUM_VIEW_CONFIGS); c.w.put(U(i)); c.w.put(id);
    return twoCallFinish(c, cap, n, out);
}
static XrResult XRAPI_CALL sh_xrGetViewConfigurationProperties(XrInstance i, XrSystemId id, XrViewConfigurationType vc, XrViewConfigurationProperties* p) {
    if (!p) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_VIEW_CONFIG_PROPS); c.w.put(U(i)); c.w.put(id); c.w.put((int32_t)vc);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) { p->viewConfigurationType = (XrViewConfigurationType)c.r.get<int32_t>(); p->fovMutable = c.r.get<XrBool32>(); }
    return res;
}
static XrResult XRAPI_CALL sh_xrEnumerateViewConfigurationViews(XrInstance i, XrSystemId id, XrViewConfigurationType vc, uint32_t cap, uint32_t* n, XrViewConfigurationView* out) {
    Rpc c(OP_ENUM_VIEW_CONFIG_VIEWS); c.w.put(U(i)); c.w.put(id); c.w.put((int32_t)vc); c.w.put(cap);
    for (uint32_t k = 0; k < cap; ++k) chainIn(c.w, out[k].next);
    XrResult res = c.call();
    if (XR_FAILED(res) && res != XR_ERROR_SIZE_INSUFFICIENT) return res;
    uint32_t count = c.r.get<uint32_t>();
    if (n) *n = count;
    if (XR_SUCCEEDED(res) && cap) for (uint32_t k = 0; k < count && k < cap; ++k) {
        uint32_t f[6]; c.r.raw(f, sizeof(f));
        out[k].recommendedImageRectWidth = f[0]; out[k].maxImageRectWidth = f[1];
        out[k].recommendedImageRectHeight = f[2]; out[k].maxImageRectHeight = f[3];
        out[k].recommendedSwapchainSampleCount = f[4]; out[k].maxSwapchainSampleCount = f[5];
        dChainOut(c.r, out[k].next);
    }
    return res;
}
static XrResult XRAPI_CALL sh_xrLocateViews(XrSession s, const XrViewLocateInfo* li, XrViewState* st, uint32_t cap, uint32_t* n, XrView* out) {
    if (!li || !st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_LOCATE_VIEWS); c.w.put(U(s));
    sI_XrViewLocateInfo(c.w, *li);
    chainIn(c.w, st->next);
    c.w.put(cap);
    for (uint32_t k = 0; k < cap; ++k) chainIn(c.w, out[k].next);
    XrResult res = c.call();
    if (XR_FAILED(res) && res != XR_ERROR_SIZE_INSUFFICIENT) return res;
    st->viewStateFlags = c.r.get<XrViewStateFlags>();
    dChainOut(c.r, st->next);
    uint32_t count = c.r.get<uint32_t>();
    if (n) *n = count;
    if (XR_SUCCEEDED(res) && cap) for (uint32_t k = 0; k < count && k < cap; ++k) {
        out[k].pose = c.r.get<XrPosef>();
        out[k].fov = c.r.get<XrFovf>();
        dChainOut(c.r, out[k].next);
    }
    return res;
}

// ---------------------------------------------------------------- swapchains
static XrResult XRAPI_CALL sh_xrEnumerateSwapchainFormats(XrSession s, uint32_t cap, uint32_t* n, int64_t* out) {
    if (!n) return XR_ERROR_VALIDATION_FAILURE;
    auto se = findSession(s);
    if (!se) return XR_ERROR_HANDLE_INVALID;
    Rpc c(OP_ENUM_SWAPCHAIN_FORMATS); c.w.put(U(s));
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    auto v = c.r.vec<int64_t>();
    std::vector<int64_t> mine;
    for (int64_t f : v) {
        int64_t app = se->gfx->appFormat((int)f);
        if (app > 0) mine.push_back(app);
    }
    *n = (uint32_t)mine.size();
    if (cap == 0) return res;
    if (cap < mine.size()) return XR_ERROR_SIZE_INSUFFICIENT;
    memcpy(out, mine.data(), mine.size() * sizeof(int64_t));
    return res;
}
static void destroyHostSwapchain(uint64_t h) {
    Rpc c(OP_DESTROY_SWAPCHAIN); c.w.put(h); c.call();
}
static XrResult XRAPI_CALL sh_xrCreateSwapchain(XrSession s, const XrSwapchainCreateInfo* ci, XrSwapchain* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    auto se = findSession(s);
    if (!se) return XR_ERROR_HANDLE_INVALID;
    int dxgi = se->gfx->dxgiFormat(ci->format);
    if (dxgi < 0) {
        logf("xrCreateSwapchain: format %lld is not usable with %s across the bridge", (long long)ci->format, se->gfx->name());
        return XR_ERROR_SWAPCHAIN_FORMAT_UNSUPPORTED;
    }
    Rpc c(OP_CREATE_SWAPCHAIN); c.w.put(U(s));
    chainIn(c.w, ci->next);
    c.w.put(ci->createFlags); c.w.put(ci->usageFlags); c.w.put((int64_t)dxgi);
    uint32_t f[6] = {ci->sampleCount, ci->width, ci->height, ci->faceCount, ci->arraySize, ci->mipCount};
    c.w.raw(f, sizeof(f));
    c.w.put((uint8_t)(se->gfx->bottomUp() ? 1 : 0));
    c.w.put((uint8_t)(se->gfx->prefersNtHandles() ? 1 : 0));
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    uint64_t handle = c.r.get<uint64_t>();
    const bool nt = c.r.get<uint8_t>() != 0;
    uint32_t count = c.r.get<uint32_t>();
    if (c.r.bad || count > 64) { destroyHostSwapchain(handle); return XR_ERROR_RUNTIME_FAILURE; }
    std::vector<uint64_t> handles(count);
    c.r.raw(handles.data(), count * sizeof(uint64_t));

    SwapchainInfo info{ci->width, ci->height, ci->arraySize, ci->faceCount, ci->mipCount, ci->sampleCount, ci->usageFlags, ci->format, dxgi, nt};
    GfxImages* images = nullptr;
    res = se->gfx->open(info, handles, &images);
    // No API takes ownership of an NT handle on import, so they are closed here either way.
    if (nt) for (uint64_t h : handles) if (h) CloseHandle((HANDLE)(uintptr_t)h);
    if (XR_FAILED(res)) {
        logf("%s could not open the shared images: %d", se->gfx->name(), res);
        destroyHostSwapchain(handle);
        return res;
    }
    auto sc = std::make_shared<ShimSwapchain>();
    sc->session = U(s);
    sc->owner = se;
    sc->imageCount = count;
    sc->images.reset(images);
    {
        std::lock_guard<std::mutex> l(g_mutex);
        g_swapchains[handle] = sc;
    }
    *out = (XrSwapchain)handle;
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrDestroySwapchain(XrSwapchain s) {
    // Game-side objects go first: the host's textures must outlive any imports of them.
    std::shared_ptr<ShimSwapchain> sc;
    {
        std::lock_guard<std::mutex> l(g_mutex);
        auto it = g_swapchains.find(U(s));
        if (it != g_swapchains.end()) { sc = it->second; g_swapchains.erase(it); }
    }
    if (sc) sc->images.reset();
    Rpc c(OP_DESTROY_SWAPCHAIN); c.w.put(U(s));
    return c.call();
}
static XrResult XRAPI_CALL sh_xrEnumerateSwapchainImages(XrSwapchain s, uint32_t cap, uint32_t* n, XrSwapchainImageBaseHeader* out) {
    if (!n) return XR_ERROR_VALIDATION_FAILURE;
    auto sc = findSwapchain(s);
    if (!sc) return XR_ERROR_HANDLE_INVALID;
    *n = sc->imageCount;
    if (cap == 0) return XR_SUCCESS;
    if (cap < sc->imageCount) return XR_ERROR_SIZE_INSUFFICIENT;
    if (!out || out->type != sc->owner->gfx->imageType()) return XR_ERROR_VALIDATION_FAILURE;
    sc->images->fill(out, sc->imageCount);
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrAcquireSwapchainImage(XrSwapchain s, const XrSwapchainImageAcquireInfo*, uint32_t* idx) {
    if (!idx) return XR_ERROR_VALIDATION_FAILURE;
    auto sc = findSwapchain(s);
    if (!sc) return XR_ERROR_HANDLE_INVALID;
    Rpc c(OP_ACQUIRE_IMAGE); c.w.put(U(s));
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    *idx = c.r.get<uint32_t>();
    if (sc->images) sc->images->onAcquire();
    std::lock_guard<std::mutex> l(g_mutex);
    sc->acquired.push_back(*idx);
    sc->acquireThread = GetCurrentThreadId();
    return res;
}
static XrResult XRAPI_CALL sh_xrWaitSwapchainImage(XrSwapchain s, const XrSwapchainImageWaitInfo* wi) {
    if (!wi) return XR_ERROR_VALIDATION_FAILURE;
    auto sc = findSwapchain(s);
    if (!sc) return XR_ERROR_HANDLE_INVALID;
    Rpc c(OP_WAIT_IMAGE); c.w.put(U(s)); c.w.put(wi->timeout);
    XrResult res = c.call();
    if (res != XR_SUCCESS) return res; // includes XR_TIMEOUT_EXPIRED
    std::lock_guard<std::mutex> l(g_mutex);
    if (sc->acquired.empty()) return XR_ERROR_CALL_ORDER_INVALID;
    sc->waited.push_back(sc->acquired.front());
    sc->acquired.pop_front();
    return res;
}
static XrResult XRAPI_CALL sh_xrReleaseSwapchainImage(XrSwapchain s, const XrSwapchainImageReleaseInfo*) {
    auto sc = findSwapchain(s);
    if (!sc) return XR_ERROR_HANDLE_INVALID;
    uint32_t idx;
    {
        std::lock_guard<std::mutex> l(g_mutex);
        if (sc->waited.empty()) return XR_ERROR_CALL_ORDER_INVALID;
        idx = sc->waited.front();
        sc->waited.pop_front();
    }
    sc->images->onRelease(idx);
    uint64_t syncValue = sc->owner->gfx->sync();
    Rpc c(OP_RELEASE_IMAGE); c.w.put(U(s)); c.w.put(syncValue);
    // The host's release copies the image and runs the 64-bit layers' work (Neural
    // Rendering VR's DLSS 5 submit) and the runtime's own release: 1-3 ms the game's
    // render thread need not wait for. It is posted when this thread acquired the image
    // and ends the session's frames, so the host has finished it before that thread's
    // xrEndFrame is sent; anything else waits as before.
    const DWORD me = GetCurrentThreadId();
    static const bool noPost = GetEnvironmentVariableA("XRB_NO_POST", nullptr, 0) > 0;
    if (!noPost && sc->acquireThread == me && sc->owner->endFrameThread == me) {
        static bool logged;
        if (!logged) { logged = true; logf("releases are posted: the game's render thread does not wait for the host's copy and layers"); }
        return c.post();
    }
    return c.call();
}

// ---------------------------------------------------------------- frame loop
static XrResult XRAPI_CALL sh_xrWaitFrame(XrSession s, const XrFrameWaitInfo* wi, XrFrameState* st) {
    if (!st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_WAIT_FRAME); c.w.put(U(s));
    chainIn(c.w, wi ? wi->next : nullptr);
    chainIn(c.w, st->next);
    XrResult res = c.call();
    if (XR_FAILED(res)) return res;
    st->predictedDisplayTime = c.r.get<XrTime>();
    st->predictedDisplayPeriod = c.r.get<XrDuration>();
    st->shouldRender = c.r.get<XrBool32>();
    dChainOut(c.r, st->next);
    return res;
}
static XrResult XRAPI_CALL sh_xrBeginFrame(XrSession s, const XrFrameBeginInfo* bi) {
    Rpc c(OP_BEGIN_FRAME); c.w.put(U(s));
    chainIn(c.w, bi ? bi->next : nullptr);
    return c.call();
}
static XrResult XRAPI_CALL sh_xrEndFrame(XrSession s, const XrFrameEndInfo* fi) {
    if (!fi) return XR_ERROR_VALIDATION_FAILURE;
    {
        std::lock_guard<std::mutex> l(g_mutex);
        auto it = g_sessions.find(U(s));
        if (it != g_sessions.end()) it->second->endFrameThread = GetCurrentThreadId();
    }
    Rpc c(OP_END_FRAME); c.w.put(U(s));
    // Every layer type in the registry, with whatever is chained to it.
    sI_XrFrameEndInfo(c.w, *fi);
    return c.call();
}

// ---------------------------------------------------------------- paths & actions
static XrResult XRAPI_CALL sh_xrStringToPath(XrInstance i, const char* s, XrPath* out) {
    if (!s || !out) return XR_ERROR_VALIDATION_FAILURE;
    // OpenComposite and many games convert the same strings over and over.
    auto key = std::make_pair(U(i), std::string(s));
    {
        std::lock_guard<std::mutex> l(g_mutex);
        auto it = g_pathCache.find(key);
        if (it != g_pathCache.end()) { *out = it->second; return XR_SUCCESS; }
    }
    Rpc c(OP_STRING_TO_PATH); c.w.put(U(i)); c.w.str(s);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) {
        *out = c.r.get<XrPath>();
        std::lock_guard<std::mutex> l(g_mutex);
        if (g_pathCache.size() < 65536) g_pathCache[key] = *out;
    }
    return res;
}
static XrResult stringResult(Rpc& c, XrResult res, uint32_t cap, uint32_t* n, char* buf) {
    if (XR_FAILED(res)) return res;
    uint32_t need = c.r.get<uint32_t>();
    std::string s = c.r.str();
    if (n) *n = need;
    if (cap == 0) return res;
    if (cap < need) return XR_ERROR_SIZE_INSUFFICIENT;
    memcpy(buf, s.c_str(), s.size() + 1);
    return res;
}
static XrResult XRAPI_CALL sh_xrPathToString(XrInstance i, XrPath p, uint32_t cap, uint32_t* n, char* buf) {
    Rpc c(OP_PATH_TO_STRING); c.w.put(U(i)); c.w.put(p);
    XrResult res = c.call();
    return stringResult(c, res, cap, n, buf);
}
static XrResult XRAPI_CALL sh_xrCreateActionSet(XrInstance i, const XrActionSetCreateInfo* ci, XrActionSet* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_CREATE_ACTION_SET); c.w.put(U(i));
    sI_XrActionSetCreateInfo(c.w, *ci);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *out = (XrActionSet)c.r.get<uint64_t>();
    return res;
}
static XrResult XRAPI_CALL sh_xrCreateAction(XrActionSet s, const XrActionCreateInfo* ci, XrAction* out) {
    if (!ci || !out) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_CREATE_ACTION); c.w.put(U(s));
    sI_XrActionCreateInfo(c.w, *ci);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *out = (XrAction)c.r.get<uint64_t>();
    return res;
}
static XrResult XRAPI_CALL sh_xrSuggestInteractionProfileBindings(XrInstance i, const XrInteractionProfileSuggestedBinding* sb) {
    if (!sb) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_SUGGEST_BINDINGS); c.w.put(U(i));
    sI_XrInteractionProfileSuggestedBinding(c.w, *sb);
    return c.call();
}
static XrResult XRAPI_CALL sh_xrAttachSessionActionSets(XrSession s, const XrSessionActionSetsAttachInfo* ai) {
    if (!ai) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_ATTACH_ACTION_SETS); c.w.put(U(s)); c.w.put(ai->countActionSets);
    for (uint32_t i = 0; i < ai->countActionSets; ++i) c.w.put(U(ai->actionSets[i]));
    return c.call();
}
static XrResult XRAPI_CALL sh_xrGetCurrentInteractionProfile(XrSession s, XrPath top, XrInteractionProfileState* st) {
    if (!st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_INTERACTION_PROFILE); c.w.put(U(s)); c.w.put(top);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) st->interactionProfile = c.r.get<XrPath>();
    return res;
}
static void putGetInfo(Rpc& c, XrSession s, const XrActionStateGetInfo* gi) {
    c.w.put(U(s));
    sI_XrActionStateGetInfo(c.w, *gi);
}
static XrResult XRAPI_CALL sh_xrGetActionStateBoolean(XrSession s, const XrActionStateGetInfo* gi, XrActionStateBoolean* st) {
    if (!gi || !st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_STATE_BOOL); putGetInfo(c, s, gi);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) { st->currentState = c.r.get<XrBool32>(); st->changedSinceLastSync = c.r.get<XrBool32>(); st->lastChangeTime = c.r.get<XrTime>(); st->isActive = c.r.get<XrBool32>(); }
    return res;
}
static XrResult XRAPI_CALL sh_xrGetActionStateFloat(XrSession s, const XrActionStateGetInfo* gi, XrActionStateFloat* st) {
    if (!gi || !st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_STATE_FLOAT); putGetInfo(c, s, gi);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) { st->currentState = c.r.get<float>(); st->changedSinceLastSync = c.r.get<XrBool32>(); st->lastChangeTime = c.r.get<XrTime>(); st->isActive = c.r.get<XrBool32>(); }
    return res;
}
static XrResult XRAPI_CALL sh_xrGetActionStateVector2f(XrSession s, const XrActionStateGetInfo* gi, XrActionStateVector2f* st) {
    if (!gi || !st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_STATE_VEC2); putGetInfo(c, s, gi);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) { st->currentState = c.r.get<XrVector2f>(); st->changedSinceLastSync = c.r.get<XrBool32>(); st->lastChangeTime = c.r.get<XrTime>(); st->isActive = c.r.get<XrBool32>(); }
    return res;
}
static XrResult XRAPI_CALL sh_xrGetActionStatePose(XrSession s, const XrActionStateGetInfo* gi, XrActionStatePose* st) {
    if (!gi || !st) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_STATE_POSE); putGetInfo(c, s, gi);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) st->isActive = c.r.get<XrBool32>();
    return res;
}
static XrResult XRAPI_CALL sh_xrSyncActions(XrSession s, const XrActionsSyncInfo* si) {
    if (!si) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_SYNC_ACTIONS); c.w.put(U(s));
    sI_XrActionsSyncInfo(c.w, *si);
    return c.call();
}
static XrResult XRAPI_CALL sh_xrEnumerateBoundSourcesForAction(XrSession s, const XrBoundSourcesForActionEnumerateInfo* ei, uint32_t cap, uint32_t* n, XrPath* out) {
    if (!ei) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_ENUM_BOUND_SOURCES); c.w.put(U(s)); c.w.put(U(ei->action));
    return twoCallFinish(c, cap, n, out);
}
static XrResult XRAPI_CALL sh_xrGetInputSourceLocalizedName(XrSession s, const XrInputSourceLocalizedNameGetInfo* gi, uint32_t cap, uint32_t* n, char* buf) {
    if (!gi) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_GET_SOURCE_NAME); c.w.put(U(s)); c.w.put(gi->sourcePath); c.w.put(gi->whichComponents);
    XrResult res = c.call();
    return stringResult(c, res, cap, n, buf);
}
static XrResult XRAPI_CALL sh_xrApplyHapticFeedback(XrSession s, const XrHapticActionInfo* hi, const XrHapticBaseHeader* h) {
    if (!hi || !h) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_APPLY_HAPTIC); c.w.put(U(s));
    sI_XrHapticActionInfo(c.w, *hi);
    sIAny(c.w, h);
    return c.call();
}
static XrResult XRAPI_CALL sh_xrStopHapticFeedback(XrSession s, const XrHapticActionInfo* hi) {
    if (!hi) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_STOP_HAPTIC); c.w.put(U(s));
    sI_XrHapticActionInfo(c.w, *hi);
    return c.call();
}

// ---------------------------------------------------------------- extensions
static XrResult XRAPI_CALL sh_xrGetD3D11GraphicsRequirementsKHR(XrInstance i, XrSystemId id, XrGraphicsRequirementsD3D11KHR* rq) {
    if (!rq) return XR_ERROR_VALIDATION_FAILURE;
    return hostRequirements(i, id, &rq->adapterLuid, &rq->minFeatureLevel);
}
static XrResult XRAPI_CALL sh_xrGetD3D12GraphicsRequirementsKHR(XrInstance i, XrSystemId id, XrGraphicsRequirementsD3D12KHR* rq) {
    if (!rq) return XR_ERROR_VALIDATION_FAILURE;
    XrResult res = hostRequirements(i, id, &rq->adapterLuid, nullptr);
    rq->minFeatureLevel = D3D_FEATURE_LEVEL_11_0;
    return res;
}
static XrResult XRAPI_CALL sh_xrGetOpenGLGraphicsRequirementsKHR(XrInstance i, XrSystemId id, XrGraphicsRequirementsOpenGLKHR* rq) {
    if (!rq) return XR_ERROR_VALIDATION_FAILURE;
    XrResult res = hostRequirements(i, id, nullptr, nullptr);
    rq->minApiVersionSupported = XR_MAKE_VERSION(3, 0, 0);
    rq->maxApiVersionSupported = XR_MAKE_VERSION(5, 0, 0);
    return res;
}
static XrResult XRAPI_CALL sh_xrGetVulkanGraphicsRequirementsKHR(XrInstance i, XrSystemId id, XrGraphicsRequirementsVulkanKHR* rq) {
    if (!rq) return XR_ERROR_VALIDATION_FAILURE;
    XrResult res = hostRequirements(i, id, nullptr, nullptr);
    rq->minApiVersionSupported = XR_MAKE_VERSION(1, 0, 0);
    rq->maxApiVersionSupported = XR_MAKE_VERSION(2, 0, 0);
    return res;
}
static XrResult copyString(const char* value, uint32_t cap, uint32_t* n, char* buf) {
    if (!n) return XR_ERROR_VALIDATION_FAILURE;
    uint32_t need = (uint32_t)strlen(value) + 1;
    *n = need;
    if (cap == 0) return XR_SUCCESS;
    if (cap < need) return XR_ERROR_SIZE_INSUFFICIENT;
    memcpy(buf, value, need);
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrGetVulkanInstanceExtensionsKHR(XrInstance, XrSystemId, uint32_t cap, uint32_t* n, char* buf) {
    return copyString(kVkInstanceExtensions, cap, n, buf);
}
static XrResult XRAPI_CALL sh_xrGetVulkanDeviceExtensionsKHR(XrInstance, XrSystemId, uint32_t cap, uint32_t* n, char* buf) {
    return copyString(kVkDeviceExtensions, cap, n, buf);
}
static XrResult XRAPI_CALL sh_xrGetVulkanGraphicsDeviceKHR(XrInstance i, XrSystemId id, VkInstance vkInstance, VkPhysicalDevice* out) {
    if (!out) return XR_ERROR_VALIDATION_FAILURE;
    if (nullGfx()) { *out = (VkPhysicalDevice)(uintptr_t)0x1000; return XR_SUCCESS; }
    LUID luid{};
    XrResult res = hostRequirements(i, id, &luid, nullptr);
    if (XR_FAILED(res)) return res;
    return vkPickPhysicalDevice(vkInstance, luid, out);
}

// XR_KHR_vulkan_enable2: the runtime creates the game's instance and device itself,
// so it can add what it needs, including the timeline feature enable1 cannot request.
static std::vector<std::string> splitWords(const char* s) {
    std::vector<std::string> out;
    std::string cur;
    for (; *s; ++s) {
        if (*s == ' ') { if (!cur.empty()) out.push_back(cur); cur.clear(); }
        else cur += *s;
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}
static void mergeNames(std::vector<std::string>& words, uint32_t count, const char* const* names, std::vector<const char*>& out) {
    for (uint32_t i = 0; i < count; ++i) {
        bool dup = false;
        for (auto& w : words) if (w == names[i]) dup = true;
        if (!dup) words.push_back(names[i]);
    }
    for (auto& w : words) out.push_back(w.c_str());
}
static XrResult XRAPI_CALL sh_xrCreateVulkanInstanceKHR(XrInstance, const XrVulkanInstanceCreateInfoKHR* ci, VkInstance* out, VkResult* vkr) {
    if (!ci || !out || !vkr || !ci->vulkanCreateInfo || !ci->pfnGetInstanceProcAddr) return XR_ERROR_VALIDATION_FAILURE;
    vkSetLoaderProc(ci->pfnGetInstanceProcAddr);
    auto words = splitWords(kVkInstanceExtensions);
    std::vector<const char*> names;
    mergeNames(words, ci->vulkanCreateInfo->enabledExtensionCount, ci->vulkanCreateInfo->ppEnabledExtensionNames, names);
    VkInstanceCreateInfo info = *ci->vulkanCreateInfo;
    info.enabledExtensionCount = (uint32_t)names.size();
    info.ppEnabledExtensionNames = names.data();
    auto create = (PFN_vkCreateInstance)ci->pfnGetInstanceProcAddr(VK_NULL_HANDLE, "vkCreateInstance");
    if (!create) return XR_ERROR_RUNTIME_FAILURE;
    *vkr = create(&info, ci->vulkanAllocator, out);
    return XR_SUCCESS;
}
static XrResult XRAPI_CALL sh_xrGetVulkanGraphicsDevice2KHR(XrInstance i, const XrVulkanGraphicsDeviceGetInfoKHR* gi, VkPhysicalDevice* out) {
    if (!gi || !out) return XR_ERROR_VALIDATION_FAILURE;
    return sh_xrGetVulkanGraphicsDeviceKHR(i, gi->systemId, gi->vulkanInstance, out);
}
static XrResult XRAPI_CALL sh_xrCreateVulkanDeviceKHR(XrInstance, const XrVulkanDeviceCreateInfoKHR* ci, VkDevice* out, VkResult* vkr) {
    if (!ci || !out || !vkr || !ci->vulkanCreateInfo || !ci->pfnGetInstanceProcAddr || !ci->vulkanPhysicalDevice) return XR_ERROR_VALIDATION_FAILURE;
    vkSetLoaderProc(ci->pfnGetInstanceProcAddr);
    auto words = splitWords(kVkDeviceExtensions);
    std::vector<const char*> names;
    mergeNames(words, ci->vulkanCreateInfo->enabledExtensionCount, ci->vulkanCreateInfo->ppEnabledExtensionNames, names);
    VkDeviceCreateInfo info = *ci->vulkanCreateInfo;
    info.enabledExtensionCount = (uint32_t)names.size();
    info.ppEnabledExtensionNames = names.data();

    // The timeline feature may already be in the app's chain, and listing a struct
    // type twice is invalid, so the existing struct is reused when there is one.
    bool present = false;
    for (auto* b = (const VkBaseInStructure*)info.pNext; b; b = b->pNext)
        if (b->sType == VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES || b->sType == VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES) {
            present = true;
            // Enabling the flag in the struct the app passed is harmless: it asked us to
            // create a device that supports the runtime's needs.
            if (b->sType == VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES) ((VkPhysicalDeviceVulkan12Features*)b)->timelineSemaphore = VK_TRUE;
            else ((VkPhysicalDeviceTimelineSemaphoreFeatures*)b)->timelineSemaphore = VK_TRUE;
        }
    VkPhysicalDeviceTimelineSemaphoreFeatures timeline{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES};
    timeline.timelineSemaphore = VK_TRUE;
    if (!present) { timeline.pNext = (void*)info.pNext; info.pNext = &timeline; }

    auto create = (PFN_vkCreateDevice)ci->pfnGetInstanceProcAddr(VK_NULL_HANDLE, "vkCreateDevice");
    if (!create) return XR_ERROR_RUNTIME_FAILURE;
    *vkr = create(ci->vulkanPhysicalDevice, &info, ci->vulkanAllocator, out);
    return XR_SUCCESS;
}

static XrResult XRAPI_CALL sh_xrGetVisibilityMaskKHR(XrSession s, XrViewConfigurationType vc, uint32_t view, XrVisibilityMaskTypeKHR t, XrVisibilityMaskKHR* m) {
    if (!m) return XR_ERROR_VALIDATION_FAILURE;
    uint64_t inst = instanceOfSession(s);
    if (!inst) return XR_ERROR_HANDLE_INVALID;
    Rpc c(OP_GET_VISIBILITY_MASK); c.w.put(U(s)); c.w.put(inst); c.w.put((int32_t)vc); c.w.put(view); c.w.put((int32_t)t);
    c.w.put(m->vertexCapacityInput); c.w.put(m->indexCapacityInput);
    XrResult res = c.call();
    if (XR_FAILED(res) && res != XR_ERROR_SIZE_INSUFFICIENT) return res;
    m->vertexCountOutput = c.r.get<uint32_t>();
    m->indexCountOutput = c.r.get<uint32_t>();
    if (XR_SUCCEEDED(res)) {
        if (m->vertexCapacityInput) c.r.raw(m->vertices, m->vertexCountOutput * sizeof(XrVector2f));
        if (m->indexCapacityInput) c.r.raw(m->indices, m->indexCountOutput * sizeof(uint32_t));
    }
    return res;
}
static XrResult XRAPI_CALL sh_xrConvertWin32PerformanceCounterToTimeKHR(XrInstance i, const LARGE_INTEGER* pc, XrTime* t) {
    if (!pc || !t) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_PERF_TO_TIME); c.w.put(U(i)); c.w.put((int64_t)pc->QuadPart);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) *t = c.r.get<XrTime>();
    return res;
}
static XrResult XRAPI_CALL sh_xrConvertTimeToWin32PerformanceCounterKHR(XrInstance i, XrTime t, LARGE_INTEGER* pc) {
    if (!pc) return XR_ERROR_VALIDATION_FAILURE;
    Rpc c(OP_TIME_TO_PERF); c.w.put(U(i)); c.w.put(t);
    XrResult res = c.call();
    if (XR_SUCCEEDED(res)) pc->QuadPart = c.r.get<int64_t>();
    return res;
}

// ---------------------------------------------------------------- loader interface
static XrResult XRAPI_CALL sh_xrGetInstanceProcAddr(XrInstance, const char* name, PFN_xrVoidFunction* fn);

struct Entry { const char* name; PFN_xrVoidFunction fn; };
#define E(n) {#n, (PFN_xrVoidFunction)sh_##n}
static const Entry kEntries[] = {
    E(xrGetInstanceProcAddr), E(xrEnumerateApiLayerProperties), E(xrEnumerateInstanceExtensionProperties),
    E(xrCreateInstance), E(xrDestroyInstance), E(xrGetInstanceProperties), E(xrPollEvent),
    E(xrResultToString), E(xrStructureTypeToString), E(xrGetSystem), E(xrGetSystemProperties),
    E(xrEnumerateEnvironmentBlendModes), E(xrCreateSession), E(xrDestroySession),
    E(xrEnumerateReferenceSpaces), E(xrCreateReferenceSpace), E(xrGetReferenceSpaceBoundsRect),
    E(xrCreateActionSpace), E(xrLocateSpace), E(xrDestroySpace),
    E(xrEnumerateViewConfigurations), E(xrGetViewConfigurationProperties), E(xrEnumerateViewConfigurationViews),
    E(xrEnumerateSwapchainFormats), E(xrCreateSwapchain), E(xrDestroySwapchain), E(xrEnumerateSwapchainImages),
    E(xrAcquireSwapchainImage), E(xrWaitSwapchainImage), E(xrReleaseSwapchainImage),
    E(xrBeginSession), E(xrEndSession), E(xrRequestExitSession),
    E(xrWaitFrame), E(xrBeginFrame), E(xrEndFrame), E(xrLocateViews),
    E(xrStringToPath), E(xrPathToString),
    E(xrCreateActionSet), E(xrDestroyActionSet), E(xrCreateAction), E(xrDestroyAction),
    E(xrSuggestInteractionProfileBindings), E(xrAttachSessionActionSets), E(xrGetCurrentInteractionProfile),
    E(xrGetActionStateBoolean), E(xrGetActionStateFloat), E(xrGetActionStateVector2f), E(xrGetActionStatePose),
    E(xrSyncActions), E(xrEnumerateBoundSourcesForAction), E(xrGetInputSourceLocalizedName),
    E(xrApplyHapticFeedback), E(xrStopHapticFeedback), E(xrLocateSpaces),
    E(xrGetD3D11GraphicsRequirementsKHR), E(xrGetVisibilityMaskKHR),
    E(xrConvertWin32PerformanceCounterToTimeKHR), E(xrConvertTimeToWin32PerformanceCounterKHR),
    E(xrGetD3D12GraphicsRequirementsKHR), E(xrGetOpenGLGraphicsRequirementsKHR),
    E(xrGetVulkanGraphicsRequirementsKHR), E(xrGetVulkanInstanceExtensionsKHR), E(xrGetVulkanDeviceExtensionsKHR), E(xrGetVulkanGraphicsDeviceKHR),
    {"xrGetVulkanGraphicsRequirements2KHR", (PFN_xrVoidFunction)sh_xrGetVulkanGraphicsRequirementsKHR},
    E(xrCreateVulkanInstanceKHR), E(xrCreateVulkanDeviceKHR), E(xrGetVulkanGraphicsDevice2KHR),
};
// Everything before xrGetD3D11GraphicsRequirementsKHR above is core OpenXR 1.0 or 1.1.
static const size_t kFirstExtensionEntry = [] {
    size_t i = 0;
    for (auto& e : kEntries) { if (!strcmp(e.name, "xrGetD3D11GraphicsRequirementsKHR")) return i; ++i; }
    return i;
}();
// Functions implemented here, by the extension that has to be enabled for them.
static const char* shimExtensionOf(const char* name) {
    if (strstr(name, "D3D12")) return "XR_KHR_D3D12_enable";
    if (strstr(name, "OpenGL")) return "XR_KHR_opengl_enable";
    if (strstr(name, "Vulkan") && strstr(name, "2KHR")) return "XR_KHR_vulkan_enable2";
    if (strstr(name, "Vulkan")) return "XR_KHR_vulkan_enable";
    return nullptr;
}
static bool hostHasFunction(XrInstance i, const char* name) {
    Rpc c(OP_HAS_FUNCTION); c.w.put(U(i)); c.w.str(name);
    return XR_SUCCEEDED(c.call());
}
static XrResult XRAPI_CALL sh_xrGetInstanceProcAddr(XrInstance inst, const char* name, PFN_xrVoidFunction* fn) {
    if (!name || !fn) return XR_ERROR_VALIDATION_FAILURE;
    *fn = nullptr;
    // An extension function is offered only when its extension is really there, as on a
    // native runtime. Games and OpenComposite probe functions to decide what to switch on.
    // Calls without an instance are the loader's own probes, which never use the result.
    PFN_xrVoidFunction found = nullptr;
    size_t index = 0;
    for (auto& e : kEntries) {
        if (!strcmp(e.name, name)) { found = e.fn; break; }
        ++index;
    }
    if (found) {
        const bool core = index < kFirstExtensionEntry;
        if (!core && inst) {
            if (const char* ext = shimExtensionOf(name)) {
                std::lock_guard<std::mutex> l(g_mutex);
                auto it = g_instanceExtensions.find(U(inst));
                if (it != g_instanceExtensions.end() && !it->second.count(ext)) return XR_ERROR_FUNCTION_UNSUPPORTED;
            } else if (!hostHasFunction(inst, name)) {
                return XR_ERROR_FUNCTION_UNSUPPORTED;
            }
        }
        *fn = found;
        return XR_SUCCESS;
    }
    for (auto& e : kGenThunks) if (!strcmp(e.name, name)) {
        if (inst && !hostHasFunction(inst, name)) return XR_ERROR_FUNCTION_UNSUPPORTED;
        *fn = e.fn;
        return XR_SUCCESS;
    }
    return XR_ERROR_FUNCTION_UNSUPPORTED;
}

extern "C" __declspec(dllexport) XrResult XRAPI_CALL xrNegotiateLoaderRuntimeInterface(const XrNegotiateLoaderInfo* info, XrNegotiateRuntimeRequest* req) {
    if (!info || !req || info->structType != XR_LOADER_INTERFACE_STRUCT_LOADER_INFO ||
        req->structType != XR_LOADER_INTERFACE_STRUCT_RUNTIME_REQUEST)
        return XR_ERROR_INITIALIZATION_FAILED;
    if (info->minInterfaceVersion > XR_CURRENT_LOADER_RUNTIME_VERSION || info->maxInterfaceVersion < XR_CURRENT_LOADER_RUNTIME_VERSION)
        return XR_ERROR_INITIALIZATION_FAILED;
    req->runtimeInterfaceVersion = XR_CURRENT_LOADER_RUNTIME_VERSION;
    // Never above what the loader accepts: a game may ship an older 1.0-only loader.
    req->runtimeApiVersion = info->maxApiVersion < XR_MAKE_VERSION(1, 1, 0) ? info->maxApiVersion : XR_MAKE_VERSION(1, 1, 0);
    req->getInstanceProcAddr = sh_xrGetInstanceProcAddr;
    return XR_SUCCESS;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD why, LPVOID reserved) {
    if (why == DLL_PROCESS_ATTACH) {
        g_module = h;
        g_tls = TlsAlloc();
        g_linkTls = TlsAlloc();
    } else if (why == DLL_THREAD_DETACH && g_tls != TLS_OUT_OF_INDEXES) {
        detachThread();
    } else if (why == DLL_PROCESS_DETACH && reserved) {
        // The process is exiting. Other threads were killed and may hold our locks, so taking
        // one could hang the game on exit. Windows closes the pipes, and the host sees that.
    } else if (why == DLL_PROCESS_DETACH) {
        // The loader unloads the runtime after the last instance. Closing every pipe
        // lets the host see that and exit, so a later session starts a clean one.
        detachThread();
        if (g_linkTls != TLS_OUT_OF_INDEXES) TlsFree(g_linkTls);
        std::lock_guard<std::mutex> l(g_connMutex);
        for (HANDLE h : g_connections) CloseHandle(h);
        g_connections.clear();
    }
    return TRUE;
}
