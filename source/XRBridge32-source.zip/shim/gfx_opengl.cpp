// OpenGL game side.
//
// OpenGL's first texel row is the bottom of the image, D3D's is the top, so a texture
// sharing memory with D3D11 reads upside down to the runtime. The game therefore renders
// to a plain GL texture of ours, and on release we blit it, flipped, into the imported
// shared texture. No shader or D3D-side pass is needed, and the bytes are copied raw.
#include "gfx.h"
#include "../common/formats.h"
#include <cstring>

namespace {
typedef unsigned int GLenum; typedef unsigned int GLuint; typedef int GLint; typedef int GLsizei;
typedef unsigned int GLbitfield; typedef unsigned char GLubyte; typedef unsigned char GLboolean; typedef unsigned long long GLuint64;

enum : GLenum {
    GL_TEXTURE_2D = 0x0DE1, GL_TEXTURE_2D_ARRAY = 0x8C1A, GL_TEXTURE_BINDING_2D = 0x8069, GL_TEXTURE_BINDING_2D_ARRAY = 0x8C1D,
    GL_READ_FRAMEBUFFER = 0x8CA8, GL_DRAW_FRAMEBUFFER = 0x8CA9, GL_READ_FRAMEBUFFER_BINDING = 0x8CAA, GL_DRAW_FRAMEBUFFER_BINDING = 0x8CA6,
    GL_COLOR_ATTACHMENT0 = 0x8CE0, GL_COLOR_BUFFER_BIT = 0x4000, GL_NEAREST = 0x2600, GL_SCISSOR_TEST = 0x0C11, GL_FRAMEBUFFER_SRGB = 0x8DB9,
    GL_HANDLE_TYPE_D3D11_IMAGE_EXT = 0x958B, GL_HANDLE_TYPE_D3D11_IMAGE_KMT_EXT = 0x958C, GL_HANDLE_TYPE_D3D12_FENCE_EXT = 0x9594, GL_D3D12_FENCE_VALUE_EXT = 0x9595, GL_DEVICE_LUID_EXT = 0x9599,
    GL_FRAMEBUFFER_COMPLETE = 0x8CD5, GL_RASTERIZER_DISCARD = 0x8C89, GL_NO_ERROR = 0,
    GL_DEPTH_ATTACHMENT = 0x8D00, GL_DEPTH_STENCIL_ATTACHMENT = 0x821A, GL_DEPTH_BUFFER_BIT = 0x0100, GL_STENCIL_BUFFER_BIT = 0x0400,
};

struct GlDispatch {
    void (APIENTRY* glFlush)(); void (APIENTRY* glFinish)(); GLenum (APIENTRY* glGetError)();
    void (APIENTRY* glGetIntegerv)(GLenum, GLint*); GLboolean (APIENTRY* glIsEnabled)(GLenum);
    void (APIENTRY* glEnable)(GLenum); void (APIENTRY* glDisable)(GLenum);
    void (APIENTRY* glGenTextures)(GLsizei, GLuint*); void (APIENTRY* glDeleteTextures)(GLsizei, const GLuint*); void (APIENTRY* glBindTexture)(GLenum, GLuint);
    // Extension entry points
    void (APIENTRY* glCreateMemoryObjectsEXT)(GLsizei, GLuint*);
    void (APIENTRY* glDeleteMemoryObjectsEXT)(GLsizei, const GLuint*);
    void (APIENTRY* glImportMemoryWin32HandleEXT)(GLuint, GLuint64, GLenum, void*);
    void (APIENTRY* glTexStorageMem2DEXT)(GLenum, GLsizei, GLenum, GLsizei, GLsizei, GLuint, GLuint64);
    void (APIENTRY* glTexStorageMem3DEXT)(GLenum, GLsizei, GLenum, GLsizei, GLsizei, GLsizei, GLuint, GLuint64);
    void (APIENTRY* glTexStorage2D)(GLenum, GLsizei, GLenum, GLsizei, GLsizei);
    void (APIENTRY* glTexStorage3D)(GLenum, GLsizei, GLenum, GLsizei, GLsizei, GLsizei);
    void (APIENTRY* glGenFramebuffers)(GLsizei, GLuint*); void (APIENTRY* glDeleteFramebuffers)(GLsizei, const GLuint*);
    void (APIENTRY* glBindFramebuffer)(GLenum, GLuint);
    void (APIENTRY* glFramebufferTexture2D)(GLenum, GLenum, GLenum, GLuint, GLint);
    void (APIENTRY* glFramebufferTextureLayer)(GLenum, GLenum, GLuint, GLint, GLint);
    void (APIENTRY* glBlitFramebuffer)(GLint, GLint, GLint, GLint, GLint, GLint, GLint, GLint, GLbitfield, GLenum);
    void (APIENTRY* glGetUnsignedBytevEXT)(GLenum, GLubyte*);
    void (APIENTRY* glGenSemaphoresEXT)(GLsizei, GLuint*); void (APIENTRY* glDeleteSemaphoresEXT)(GLsizei, const GLuint*);
    void (APIENTRY* glImportSemaphoreWin32HandleEXT)(GLuint, GLenum, void*);
    void (APIENTRY* glSemaphoreParameterui64vEXT)(GLuint, GLenum, const GLuint64*);
    void (APIENTRY* glSignalSemaphoreEXT)(GLuint, GLuint, const GLuint*, GLuint, const GLuint*, const GLenum*);
};

// Makes the game's context current for the duration of a call and puts things back.
class ContextGuard {
    HDC prevDC; HGLRC prevRC; bool switched = false;
public:
    ContextGuard(HDC dc, HGLRC rc) : prevDC(wglGetCurrentDC()), prevRC(wglGetCurrentContext()) {
        if (prevRC != rc) { wglMakeCurrent(dc, rc); switched = true; }
    }
    ~ContextGuard() { if (switched) wglMakeCurrent(prevDC, prevRC); }
};

class GlSession;

class GlImages : public GfxImages {
public:
    GlSession* s;
    GLenum target;
    SwapchainInfo info;
    std::vector<GLuint> appTex, sharedTex, memory;
    GlImages(GlSession* session, const SwapchainInfo& i) : s(session), target(i.arraySize > 1 ? GL_TEXTURE_2D_ARRAY : GL_TEXTURE_2D), info(i) {}
    ~GlImages() override;
    void fill(XrSwapchainImageBaseHeader* out, uint32_t count) override {
        auto* d = (XrSwapchainImageOpenGLKHR*)out;
        for (uint32_t i = 0; i < count && i < appTex.size(); ++i) d[i].image = appTex[i];
    }
    void onRelease(uint32_t idx) override;
};

class GlSession : public GfxSession {
public:
    HDC dc; HGLRC rc;
    GlDispatch gl{};
    GLuint semaphore = 0, fbo[2] = {0, 0};
    HANDLE fenceHandle = nullptr; // kept open: some AMD drivers need it to outlive the import
    GLuint64 value = 0;

    explicit GlSession(const XrGraphicsBindingOpenGLWin32KHR& b) : dc(b.hDC), rc(b.hGLRC) {}
    ~GlSession() override {
        if (rc && gl.glFinish && wglGetCurrentContext() == rc) {
            gl.glFinish();
            if (semaphore) gl.glDeleteSemaphoresEXT(1, &semaphore);
            if (fbo[0]) gl.glDeleteFramebuffers(2, fbo);
        }
        if (fenceHandle) CloseHandle(fenceHandle);
    }
    const char* name() const override { return "OpenGL"; }
    bool bottomUp() const override { return true; }
    XrStructureType imageType() const override { return XR_TYPE_SWAPCHAIN_IMAGE_OPENGL_KHR; }
    int64_t appFormat(int dxgi) const override { const XrbFormat* f = xrbFindDxgi(dxgi); return f && f->gl ? f->gl : -1; }
    int dxgiFormat(int64_t app) const override { const XrbFormat* f = xrbFindGl((int)app); return f ? f->dxgi : -1; }

    XrResult init(HANDLE fence, const LUID& luid) override {
        fenceHandle = fence;
        if (!dc || !rc) return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        ContextGuard g(dc, rc);
        if (wglGetCurrentContext() != rc) {
            logf("OpenGL: could not make the game's context current");
            return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        }
        HMODULE m = GetModuleHandleA("opengl32.dll");
        if (!m) return XR_ERROR_RUNTIME_FAILURE;
#define CORE(f) gl.f = (decltype(gl.f))GetProcAddress(m, #f);
        CORE(glFlush) CORE(glFinish) CORE(glGetError) CORE(glGetIntegerv) CORE(glIsEnabled) CORE(glEnable) CORE(glDisable)
        CORE(glGenTextures) CORE(glDeleteTextures) CORE(glBindTexture)
#undef CORE
#define EXT(f) gl.f = (decltype(gl.f))wglGetProcAddress(#f);
        EXT(glCreateMemoryObjectsEXT) EXT(glDeleteMemoryObjectsEXT) EXT(glImportMemoryWin32HandleEXT)
        EXT(glTexStorageMem2DEXT) EXT(glTexStorageMem3DEXT) EXT(glTexStorage2D) EXT(glTexStorage3D)
        EXT(glGenFramebuffers) EXT(glDeleteFramebuffers) EXT(glBindFramebuffer) EXT(glFramebufferTexture2D)
        EXT(glFramebufferTextureLayer) EXT(glBlitFramebuffer) EXT(glGetUnsignedBytevEXT)
        EXT(glGenSemaphoresEXT) EXT(glDeleteSemaphoresEXT) EXT(glImportSemaphoreWin32HandleEXT)
        EXT(glSemaphoreParameterui64vEXT) EXT(glSignalSemaphoreEXT)
#undef EXT
        if (!gl.glCreateMemoryObjectsEXT || !gl.glImportMemoryWin32HandleEXT || !gl.glTexStorageMem2DEXT ||
            !gl.glTexStorage2D || !gl.glBlitFramebuffer || !gl.glGenFramebuffers) {
            logf("OpenGL: this driver or context lacks GL_EXT_memory_object_win32 or GL 4.2 storage, so frames cannot be shared");
            return XR_ERROR_GRAPHICS_DEVICE_INVALID;
        }
        if (gl.glGetUnsignedBytevEXT) {
            GLubyte got[8] = {};
            gl.glGetUnsignedBytevEXT(GL_DEVICE_LUID_EXT, got);
            if (gl.glGetError() == GL_NO_ERROR && memcmp(got, &luid, sizeof(LUID))) {
                logf("OpenGL: the game's GPU is not the headset's GPU");
                return XR_ERROR_GRAPHICS_DEVICE_INVALID;
            }
        }
        gl.glGenFramebuffers(2, fbo);
        if (fence && gl.glGenSemaphoresEXT && gl.glImportSemaphoreWin32HandleEXT && gl.glSemaphoreParameterui64vEXT && gl.glSignalSemaphoreEXT) {
            gl.glGenSemaphoresEXT(1, &semaphore);
            gl.glImportSemaphoreWin32HandleEXT(semaphore, GL_HANDLE_TYPE_D3D12_FENCE_EXT, fence);
            if (gl.glGetError() != GL_NO_ERROR) {
                gl.glDeleteSemaphoresEXT(1, &semaphore);
                semaphore = 0;
            }
        }
        if (!semaphore) logf("OpenGL: no shared fence, using CPU sync");
        return XR_SUCCESS;
    }

    XrResult open(const SwapchainInfo& info, const std::vector<uint64_t>& handles, GfxImages** out) override {
        if (info.sampleCount > 1 || info.faceCount > 1) {
            logf("OpenGL: multisampled and cube swapchains are not supported across the bridge");
            return XR_ERROR_FEATURE_UNSUPPORTED;
        }
        const XrbFormat* f = xrbFindGl((int)info.appFormat);
        if (!f) return XR_ERROR_SWAPCHAIN_FORMAT_UNSUPPORTED;
        ContextGuard g(dc, rc);
        for (int i = 0; i < 64 && gl.glGetError() != GL_NO_ERROR; ++i) {} // bounded: a lost context never clears
        auto* im = new GlImages(this, info);
        GLint prevBind = 0;
        gl.glGetIntegerv(im->target == GL_TEXTURE_2D ? GL_TEXTURE_BINDING_2D : GL_TEXTURE_BINDING_2D_ARRAY, &prevBind);
        // The ×2 mirrors what drivers need for imported D3D11 textures in PimaxXR.
        GLuint64 size = (GLuint64)info.width * info.height * info.arraySize * f->bytesPerPixel * 2;
        for (uint64_t h : handles) {
            GLuint mem = 0, shared = 0, app = 0;
            gl.glCreateMemoryObjectsEXT(1, &mem);
            gl.glImportMemoryWin32HandleEXT(mem, size, info.ntHandles ? GL_HANDLE_TYPE_D3D11_IMAGE_EXT : GL_HANDLE_TYPE_D3D11_IMAGE_KMT_EXT, (void*)(uintptr_t)h);
            gl.glGenTextures(1, &shared);
            gl.glBindTexture(im->target, shared);
            if (im->target == GL_TEXTURE_2D) gl.glTexStorageMem2DEXT(GL_TEXTURE_2D, info.mipCount, (GLenum)info.appFormat, info.width, info.height, mem, 0);
            else gl.glTexStorageMem3DEXT(GL_TEXTURE_2D_ARRAY, info.mipCount, (GLenum)info.appFormat, info.width, info.height, info.arraySize, mem, 0);
            gl.glGenTextures(1, &app);
            gl.glBindTexture(im->target, app);
            if (im->target == GL_TEXTURE_2D) gl.glTexStorage2D(GL_TEXTURE_2D, info.mipCount, (GLenum)info.appFormat, info.width, info.height);
            else gl.glTexStorage3D(GL_TEXTURE_2D_ARRAY, info.mipCount, (GLenum)info.appFormat, info.width, info.height, info.arraySize);
            im->memory.push_back(mem);
            im->sharedTex.push_back(shared);
            im->appTex.push_back(app);
            GLenum err = gl.glGetError();
            if (err != GL_NO_ERROR) {
                logf("OpenGL: importing a shared texture failed, GL error 0x%04x", err);
                gl.glBindTexture(im->target, (GLuint)prevBind);
                delete im;
                return XR_ERROR_GRAPHICS_DEVICE_INVALID;
            }
        }
        gl.glBindTexture(im->target, (GLuint)prevBind);
        *out = im;
        return XR_SUCCESS;
    }

    uint64_t sync() override {
        ContextGuard g(dc, rc);
        if (semaphore) {
            GLuint64 v = value + 1;
            gl.glSemaphoreParameterui64vEXT(semaphore, GL_D3D12_FENCE_VALUE_EXT, &v);
            gl.glSignalSemaphoreEXT(semaphore, 0, nullptr, 0, nullptr, nullptr);
            gl.glFlush();
            value = v;
            return v;
        }
        gl.glFinish();
        return 0;
    }
};

GlImages::~GlImages() {
    ContextGuard g(s->dc, s->rc);
    if (wglGetCurrentContext() != s->rc) return;
    if (!appTex.empty()) s->gl.glDeleteTextures((GLsizei)appTex.size(), appTex.data());
    if (!sharedTex.empty()) s->gl.glDeleteTextures((GLsizei)sharedTex.size(), sharedTex.data());
    if (!memory.empty() && s->gl.glDeleteMemoryObjectsEXT) s->gl.glDeleteMemoryObjectsEXT((GLsizei)memory.size(), memory.data());
}

void GlImages::onRelease(uint32_t idx) {
    if (idx >= appTex.size()) return;
    ContextGuard g(s->dc, s->rc);
    GlDispatch& gl = s->gl;
    GLint prevRead = 0, prevDraw = 0;
    gl.glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &prevRead);
    gl.glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &prevDraw);
    // These are the only states that affect a blit. sRGB off means raw bytes.
    const XrbFormat* f = xrbFindGl((int)info.appFormat);
    const bool depth = f && f->depth;
    const GLenum attachment = depth ? (f->stencil ? GL_DEPTH_STENCIL_ATTACHMENT : GL_DEPTH_ATTACHMENT) : GL_COLOR_ATTACHMENT0;
    const GLbitfield mask = depth ? (GL_DEPTH_BUFFER_BIT | (f->stencil ? GL_STENCIL_BUFFER_BIT : 0)) : GL_COLOR_BUFFER_BIT;
    GLboolean scissor = gl.glIsEnabled(GL_SCISSOR_TEST), srgb = gl.glIsEnabled(GL_FRAMEBUFFER_SRGB), discard = gl.glIsEnabled(GL_RASTERIZER_DISCARD);
    if (scissor) gl.glDisable(GL_SCISSOR_TEST);
    if (srgb) gl.glDisable(GL_FRAMEBUFFER_SRGB);
    if (discard) gl.glDisable(GL_RASTERIZER_DISCARD);
    gl.glBindFramebuffer(GL_READ_FRAMEBUFFER, s->fbo[0]);
    gl.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, s->fbo[1]);
    for (uint32_t mip = 0; mip < info.mipCount; ++mip) {
        GLint w = info.width >> mip, h = info.height >> mip;
        if (w < 1) w = 1;
        if (h < 1) h = 1;
        for (uint32_t layer = 0; layer < info.arraySize; ++layer) {
            if (target == GL_TEXTURE_2D) {
                gl.glFramebufferTexture2D(GL_READ_FRAMEBUFFER, attachment, GL_TEXTURE_2D, appTex[idx], (GLint)mip);
                gl.glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, attachment, GL_TEXTURE_2D, sharedTex[idx], (GLint)mip);
            } else {
                gl.glFramebufferTextureLayer(GL_READ_FRAMEBUFFER, attachment, appTex[idx], (GLint)mip, (GLint)layer);
                gl.glFramebufferTextureLayer(GL_DRAW_FRAMEBUFFER, attachment, sharedTex[idx], (GLint)mip, (GLint)layer);
            }
            gl.glBlitFramebuffer(0, 0, w, h, 0, h, w, 0, mask, GL_NEAREST);
        }
    }
    gl.glBindFramebuffer(GL_READ_FRAMEBUFFER, (GLuint)prevRead);
    gl.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, (GLuint)prevDraw);
    if (scissor) gl.glEnable(GL_SCISSOR_TEST);
    if (srgb) gl.glEnable(GL_FRAMEBUFFER_SRGB);
    if (discard) gl.glEnable(GL_RASTERIZER_DISCARD);
}
} // namespace

GfxSession* makeOpenGLSession(const XrGraphicsBindingOpenGLWin32KHR& b) { return new GlSession(b); }
